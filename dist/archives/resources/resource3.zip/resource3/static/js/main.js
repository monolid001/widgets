import '../css/main.scss';
//------------------------


$(document).ready(function () {
  setTimeout(function () {
    $('.ffl').addClass('ffl__anim')
  }, 300)
})

$(window).on('load resize', function () {
  let fflHeight = $('.ffl').outerHeight();
  if ($(window).width() < 469 && !$('.ffl').hasClass('ffl__out')) {
    $('html').css('padding-bottom', fflHeight + 'px')
  } else {
    $('html').css('padding-bottom', '0')
  }
})

$('.ffl__close, .ffl__btn').on('click', function () {
  $('.ffl').addClass('ffl__out')
  $('html').css('padding-bottom', '0')
})

jQuery(document).ready(function () {
  $('.ffl__close, .ffl__btn').on('click', function () {
    $('.ffl').addClass('ffl__out')
    $('html').css('padding-bottom', '0')
    $('.site-footer').css('padding-bottom', '35px')
  })
});


function getElementY(query) {
  return window.pageYOffset + document.querySelector(query).getBoundingClientRect().top;
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();

    const targetID = this.getAttribute('href');
    const target_Y = getElementY(targetID);

    let scroll = (targetY) => {
      window.scrollTo({
        top: targetY,
        behavior: 'smooth'
      })
      setTimeout(() => {
        const targetY_again = getElementY(targetID);
        if (targetY !== targetY_again) {
          scroll(targetY_again)
        }
      }, 700)
    }

    scroll(target_Y)
  });
});

const leftPack = $('.left-pack');
let countt = localStorage.getItem('leftPack') ? Number(localStorage.getItem('leftPack')) : 43;
function randomInteger(min, max) {
let rand = min - 0.5 + Math.random() * (max - min + 1);
return Math.round(rand);}


function init(countt) {
if(countt > 5){
leftPack.html(localStorage.getItem('leftPack'));
localStorage.setItem('leftPack', countt);
leftPack.html(countt);
} else if (countt === 5) {
leftPack.html(5);}
} init(countt);
setInterval(function() {
countt -= randomInteger(1,2);
init(countt);
}, 60000);

window.addEventListener('scroll', function () {
  var header = document.querySelector('.dst-header-component');
  var headerContent = document.querySelector('.fix');
  if (window.innerWidth >= 1024) {
    if (window.pageYOffset > 100) {
      header.style.top = 0;
      headerContent.style.display = 'block';
    } else {
      headerContent.style.display = 'none';
    }
  }
});

let lastScrollTop = 0;
let isFixed = false; 
window.addEventListener('scroll', function () {
  clearTimeout(window.fixedTimeout);
  if (window.pageYOffset > 120 && window.innerWidth <= 1023) {
    window.fixedTimeout = setTimeout(() => {
      var tabHeader = document.querySelector('.dst-header-component');
      if (!isFixed) {
        tabHeader.classList.add('fixed');
        isFixed = true;
      }
    }, 100); 
  } else {
    var tabHeader = document.querySelector('.dst-header-component');
    if (isFixed) {
      tabHeader.classList.remove('fixed');
      isFixed = false;
    }
  }
});

var adBanner = document.querySelector('.site-sitebar.ad');
var initialBannerOffset = adBanner.offsetTop;
var adBannerHeight = adBanner.offsetHeight;
var fixed = false;
function onScroll() {
    var scrollY = window.scrollY || window.pageYOffset;
    if (scrollY > initialBannerOffset + 100) {
        if (!fixed) {
            adBanner.style.position = 'fixed';
            adBanner.style.top = '100px';
            adBanner.style.width = '280px';
            fixed = true;
        }
    } else if (scrollY <= initialBannerOffset + 100 && fixed) {
        adBanner.style.position = 'fixed';
        adBanner.style.top = '50px';
        adBanner.style.width = '280px';
    }
    if (scrollY < initialBannerOffset && fixed) {
        adBanner.style.position = '';
        adBanner.style.top = '';
        adBanner.style.width = '';
        fixed = false;
    }
}
window.addEventListener('scroll', onScroll);

document.addEventListener('DOMContentLoaded', (event) => {
  var scrollButton = document.getElementById('scrollButton');
  scrollButton.addEventListener('click', function() {
    var rouletteSection = document.getElementById('roulette');
    rouletteSection.scrollIntoView({
      behavior: 'smooth', 
      block: 'start' 
    });
  });
});

document.addEventListener('DOMContentLoaded', (event) => {
  var scrollButton = document.getElementById('scrollButton1');
  scrollButton.addEventListener('click', function() {
    var rouletteSection = document.getElementById('roulette');
    rouletteSection.scrollIntoView({
      behavior: 'smooth', 
      block: 'start' 
    });
  });
});

document.addEventListener('DOMContentLoaded', (event) => {
  var scrollButton = document.getElementById('scrollButton2');
  scrollButton.addEventListener('click', function() {
    var rouletteSection = document.getElementById('roulette');
    rouletteSection.scrollIntoView({
      behavior: 'smooth', 
      block: 'start' 
    });
  });
});

