<!DOCTYPE html>
<html class="theme-gesundheit dst-header" lang="de-AT">

<head>
  <title>Medizinisches Paradox: Milchkonsum bei Laktoseintoleranz reduziert Diabetesrisiko&nbsp;- Forschung&nbsp;-
    derStandard.at &#x203A;Gesundheit</title>
  <meta charset="utf-8">
  <meta name="msapplication-config" content="none" />
  <meta name="viewport"
    content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=2.0, user-scalable=yes" />

  <link rel="stylesheet" href="./static/dist/bundle.css">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>

<body data-embed-autoload="true" data-embed-placeholder data-pur="false" class="is-sticky-statusbar">
  <dst-header class="dst-header-component" appid="editorialweb" variant="at">
    <header class="app--header">
      <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
        <symbol id="symbol-brandlogo" viewBox="0 0 276 40">
          <path fill="currentcolor"
            d="M.04 28.98c0-1.02 1.12-.83 2.08-1.21 1.44-.58 1.47-1.88 1.47-3.59V10.64c0-1.7-.03-3-1.47-3.58-.96-.39-2.08-.2-2.08-1.22 0-.43.21-.66.63-.66H11.9c8.68 0 14.23 4.48 14.23 11.58 0 7.83-5.55 12.88-14.23 12.88H.67c-.42 0-.63-.23-.63-.66zm20.84-11.12c0-6.54-3.34-10.72-8.6-10.72-3.26 0-3.6 1.4-3.6 4.44v11.66c0 3.05.34 4.45 3.6 4.45 5.25 0 8.6-3.74 8.6-9.83zm7.43 11.78c-.48 0-.81-.2-.81-.66 0-.98.89-.83 1.63-1.21 1.15-.52 1.22-1.79 1.22-3.43v-13.7c0-1.71-.03-3.02-1.42-3.57-1.01-.4-2.13-.2-2.13-1.23 0-.43.21-.66.63-.66h16.82c.77 0 1.06.33 1.06.98v3.53c0 .63-.22.9-.7.9-.97 0-.52-1.25-1.2-2.2s-2.07-1.25-5.48-1.25c-1.88 0-2.5.49-2.5 2.04v5.38c0 1.02.3 1.47 1.1 1.47h1.15c1.55 0 2.9-.2 3.63-1.06.86-1 .54-1.88 1.33-1.88a.59.59 0 0 1 .67.58v6.97a.68.68 0 0 1-.73.76c-.87 0-.58-.92-.99-1.86-.53-1.23-1.7-1.55-3.67-1.55h-1.38c-.94 0-1.1.53-1.1 1.96v5.7c0 1.55.57 2.04 3.1 2.04 3.56 0 4.7-.52 5.55-1.71s.83-2.37 1.8-2.37c.42 0 .6.24.5.85l-.6 3.55c-.2 1.15-.67 1.64-1.62 1.64H28.31zm44.15-.77c0 .57-.34.77-1.1.77h-3.92c-1.23 0-1.94-.5-2.76-1.9l-4.26-7.28a2.2 2.2 0 0 0-2.33-1.42h-.47c-1.02 0-1.3.28-1.3 1.27v3.83c0 1.83.44 2.98 1.38 3.54.78.46 1.67.41 1.67 1.3 0 .46-.2.66-.85.66h-9.34c-.48 0-.8-.2-.8-.66 0-.98.88-.83 1.75-1.25 1.02-.48 1.09-1.75 1.09-3.39v-13.7c0-1.7-.03-3.03-1.3-3.54-1.13-.45-2.25-.24-2.25-1.26 0-.43.21-.66.63-.66h11.64c5.3 0 8.28 2.25 8.28 6.44a6.66 6.66 0 0 1-3.65 5.98c-.34.19-.29.4.04.9l5 7.64c1.75 2.66 2.85 1.46 2.85 2.73zm-9.14-16.55c0-3.49-1.84-5.1-4.85-5.1-1.87 0-2.16.44-2.16 1.7v6.6c0 1.15.16 1.56 1.76 1.56h1.04c2.93 0 4.2-1.77 4.2-4.76zm22.45 18.74c-3.06 0-5.37-1.42-7.79-1.42-.84 0-1.17-.57-1.32-1.59l-.8-5.38c-.17-1.16-.14-2.08.84-2.08.8 0 .95.6 1.15 1.83.6 3.48 3.24 6.24 8.08 6.24 3.32 0 6.1-1.74 6.1-5.01 0-3.06-2.7-4.12-7.13-6-5.27-2.22-8.62-4.32-8.62-8.98C76.3 3.96 79.58 0 85.65 0c3.12 0 4.64.98 7.4 1.15a.9.9 0 0 1 .98.94c.04.54.56 6.24.56 6.7 0 .68-.25 1.04-.92 1.04-.96 0-1.11-.93-1.26-1.97-.51-3.74-3.19-5.74-6.85-5.74-3.23 0-5.25 1.88-5.25 4.36 0 2.15 1.75 3.58 5.8 5.25C91.5 14 96 15.67 96 21.41c0 6-4.62 9.68-10.24 9.66zm17.82-1.42c-.65 0-.96-.2-.96-.66.01-1 1.19-.83 2.36-1.26 1.38-.5 1.5-1.83 1.5-3.53V9.35c0-1.47-.21-1.84-2.33-1.84-2.85 0-3.76.12-4.28 1.6-.69 1.97-.35 2.6-1.37 2.6-.62 0-.83-.36-.83-1.1 0-.66.13-1.56.2-4.12.02-.86.13-1.3.74-1.3h20.84c.58 0 .73.44.73 1.3-.01 2.45.17 3.46.17 4.12 0 .74-.21 1.1-.83 1.1-1.02 0-.68-.63-1.37-2.6-.52-1.48-1.43-1.6-4.28-1.6-2.05 0-2.25.37-2.25 1.84v14.84c0 1.7.11 3.04 1.5 3.53 1.18.42 2.34.27 2.35 1.26 0 .46-.3.66-.95.66h-10.94zm15.21 0a.6.6 0 0 1-.7-.66c0-.8.92-.95 1.6-1.22 1-.4 1.43-1.27 2.13-2.85l8.88-20.14a.63.63 0 0 1 1.22 0l8.8 20.04c.7 1.59 1.18 2.36 2.12 2.85.7.37 1.6.52 1.6 1.26 0 .48-.26.72-.85.72h-9.34c-.43 0-.83-.24-.83-.62 0-.45.4-.78 1.23-.94 1.18-.22 1.24-.5 1.24-.9a6.73 6.73 0 0 0-.7-2.53l-.66-1.7c-.5-1.27-.47-1.66-2.2-1.66h-4.44c-1.46 0-2.09.01-2.73 1.59l-1.02 2.5a4.14 4.14 0 0 0-.32 1.26c0 1 .57 1.15 1.92 1.33 1.26.18 1.97.33 1.97 1.05a.56.56 0 0 1-.63.63h-8.29zm13.43-10.34a.47.47 0 0 0 .45-.53 3.29 3.29 0 0 0-.29-.98l-2.23-5.47c-.17-.4-.2-.48-.33-.48-.16 0-.19.07-.36.44l-2.24 5.51a3.72 3.72 0 0 0-.33.98.48.48 0 0 0 .49.53zM0 39.38v-2.15a.57.57 0 0 1 .62-.62H274.6a.57.57 0 0 1 .62.62v2.15a.57.57 0 0 1-.62.62H.62a.57.57 0 0 1-.62-.62zM167.96 30c-.58 0-1.28-.39-2.25-1.51L152.06 12.5c-.48-.55-.65-.7-.86-.7-.28 0-.32.25-.32.58v8.01c0 3.1.01 5.7 1.22 6.92s3.14.43 3.14 1.7a.55.55 0 0 1-.63.63h-8.3c-.49 0-.74-.2-.74-.66 0-.98 1.06-.76 1.8-1.59 1.12-1.27 1.14-2.88 1.14-6.1v-9.6c0-1.97-.06-3.35-.84-4.18-1.1-1.16-2.63-.53-2.63-1.69 0-.4.17-.65.53-.65h5.83c.98 0 1.26.4 2.16 1.46L164.9 19.9c.75.88 1.06 1.22 1.38 1.22.25 0 .41-.16.41-.61V13.8c0-3.08-.06-5.31-1.26-6.4-1.32-1.19-3.13-.4-3.13-1.66a.55.55 0 0 1 .62-.63h8.31c.5 0 .7.2.7.67 0 .97-1.09.72-1.84 1.53-1.06 1.14-1.12 2.5-1.12 5.65v16.03a.96.96 0 0 1-1.01 1.02zm5.6-1.03c0-.98.88-.84 1.63-1.18 1.02-.47 1.21-1.56 1.21-3.46v-13.7c0-1.71-.02-3.01-1.46-3.59-.97-.38-2.09-.2-2.09-1.21 0-.43.22-.66.63-.66h11.24c8.68 0 14.23 4.48 14.23 11.6 0 7.8-5.55 12.86-14.23 12.86h-10.36c-.48 0-.8-.2-.8-.66zm20.13-11.32c0-6.3-3.34-10.52-8.6-10.52-3.27 0-3.6 1.4-3.6 4.44v11.66c0 3.05.33 4.45 3.6 4.45 5.26 0 8.6-3.7 8.6-10.03zm4.97 11.98a.6.6 0 0 1-.7-.66c0-.8.91-.95 1.6-1.22 1-.4 1.43-1.27 2.13-2.85l8.87-20.14a.63.63 0 0 1 1.23 0l8.8 20.04c.7 1.59 1.18 2.36 2.12 2.85.69.37 1.6.52 1.6 1.26 0 .48-.26.72-.86.72h-9.33c-.44 0-.84-.24-.84-.62 0-.45.4-.78 1.23-.94 1.19-.22 1.24-.5 1.24-.9a6.73 6.73 0 0 0-.7-2.53l-.66-1.7c-.5-1.27-.46-1.66-2.2-1.66h-4.43c-1.46 0-2.08.01-2.72 1.59l-1.02 2.5a4.14 4.14 0 0 0-.33 1.26c0 1 .57 1.15 1.92 1.33 1.26.18 1.97.33 1.97 1.05a.56.56 0 0 1-.63.63h-8.28zm13.43-10.34a.47.47 0 0 0 .45-.53 3.29 3.29 0 0 0-.29-.98l-2.23-5.47c-.17-.4-.21-.48-.33-.48-.17 0-.2.07-.36.44l-2.25 5.51a3.72 3.72 0 0 0-.32.98.48.48 0 0 0 .48.53zm37.24 9.57c0 .57-.34.77-1.1.77h-3.91c-1.24 0-1.95-.5-2.76-1.9l-4.26-7.28a2.2 2.2 0 0 0-2.33-1.42h-.48c-1.02 0-1.3.28-1.3 1.26v3.83c0 1.84.45 2.99 1.4 3.55.76.46 1.66.41 1.66 1.3 0 .46-.2.66-.86.66h-9.34c-.48 0-.8-.2-.8-.66 0-.98.89-.83 1.76-1.25 1.02-.48 1.08-1.75 1.08-3.39v-13.7c0-1.71-.02-3.03-1.3-3.54-1.13-.45-2.24-.24-2.24-1.26 0-.43.2-.66.62-.66h11.65c5.3 0 8.27 2.25 8.27 6.44a6.66 6.66 0 0 1-3.64 5.98c-.34.19-.29.4.03.9l5 7.63c1.76 2.67 2.85 1.47 2.85 2.73zm-9.14-16.55c0-3.48-1.84-5.1-4.85-5.1-1.87 0-2.16.44-2.16 1.71v6.6c0 1.14.17 1.55 1.76 1.55h1.04c2.94 0 4.2-1.77 4.2-4.76zm10.16 16.67c0-.98.9-.84 1.64-1.18 1.02-.47 1.2-1.56 1.2-3.46v-13.7c0-1.72-.01-3.01-1.45-3.6-.97-.38-2.09-.2-2.09-1.2 0-.44.22-.67.63-.67h11.23c8.69 0 14.23 4.49 14.23 11.6 0 7.81-5.54 12.87-14.23 12.87h-10.35c-.48 0-.8-.2-.8-.66zm20.14-11.33c0-6.3-3.34-10.52-8.6-10.52-3.27 0-3.6 1.4-3.6 4.45v11.65c0 3.05.33 4.45 3.6 4.45 5.25 0 8.6-3.7 8.6-10.03z">
          </path>
        </symbol>
        <symbol id="symbol-brandicon" viewBox="75 0 42 40">
          <svg xmlns:xlink="http://www.w3.org/1999/xlink" width="276" height="40">
            <use xlink:href="#symbol-brandlogo"></use>
          </svg>
        </symbol>
        <symbol id="symbol-appicon" viewBox="0 0 28 28">
          <circle cx="14" cy="14" r="14" fill="var(--theme--primary)"></circle>
          <path
            d="M7.471 24.927a12.776 12.776 0 01-2.289-1.755h17.641a12.776 12.776 0 01-2.294 1.754zm-2.483-5.355c-.463 0-.61-.3-.7-.825l-.4-2.808c-.086-.616-.025-1.059.4-1.059s.485.315.59.949a3.906 3.906 0 004.224 3.251c1.816 0 3.37-.93 3.37-2.623s-1.478-2.3-3.928-3.318c-2.728-1.12-4.458-2.029-4.458-4.458s1.712-4.48 4.839-4.48c1.652 0 2.434.53 3.85.616.375.044.49.216.5.487s.3 3.146.3 3.485-.123.5-.462.5c-.487 0-.548-.443-.635-.991a3.423 3.423 0 00-3.589-3.023c-1.8 0-2.94 1.062-2.94 2.272s.993 2.03 3.233 2.94c2.85 1.139 5.134 1.712 5.134 4.815s-2.383 5.006-5.3 5.006c-1.64.002-2.778-.736-4.028-.736zm13.244-.006c-.314 0-.462-.1-.462-.338 0-.487.659-.424 1.311-.634.887-.3.887-1.04.887-1.841v-7.76c0-.758-.123-.949-1.33-.949-1.5 0-2.048.068-2.327.868-.357 1.016-.167 1.355-.7 1.355-.32 0-.425-.209-.425-.548s.061-.755.1-2.155c.024-.425.043-.678.382-.678h8.88a12.724 12.724 0 01.834 1.415 3.788 3.788 0 00-1.894-.257c-1.16 0-1.287.19-1.281.954v7.753c0 .806 0 1.561.887 1.841.659.21 1.293.148 1.311.634 0 .234-.154.338-.468.338z"
            fill="var(--theme--on-primary)"></path>
        </symbol>
      </svg>
      <nav id="top" role="navigation" aria-label="Sprungmarken"></nav>
      <a href="#roulette"><button class="app--header--sidebartoggle app--header--sidebartoggle-large">
          <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 34 34">
            <path
              d="M22.25 12h-10.5a.75.75 0 0 0 0 1.5h10.5a.75.75 0 0 0 0-1.5ZM15.904 16.904a6.496 6.496 0 0 0-.713.846H11.75a.75.75 0 0 1 0-1.5h4.918c-.27.197-.525.415-.764.654ZM14 21.5c0 .167.007.334.02.5h-2.27a.75.75 0 0 1 0-1.5h2.327a6.5 6.5 0 0 0-.077 1Z M25 21.5c0-2.5-2-4.5-4.5-4.5S16 19 16 21.5s2 4.5 4.5 4.5c.87 0 1.69-.25 2.38-.68L26 28.39 27.39 27l-3.08-3.1c.44-.69.69-1.52.69-2.4Zm-6.268-1.768a2.5 2.5 0 1 1 3.536 3.537 2.5 2.5 0 0 1-3.536-3.537Z"
              fill="currentcolor"></path>
          </svg>
        </button></a>
      <div class="app--header--content">
        <button class="app--header--sidebartoggle app--header--sidebartoggle-small btn_2" title="Menü anzeigen"
          aria-haspopup="true" aria-expanded="false">
          <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
            <path fill="currentColor"
              d="M17.75 19.75h14.5a.75.75 0 0 1 0 1.5h-14.5a.75.75 0 0 1 0-1.5ZM17.75 28.75h6.293a6.494 6.494 0 0 0 0 1.5H17.75a.75.75 0 0 1 0-1.5ZM17.75 25.75h7.44a6.496 6.496 0 0 1 1.477-1.5H17.75a.75.75 0 0 0 0 1.5Z M35 29.5c0-2.5-2-4.5-4.5-4.5S26 27 26 29.5s2 4.5 4.5 4.5c.87 0 1.69-.25 2.38-.68L36 36.39 37.39 35l-3.08-3.1c.44-.69.69-1.52.69-2.4Zm-6.268-1.768a2.5 2.5 0 1 1 3.536 3.537 2.5 2.5 0 0 1-3.536-3.537Z">
            </path>
          </svg>
        </button>
        <div class="app_header">
          <div class="app--header--selectapp">
            <a href="#roulette" class="app--header--branding brandlogo">
              <svg>
                <use xlink:href="#symbol-brandlogo"></use>
              </svg>
            </a>
            <button id="scrollButton" title="Anwendung wechseln" data-closable-target="app-selectapp">
              <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                <path fill="currentcolor" d="M21.94 23L25 26.06 28.06 23l.94.947-4 4-4-4z"></path>
              </svg>
            </button>
          </div>
          <div class="app--header--hero">
            <nav class="nav_app">
              <a href="#roulette" class="theme-supporter">Unterstützung</a>
              <a href="#roulette" class="theme-abo">Abo</a>
              <a href="#roulette" class="theme-immobilien">Immosuche</a>
              <a href="#roulette" class="theme-jobs">Jobsuche</a>
            </nav>
          </div>
          <div class="dst-useractions">
            <button title="Anmelden"><a href="#roulette"
                style="display: flex; text-decoration: none; padding: 0; margin:0;">
                <span class="anme">Anmelden</span>
                <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                  <path fill="currentcolor"
                    d="M33.5 22.5h-9.1a5.5 5.5 0 100 5h2.1l1.8-1.8 1.8 1.8 1.8-1.8 1.8 1.8L36 25zm-15.3 4.3A1.8 1.8 0 1120 25a1.8 1.8 0 01-1.8 1.8z">
                  </path>
                </svg></a>
            </button>
            <dst-flyout id="app-useractions"></dst-flyout>
            <div class="flyout--tabs"></div>
            <div class="app--header--useractions--menus u-scrollbar"></div>
          </div>
        </div>
        <dst-at-navigation>
          <div class="dst-navigation">
            <nav class="contextual contextual1">
              <div class="app--header--breadcrumb">
                <a href="#roulette" title="Gesundheit">Gesundheit</a>
                <a href="#roulette" title="Forschung">Forschung</a>
              </div>
              <a href="#roulette" class="nm1">International</a>
              <a href="#roulette" class="nm2">Inland</a>
              <a href="#roulette" class="nm3">Wirtschaft</a>
              <a href="#roulette" class="nm4">Web</a>
              <a href="#roulette" class="nm5">Sport</a>
              <a href="#roulette" class="nm6">Panorama</a>
              <a href="#roulette" class="nm7">Kultur</a>
              <a href="#roulette" class="nm8">Etat</a>
              <a href="#roulette" class="nm9">Wissenschaft</a>
              <a href="#roulette" class="nm10">Lifestyle</a>
              <a href="#roulette" class="nm11">Diskurs</a>
              <a href="#roulette" class="nm12">Karriere</a>
              <a href="#roulette" class="nm13">Immobilien</a>
              <a href="#roulette" class="nm14">Zukunft</a>
              <a href="#roulette" class="nm16">Recht</a>
              <a href="#roulette" class="nm17">Familie</a>
              <a href="#roulette" class="nm18">Bildung</a>
              <a href="#roulette" class="nm19">Reisen</a>
              <a href="#roulette" class="nm20">dieStandard</a>
              <a href="#roulette" class="nm21">Podcast</a>
              <a href="#roulette" class="nm22">Video</a>
              <div class="app--header--navigation--overflowcontainer">
                <a href="#roulette"><button type="button"
                    class="app--header--navigation--overflowtoggle dropdown-toggle">…</button></a>
              </div>
            </nav>
          </div>
        </dst-at-navigation>
      </div>
      <div class="fix" style="display:none;">
        <div class="app_header">
          <div class="app--header--selectapp" style="margin-right:0;">
            <a href="#roulette" class="app--header--branding app--header--branding-compact brandicon">
              <svg>
                <use xlink:href="#symbol-brandicon"></use>
              </svg>
            </a>
            <button id="scrollButton1" title="Anwendung wechseln" data-closable-target="app-selectapp">
              <a href="#roulette"> <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                  <path fill="currentcolor" d="M21.94 23L25 26.06 28.06 23l.94.947-4 4-4-4z"></path>
                </svg></a>
            </button>
          </div>
          <dst-at-navigation>
            <div class="dst-navigation">
              <nav class="contextual">
                <div class="app--header--breadcrumb">
                  <a href="#roulette" title="Gesundheit">Gesundheit</a>
                  <a href="#roulette" title="Forschung">Forschung</a>
                </div>
                <a href="#roulette">International</a>
                <a href="#roulette">Inland</a>
                <a href="#roulette">Wirtschaft</a>
                <a href="#roulette">Web</a>
                <a href="#roulette">Sport</a>
                <a href="#roulette" class="n4">Panorama</a>
                <a href="#roulette" class="n5">Kultur</a>
                <a href="#roulette" class="n6">Etat</a>
                <a href="#roulette" class="n7">Wissenschaft</a>
                <a href="#roulette" class="n8">Lifestyle</a>
                <a href="#roulette" class="n9">Diskurs</a>
                <a href="#roulette" class="n10">Karriere</a>
                <a href="#roulette" class="n11">Immobilien</a>
                <a href="#roulette" class="n12">Zukunft</a>
                <a href="#roulette" class="n13">Recht</a>
                <a href="#roulette" class="n14">Familie</a>
                <a href="#roulette" class="n15">Bildung</a>
                <a href="#roulette" class="n16">Reisen</a>
                <div class="app--header--navigation--overflowcontainer">
                  <a href="#roulette"><button type="button"
                      class="app--header--navigation--overflowtoggle dropdown-toggle">…</button></a>
                </div>
                <div class="dst-useractions">
                  <button title="Anmelden"><a href="#roulette"
                      style="display: flex; text-decoration: none; padding: 0; margin:0;">
                      <span class="anme">Anmelden</span>
                      <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                        <path fill="currentcolor"
                          d="M33.5 22.5h-9.1a5.5 5.5 0 100 5h2.1l1.8-1.8 1.8 1.8 1.8-1.8 1.8 1.8L36 25zm-15.3 4.3A1.8 1.8 0 1120 25a1.8 1.8 0 01-1.8 1.8z">
                        </path>
                      </svg></a>
                  </button>
                </div>
              </nav>
            </div>
          </dst-at-navigation>
        </div>
      </div>
      <div class="app--header--content tab" style="display:none;">
        <div class="tab_wrap">
          <div class="app_header">
            <button class="app--header--sidebartoggle app--header--sidebartoggle-small" title="Menü anzeigen"
              aria-haspopup="true" aria-expanded="false">
              <a href="#roulette"><svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                  <path fill="currentColor"
                    d="M17.75 19.75h14.5a.75.75 0 0 1 0 1.5h-14.5a.75.75 0 0 1 0-1.5ZM17.75 28.75h6.293a6.494 6.494 0 0 0 0 1.5H17.75a.75.75 0 0 1 0-1.5ZM17.75 25.75h7.44a6.496 6.496 0 0 1 1.477-1.5H17.75a.75.75 0 0 0 0 1.5Z M35 29.5c0-2.5-2-4.5-4.5-4.5S26 27 26 29.5s2 4.5 4.5 4.5c.87 0 1.69-.25 2.38-.68L36 36.39 37.39 35l-3.08-3.1c.44-.69.69-1.52.69-2.4Zm-6.268-1.768a2.5 2.5 0 1 1 3.536 3.537 2.5 2.5 0 0 1-3.536-3.537Z">
                  </path>
                </svg></a>
            </button>
            <div class="app--header--selectapp">
              <a href="#roulette" class="app--header--branding brandlogo">
                <svg>
                  <use xlink:href="#symbol-brandlogo"></use>
                </svg>
              </a>
              <button id="scrollButton2" title="Anwendung wechseln" data-closable-target="app-selectapp">
                <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                  <path fill="currentcolor" d="M21.94 23L25 26.06 28.06 23l.94.947-4 4-4-4z"></path>
                </svg>
              </button>
            </div>
            <div class="app--header--hero">
              <nav class="nav_app">
                <a href="#roulette" class="theme-supporter">Unterstützung</a>
                <a href="#roulette" class="theme-abo">Abo</a>
                <a href="#roulette" class="theme-immobilien">Immosuche</a>
                <a href="#roulette" class="theme-jobs">Jobsuche</a>
              </nav>
            </div>
            <div class="dst-useractions">
              <button title="Anmelden"><a href="#roulette"
                  style="display: flex; text-decoration: none; padding: 0; margin:0;">
                  <span class="anme">Anmelden</span>
                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
                    <path fill="currentcolor"
                      d="M33.5 22.5h-9.1a5.5 5.5 0 100 5h2.1l1.8-1.8 1.8 1.8 1.8-1.8 1.8 1.8L36 25zm-15.3 4.3A1.8 1.8 0 1120 25a1.8 1.8 0 01-1.8 1.8z">
                    </path>
                  </svg></a>
              </button>
              <dst-flyout id="app-useractions"></dst-flyout>
              <div class="flyout--tabs"></div>
              <div class="app--header--useractions--menus u-scrollbar"></div>
            </div>
          </div>
        </div>
        <dst-at-navigation>
          <div class="dst-navigation nw3">
            <nav class="contextual">
              <div class="app--header--breadcrumb">
                <a href="#roulette" title="Gesundheit">Gesundheit</a>
                <a href="#roulette" title="Forschung">Forschung</a>
              </div>
              <a href="#roulette">International</a>
              <a href="#roulette">Inland</a>
              <a href="#roulette">Wirtschaft</a>
              <a href="#roulette">Web</a>
              <a href="#roulette">Sport</a>
              <a href="#roulette">Panorama</a>
              <a href="#roulette">Kultur</a>
              <a href="#roulette">Etat</a>
              <a href="#roulette">Wissenschaft</a>
              <a href="#roulette">Lifestyle</a>
              <a href="#roulette">Diskurs</a>
              <a href="#roulette">Karriere</a>
              <a href="#roulette">Immobilien</a>
              <a href="#roulette">Zukunft</a>
              <a href="#roulette">Recht</a>
              <a href="#roulette">Familie</a>
              <a href="#roulette">Bildung</a>
              <a href="#roulette">Reisen</a>
              <a href="#roulette">dieStandard</a>
              <a href="#roulette">Podcast</a>
              <a href="#roulette">Video</a>
              <a href="#roulette">Mobilität</a>
              <a href="#roulette">Im Fokus</a>
            </nav>
          </div>
        </dst-at-navigation>
      </div>
    </header>
  </dst-header>
  <main id="main">
    <div class="layout">
      <div class="story js-story">
        <div id="ad-container-2" class="ad-container-used">
          <div>
            <div>
              <div class="baner_wrap">
                <a href="#roulette" style=" text-decoration:none; padding:0; margin: 0 auto;"><img loading="lazy"
                    src="./static/img/lg.png" alt="" class="image_baner"></a>
              </div>
            </div>
          </div>
        </div>
        <article class="story-article">
          <div class="article-header">
            <header>
              <h2 class="article-kicker">Neue Studie</h2>
              <h1 class="article-title">Alter-kein Hindernis für ein erfülltes Leben!
                105‑jährige
                Akademiker aus Japan erzählte, wie man die Sehkraft in&nbsp;jedem Alterzurückkehrt.</h1>
              <p class="article-subtitle"><strong><span class="inL_858381">Der berühmte
                    japanische
                    Augenarzt</span></strong><strong><span class="inL_914342">, Erfinder, Professor,
                    Akademiker, sowie Träger von vielen anderen medizinischen Preisen
                    Aretha Tanaka ging in den Ruhestand mit 90&nbsp;Jahren, aber weder in der Seele noch
                    körperlich wurde er keinen Rentner. Seit mehr als 10&nbsp;Jahren schreibt Professor Tanaka im
                    Ruhestand weiterhin Arbeiten im Gebiet der Augenheilkunde. Jetzt ist der Professor 105&nbsp;Jahre
                    alt,
                    und erst vor 3&nbsp;Jahren begann er, eine Brille zu&nbsp;tragen.</span></strong></p>
              <div class="article-byline">
                <div class="article-origins">
                  <span class="simple">Veröffentlicht um:</span>
                </div>
              </div>
              <div class="article-meta">
                <p class="article-pubdate">
                  <span class="startdate" format="dayF.monthF.year" daysago="2"></span> 06:00, </span><span
                    class="js-forum-postingcount">122
                    <span class="js-forum-postinglabel">Postings</span>
                </p>
                <p class="article-postingcount">
                  <button>
                    <span class="js-forum-postingcount">
                      <span class="js-forum-postinglabel"></span>
                    </span>
                  </button>
                </p>
              </div>
            </header>

            <div class="article-body">
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores voluptatibus rerum cupiditate porro sed ducimus quae, ex quas natus non dolor molestias. Impedit ab omnis ipsum soluta debitis in numquam!
                    Laboriosam, commodi saepe nulla, libero nihil nisi deserunt vel, quos illo ullam cupiditate! Dicta pariatur aut, aliquid dolorem rerum maxime quaerat totam necessitatibus, facere sed explicabo, dolore veritatis eligendi dolor!
                    Aut porro nostrum aperiam aspernatur quae, ullam commodi distinctio consequuntur ratione quaerat officia facilis incidunt ipsum voluptas, consectetur, explicabo tempore omnis eaque. Voluptas sunt quae nisi nam perspiciatis modi iure!
                    Vel possimus exercitationem rerum eligendi nemo officiis illum debitis quos. Consequatur consequuntur eum incidunt sint saepe voluptas cupiditate reprehenderit tenetur expedita provident, libero culpa totam neque quibusdam labore, inventore veritatis.
                    Aspernatur quasi corporis maiores officia autem quisquam eos expedita ad necessitatibus illo, corrupti voluptatum deserunt aperiam ab sed amet animi voluptatibus, quae similique ipsam! Natus fuga atque est exercitationem animi!
                    A consequuntur, repellat perspiciatis odio harum sit labore omnis eaque tenetur inventore est ab dolorum, vero incidunt ad nobis voluptates, distinctio optio. Illo suscipit magnam quos doloremque amet commodi asperiores!
                    Animi, ipsam. Qui, magnam! Magni earum illo, veniam expedita odit sint, repudiandae, ducimus cum reprehenderit sequi ab minus tempore laboriosam eius. Deleniti autem tenetur quam, dolores sunt labore sed tempora.
                    Officia temporibus labore ipsum inventore voluptate magnam beatae reiciendis minus vero eos obcaecati unde laborum, ut recusandae cum ab quidem explicabo consequatur, rerum veniam quibusdam accusantium nisi soluta. Vitae, harum.
                    Asperiores amet veniam minima perferendis incidunt doloribus iusto numquam quas totam vitae ab cupiditate provident laudantium voluptatem eum autem suscipit cum eos, aperiam assumenda aspernatur. Architecto suscipit molestiae iure quasi.
                    Atque nobis iure, voluptatibus sunt esse vel ipsa quo aliquam! Ipsam porro, eligendi quis neque deserunt optio totam quasi? Libero maiores, illo quas quia aspernatur natus possimus autem maxime ea?
                    Officiis at voluptatibus dignissimos recusandae laboriosam enim sequi impedit qui, dolorum neque sunt sit totam architecto minima id autem doloremque quos. Magnam distinctio expedita repellendus perspiciatis magni, dolore recusandae! Harum!
                    Atque error, tempore voluptatibus nihil corporis modi autem corrupti porro repellendus nam officia ad odio similique exercitationem ipsa inventore voluptate vel a ab hic. Omnis quia error sequi inventore nihil!
                    Magnam modi dolore cumque rerum atque, quia eum sunt doloribus dolorum in. Tempore quis debitis odit qui doloremque laudantium est, totam nobis distinctio dicta magni reiciendis deserunt molestias, vitae eveniet!
                    Laboriosam nulla sequi quasi, consequuntur labore sunt sed. Dolores, deleniti. Aspernatur eum dolor laboriosam iusto dicta repudiandae voluptas amet, dolores, corrupti aut necessitatibus! Magni delectus reprehenderit perspiciatis possimus, iure dignissimos.
                    Consequuntur beatae doloribus id saepe magnam expedita excepturi tenetur tempora consectetur officia? Pariatur aperiam sapiente explicabo amet asperiores, excepturi eveniet quod ea labore dolorum iure cupiditate eum velit iusto autem!
                    Sapiente amet ipsum rerum officia dolor totam hic soluta molestiae cum officiis repudiandae aliquam explicabo nostrum minima tenetur, voluptatem consequatur, eum adipisci quidem optio omnis ex itaque laudantium! Vel, ipsa.
                    At, repellat? Eum libero cupiditate itaque facere neque expedita dolores atque perferendis ullam pariatur ducimus, voluptatem perspiciatis error. Placeat alias aperiam dolores nam maiores debitis aliquam sapiente suscipit assumenda qui?
                    Laudantium repudiandae, beatae vel molestias modi, placeat facere a veritatis iusto reiciendis deserunt dignissimos consequatur explicabo labore cumque quas suscipit maxime perspiciatis harum expedita perferendis iure, laboriosam repellat ipsa? Ipsa.
                    Ratione animi, illo asperiores quos sint voluptatem, earum aspernatur possimus cumque itaque quod nobis vero alias, eos soluta praesentium libero quasi repellendus voluptate. Tenetur quam perferendis, veniam possimus molestiae sed.
                    Molestiae accusantium aspernatur nulla officiis ipsa nam impedit asperiores, tenetur consectetur cum id tempore libero fugit a eaque neque quod! Nostrum saepe laboriosam rerum repudiandae itaque dolore ullam fugit exercitationem!
                    Veritatis illum asperiores magni ab, ad dignissimos error? Architecto deserunt possimus cupiditate nam illo hic, unde accusantium tenetur est dolorem necessitatibus voluptates voluptate animi obcaecati? Tempore adipisci nemo provident dolorem.
                    Recusandae quam maiores sunt sit ea temporibus eveniet, autem corporis dolore voluptate possimus, modi tenetur eos odio atque voluptates assumenda? Maiores nam eius ea consequatur odio, necessitatibus praesentium atque sequi.
                    Adipisci, aut? Asperiores, nihil. Sed saepe placeat rerum quas totam temporibus! Vel asperiores accusantium, exercitationem similique vero molestiae nostrum quibusdam totam. Voluptates, porro ea corporis ut obcaecati soluta culpa optio.
                    Deserunt cum soluta voluptates sapiente voluptate eum maxime eius, placeat quod amet iure optio cumque ratione suscipit voluptatum at similique, voluptatibus ducimus debitis? Rerum ad reiciendis quis illum autem necessitatibus!
                    Laudantium a ea voluptas expedita excepturi cumque, quidem nesciunt quibusdam veritatis accusantium, laborum officiis eum ipsa corporis aspernatur adipisci sunt unde mollitia dolore deleniti rerum quis! Culpa quo et recusandae!
                    Ratione aliquid minima perspiciatis sequi modi quasi consectetur quidem provident ex dolor, voluptatem fugiat, accusantium minus dicta quisquam architecto cumque veritatis, corrupti quod magnam! Illo dignissimos dicta itaque molestias iste.
                    Quis possimus omnis sequi. Accusantium voluptatum consequuntur consectetur eaque. Dolorem, excepturi distinctio atque commodi, sit velit officiis assumenda officia, quibusdam hic quaerat beatae voluptatem non repellendus necessitatibus at ducimus accusantium!
                    Fuga ad maxime atque dolore nesciunt quas quia! Reprehenderit nihil amet ducimus natus veniam consequatur quo sapiente enim cum neque architecto error, magnam nisi aut excepturi tempora minus dolorem ex.
                    Unde, nulla quo! Consequatur quae molestiae hic, quibusdam corporis a iusto excepturi, nisi amet nostrum fuga temporibus velit, non odit reiciendis distinctio error dolores libero aliquid illum consequuntur. Totam, delectus!
                    Repellendus et cupiditate rerum. Reprehenderit nostrum quas nam quam eaque laborum molestias impedit suscipit quidem aliquid ullam omnis doloremque quaerat, rerum voluptatum voluptatibus beatae natus? Nemo dolorum repellat assumenda non.
                </p>
            </div>
          </div>
          <nav class="story-tool js-article-tool">
            <ul>
              <li class="js-article-tool-socialshare-menu story-tool-socialshare-menu"
                data-closable="story-tool-socialshare-menu" data-closable-active="false">
                <ul>
                  <li class="story-tool-sharetwitter js-article-tool-share">
                    <a href="#roulette" class="story-tool-button" title="Artikel auf Twitter teilen">
                      <svg viewBox="0 0 30 30">
                        <path fill="var(--tint)"
                          d="M12.35 24a12.24 12.24 0 0 0 12.32-12.32v-.56a8.81 8.81 0 0 0 2.15-2.24 8.65 8.65 0 0 1-2.49.68 4.35 4.35 0 0 0 1.9-2.4 8.68 8.68 0 0 1-2.75 1.05 4.33 4.33 0 0 0-7.38 3.95 12.3 12.3 0 0 1-8.92-4.52 4.33 4.33 0 0 0 1.34 5.78 4.3 4.3 0 0 1-1.97-.54v.05a4.33 4.33 0 0 0 3.48 4.25 4.32 4.32 0 0 1-1.96.07 4.34 4.34 0 0 0 4.05 3.01 8.7 8.7 0 0 1-5.38 1.86 8.82 8.82 0 0 1-1.03-.06A12.26 12.26 0 0 0 12.35 24" />
                      </svg>
                      <span>Artikel auf Twitter teilen</span>
                    </a>
                  </li>
                  <li class="story-tool-sharefacebook js-article-tool-share">
                    <a href="#roulette" class="story-tool-button" title="Artikel auf Facebook teilen">
                      <svg viewBox="0 0 30 30">
                        <path fill="var(--tint)"
                          d="M23.5 5.5h-17a1 1 0 0 0-1 1v16.9c0 .6.5 1 1 1h9.1V17h-2.5v-2.9h2.5V12c0-2.5 1.5-3.8 3.7-3.8 1 0 2 .1 2.2.1V11H20c-1.2 0-1.4.6-1.4 1.4v1.8h2.8l-.4 2.9h-2.5v7.4h4.8c.6 0 1-.5 1-1v-17c.2-.5-.3-1-.8-1z" />
                      </svg>
                      <span>Artikel auf Facebook teilen</span>
                    </a>
                  </li>
                  <li class="story-tool-sharewhatsapp js-article-tool-share">
                    <a href="#roulette" class="story-tool-button" title="Artikel auf WhatsApp teilen">
                      <svg viewBox="0 0 30 30">
                        <path fill="var(--tint)"
                          d="M23.79 6.13A11.07 11.07 0 0 0 6.36 19.48L4.8 25.22l5.87-1.54a11.05 11.05 0 0 0 5.28 1.35 11.07 11.07 0 0 0 7.84-18.9zm-7.83 17.03a9.18 9.18 0 0 1-4.68-1.28l-.34-.2-3.48.9.93-3.38-.22-.35a9.2 9.2 0 1 1 7.79 4.3zm5.04-6.9c-.28-.13-1.64-.8-1.89-.9s-.44-.13-.62.15-.71.9-.88 1.08-.32.2-.6.07a7.56 7.56 0 0 1-2.22-1.37 8.33 8.33 0 0 1-1.53-1.92c-.17-.27-.02-.42.12-.56s.27-.32.41-.48a1.89 1.89 0 0 0 .28-.46.5.5 0 0 0-.03-.49c-.07-.14-.62-1.5-.85-2.05s-.45-.47-.62-.48h-.53a1.02 1.02 0 0 0-.74.34 3.1 3.1 0 0 0-.97 2.3 5.38 5.38 0 0 0 1.13 2.87 12.32 12.32 0 0 0 4.72 4.17 15.88 15.88 0 0 0 1.58.58 3.79 3.79 0 0 0 1.74.11 2.85 2.85 0 0 0 1.87-1.31 2.31 2.31 0 0 0 .16-1.32c-.07-.11-.25-.18-.53-.32z" />
                      </svg>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="story-tool-forum" style="text-align: -webkit-match-parent;display: flex;">
                <a href="#roulette"><button class="story-tool-button" data-scrollto=".story-community-postings"
                    data-scrollto-offset="110" title="Kommentieren / Forum lesen">
                    <svg viewBox="0 0 30 30" class="icon-postings-v1">
                      <path fill="var(--tint)"
                        d="M4.95 9l4.9 4.9V22h14.6V9H4.95zm17.9 11.4h-11.4v-6.5c0-.4-.2-.8-.5-1.1l-2.1-2.1h14v9.7z" />
                    </svg>
                    <span>Kommentieren / Forum lesen</span>
                    <span class="js-forum-postingcount">122
                      <span class="js-forum-postinglabel">Postings</span>
                    </span>
                  </button></a>
              </li>
              <li class="story-tool-share" style="text-align: -webkit-match-parent;display: flex;">
                <a href="#roulette">
                  <button class="story-tool-socialshare js-article-tool-share story-tool-button" title="Artikel teilen"
                    data-closable-target="story-tool-socialshare-menu">
                    <svg viewBox="0 0 30 30">
                      <path fill="var(--tint)"
                        d="M21.3 19.3c-.8 0-1.5.3-2.1.8l-7.4-4.3c.1-.3.1-.5.1-.7 0-.3-.1-.5-.1-.8l7.4-4.3c.6.5 1.3.8 2.2.8 1.8 0 3.2-1.4 3.2-3.2s-1.4-3.2-3.2-3.2-3.2 1.4-3.2 3.2c0 .3 0 .5.1.8l-7.4 4.3c-.6-.5-1.3-.8-2.2-.8-1.8 0-3.2 1.4-3.2 3.2s1.4 3.2 3.2 3.2c.8 0 1.6-.3 2.2-.8l7.4 4.3c-.1.2-.1.4-.1.7 0 1.7 1.3 3.1 3.1 3.1s3.1-1.3 3.1-3.1-1.5-3.2-3.1-3.2z" />
                    </svg>
                  </button></a>
              </li>
              <li class="story-tool-share" style="text-align: -webkit-match-parent;display: flex;">
                <a href="#roulette">
                  <button class="story-tool-socialshare js-article-tool-share story-tool-button" title="Artikel teilen"
                    data-closable-target="story-tool-socialshare-menu">
                    <img src="./static/img/twitter.png" alt="" viewBox="0 0 24 24" loading="lazy">
                  </button></a>
              </li>
              <li class="story-tool-share" style="text-align: -webkit-match-parent;display: flex;">
                <a href="#roulette">
                  <button class="story-tool-socialshare js-article-tool-share story-tool-button" title="Artikel teilen"
                    data-closable-target="story-tool-socialshare-menu">
                    <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                      <path fill="currentColor"
                        d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96A10 10 0 0 0 22 12.06C22 6.53 17.5 2.04 12 2.04Z">
                      </path>
                    </svg>
                  </button></a>
              </li>
              <li class="story-tool-share" style="text-align: -webkit-match-parent;display: flex;">
                <a href="#roulette">
                  <button class="story-tool-socialshare js-article-tool-share story-tool-button" title="Artikel teilen"
                    data-closable-target="story-tool-socialshare-menu">
                    <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                      <path fill="currentColor"
                        d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z">
                      </path>
                    </svg>
                  </button></a>
              </li>
            </ul>
          </nav>
          <div class="ad-placeholder" style="height: 0; visibility: hidden; overflow: hidden;display:none"></div>
          <div class="site-sitebar ad">
            <div>
              <a href="#roulette" class="card card-main" id="tndr-card-main">
                <h2 style="color:red;text-align:center;margin: 0 auto 20px;">Sonderangebot</h2>
                <img loading="lazy" src="./static/comebacker_tube.png" alt=""
                  style="max-width:220px;width:100%;margin-left:18px;">
                <button class="buttom-button1">BESTELLUNG AUFGEBEN</button>
              </a>
            </div>
          </div>
        </article>
      </div>
    </div>
  </main>
  <footer class="site-footer">
    <div class="ft1">
      <div class="site-footer-legalline">
        <h2 class="site-footer-title">© STANDARD Verlagsgesellschaft m.b.H. <span class="nowyear"></span></h2>
        <p>
          Alle Rechte vorbehalten. Nutzung ausschließlich für den privaten Eigenbedarf.<br />Eine Weiterverwendung und
          Reproduktion über den persönlichen Gebrauch hinaus ist nicht gestattet.
        </p>
      </div>
      <div class="ft2" style="display:flex;">
        <nav class="site-footer-network-nav">
          <ul>
            <li style="list-style:none;">
              <a href="#roulette" title="derStandard.de">derStandard.de</a>
            </li>
            <li style="list-style:none;">
              <a href="#roulette" title="derStandard.at">derStandard.at</a>
            </li>
          </ul>
        </nav>
        <nav class="site-footer-legal-nav">
          <ul>
            <li style="display: flex;">
              <a href="#roulette">Impressum &amp;Offenlegung</a>
            </li>
            <li style="display: flex;">
              <a href="#roulette">Datenschutz</a>
            </li>
            <li style="display: flex;">
              <a href="#roulette">AGB</a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </footer>


  <script src="./static/dist/bundle.js"></script>
</body>

</html>