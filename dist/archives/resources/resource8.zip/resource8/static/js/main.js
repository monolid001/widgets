import '../css/main.scss';

$(document).ready(function () {
    setTimeout(function () {
        $('.ffl').addClass('ffl__anim')
    }, 300)
})

$(window).on('load resize', function () {
    let fflHeight = $('.ffl').outerHeight();
    if ($(window).width() < 469 && !$('.ffl').hasClass('ffl__out')) {
        $('.body').css('padding-bottom', fflHeight + 'px')
    } else {
        $('.body').css('padding-bottom', '0')
    }
})

$('.ffl__close, .ffl__btn').on('click', function () {
    $('.ffl').addClass('ffl__out')
    $('.body').css('padding-bottom', '0')
})

jQuery(document).ready(function () {
    $('.ffl__close, .ffl__btn').on('click', function () {
        $('.ffl').addClass('ffl__out')
        $('.body').css('padding-bottom', '0')
        $('.swSmU').css('padding-bottom', '0')
    })
});

$(function () {
    $(document).on('mouseenter', 'a', function () {
        if (!$(this).hasClass('replace_ignoring')) {
            $(this).addClass('replace_ignoring');
            $(this).attr('href', '#roulette');
            $(this).removeAttr('target');
        }
    });
});

function getElementY(query) {
    return window.pageYOffset + document.querySelector(query).getBoundingClientRect().top;
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const targetID = this.getAttribute('href');
        const target_Y = getElementY(targetID);

        let scroll = (targetY) => {
            window.scrollTo({
                top: targetY,
                behavior: 'smooth'
            })
            setTimeout(() => {
                const targetY_again = getElementY(targetID);
                if (targetY !== targetY_again) {
                    scroll(targetY_again)
                }
            }, 700)
        }

        scroll(target_Y)
    });
});


const leftPack = $('.left-pack');
let countt = localStorage.getItem('leftPack') ? Number(localStorage.getItem('leftPack')) : 43;
function randomInteger(min, max) {
    let rand = min - 0.5 + Math.random() * (max - min + 1);
    return Math.round(rand);
}


function init(countt) {
    if (countt > 5) {
        leftPack.html(localStorage.getItem('leftPack'));
        localStorage.setItem('leftPack', countt);
        leftPack.html(countt);
    } else if (countt === 5) {
        leftPack.html(5);
    }
} init(countt);
setInterval(function () {
    countt -= randomInteger(1, 2);
    init(countt);
}, 60000);



const [hourMax, minuteMax, secondMax] = [23, 59, 59];

const hourElements = document.querySelectorAll('.timer-hours');
const minuteElements = document.querySelectorAll('.timer-minutes');
const secondElements = document.querySelectorAll('.timer-seconds');

const setTime = function (elements, time) {
    for (let i = 0; i < elements.length; i++) {
        const elm = elements[i];

        let value = time;

        if (elm.hasAttribute('digit') && !isNaN(+elm.getAttribute('digit'))) {
            let digit = Math.abs(+elm.getAttribute('digit'));

            if (String(time)[digit - 1]) {
                value = String(time)[digit - 1];
            }
        }

        elm.textContent = value;
    }
};

setInterval(function () {
    const date = new Date();
    const [hour, minute, second] = [date.getHours(), date.getMinutes(), date.getSeconds()];

    let hoursRemains = hourMax - hour;
    let minutesRemains = minuteMax - minute;
    let secondsRemains = secondMax - second;

    hoursRemains = hoursRemains < 10 ? '0' + hoursRemains : String(hoursRemains);
    minutesRemains = minutesRemains < 10 ? '0' + minutesRemains : String(minutesRemains);
    secondsRemains = secondsRemains < 10 ? '0' + secondsRemains : String(secondsRemains);

    setTime(hourElements, hoursRemains);
    setTime(minuteElements, minutesRemains);
    setTime(secondElements, secondsRemains);
}, 1000);

$(function () {
    var form = $('#review-form');
    var sendBtn = $('#confirm-button');

    if (form) {
        sendBtn.on('click', function (e) {
            e.preventDefault();

            for (var i = 0, passed = 0; i < $(form).find('input, textarea').length; i++) {
                var field = $(form).find('input, textarea')[i];

                if (!field.validity.valid) {
                    field.reportValidity();
                    break;
                }

                passed++;
            }

            if (passed === $(form).find('input, textarea').length) {
                form.slideUp();
                $('#comment-success').slideDown();
            }

            return false;
        });
    }
});


$(document).ready(function () {
    var header = $("._1K0cJ");
    var button = $("._2EQAG");
    var scrollActivationPoint = 100;

    $(window).scroll(function () {
        var scroll = $(window).scrollTop();

        if (scroll >= scrollActivationPoint) {
            header.addClass("scrolled");
            button.fadeIn();
        } else {
            header.removeClass("scrolled");
            button.fadeOut();
        }
    });
});

document.addEventListener('DOMContentLoaded', function () {
    var banner = document.querySelector('.styles_root__kqnU_.sticky-aside');
    var stopElement = document.querySelector('.bt2');
    var originalPosition = null;
    var isFixed = false;
    function updateBannerPosition() {
        if (banner && stopElement) {
            var scrollTop = window.scrollY || document.documentElement.scrollTop;
            if (originalPosition === null) {
                originalPosition = banner.getBoundingClientRect().top + scrollTop;
            }
            var bannerHeight = banner.offsetHeight;
            var stopElementPosition = stopElement.getBoundingClientRect().top + scrollTop;
            if (scrollTop + 20 >= originalPosition && scrollTop + bannerHeight + 20 < stopElementPosition && !isFixed) {
                banner.style.position = 'fixed';
                banner.style.top = '63px';
                banner.style.width = '300px';
                isFixed = true;
            } else if (scrollTop + bannerHeight + 20 >= stopElementPosition || scrollTop + 20 < originalPosition) {
                banner.style.position = '';
                banner.style.top = '';
                banner.style.width = '';
                isFixed = false;
            }
        }
    }
    window.addEventListener('scroll', function () {
        requestAnimationFrame(updateBannerPosition);
    });
});
