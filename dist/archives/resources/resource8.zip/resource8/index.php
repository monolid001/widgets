<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Не ждите беды: очищение сосудов&nbsp;– ключ к здоровому сердцу и избавлению от хронических
        заболеваний</title>
    
    <link rel="stylesheet" href="static/dist/bundle.css">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>
<body class="body">

<div id="__next">
    <div class="CommonLayout_wrapper__2H1ME">
        <div id="app-scroll-trigger" style="position:absolute;left:0;top:150vh"></div>
        <div class="styles_root__kqnU_ styles_root__3qXe-" style="display:flex"></div>
        <div class="CommonLayout_root__3Kkv6">
            <div class="styles_root__3L8X1">
                <div class="app_content_wrapper styles_wrapper__3fxYZ">
                    <div class="styles_content__121VY">
                        <div class="styles_logo__11e-T" id="/p_block=header-logo">
                            <div class="styles_root__2bZ38"><a href="#roulette"><svg
                                            style="cursor:pointer;color:#FF0A0A" width="74" height="28"
                                            viewBox="0 0 74 28" fill="#FF0A0A" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                                d="M7.863 0H0v28h19v-6.292H7.863V0zM22 28h9V0h-9v28zm12 0h7.877V16.943h8.746v-6.292h-8.746V6.292H53V0H34v28zM55 0v28h19v-6.293H62.77v-4.764h8.911V10.65H62.77V6.255H74V0H55z"
                                                fill-rule="evenodd" clip-rule="evenodd"></path>
                                    </svg></a>
                            </div>
                            <div class="styles_lightning__2JQDr"><a href="#roulette"><svg width="25" height="24"
                                                                                          viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.167 3L6.5 13.262h4.333V21L18.5 10.57h-4.333V3z" fill="#424242">
                                        </path>
                                    </svg></a></div>
                        </div>
                        <div class="styles_right__2tmiH">
                            <div class="styles_region__TO5dp" id="/p_block=header-region">
                                <div class="styles_container__1rhgd">
                                    <a href="#roulette">
                                        <div class="styles_root__7WgoU"><svg class="" width="20" height="20"
                                                                             viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10 10.833a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
                                                      stroke="#9A9A9A" stroke-width="1.5" stroke-linecap="round"
                                                      stroke-linejoin="round"></path>
                                                <path
                                                        d="M10 18.083c4.417-3.916 6.667-7.25 6.667-9.75a6.666 6.666 0 1 0-13.334 0c0 2.5 2.25 5.75 6.667 9.75z"
                                                        stroke="#9A9A9A" stroke-width="1.5" stroke-linecap="round"
                                                        stroke-linejoin="round"></path>
                                            </svg>
                                            <div class="styles_wrapperTitle__4cbBJ"><span
                                                        style="letter-spacing:normal"
                                                        class="Text_root__1rV-_ Text_size-normal-xs__3GI8j Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-medium__2bDOk Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M styles_title__E4V2B">Регион</span>
                                            </div>
                                        </div>
                                </div></a>
                            </div>
                            <div class="styles_theme__3TCbN" id="/p_block=header-theme">
                                <a href="#roulette">
                                    <div class=""><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                       xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M17.727 10.454c-.13 1.419-.922 2.975-1.794 4.102A7.5 7.5 0 1 1 9.31 2.5a5.833 5.833 0 0 0 8.158 8.158l.26-.204z"
                                                    stroke="#9A9A9A" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round"></path>
                                        </svg></div>
                                </a>
                            </div>
                            <div class="styles_follow__UH3vh" id="/p_block=header-follow">
                                <a href="#roulette">
                                    <div class="styles_root__2bZ38"><svg class="styles_icon__jHs1O" width="20"
                                                                         height="20" viewBox="0 0 20 20" fill="none"
                                                                         xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                    d="M17.367 3.842a4.583 4.583 0 0 0-6.483 0L10 4.725l-.883-.883a4.584 4.584 0 1 0-6.483 6.483l.883.883L10 17.692l6.484-6.484.883-.883a4.584 4.584 0 0 0 0-6.483z"
                                                    stroke="#9A9A9A" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round"></path>
                                        </svg>
                                        <div class="styles_content__2-bRZ styles_bottom__NMJNi styles_right__Ic7F4">
                                            <div class="styles_listBackground__2D2VL">
                                                <ul class="styles_list__wkiI4">
                                                    <li class="styles_item__Xa6mw"><a href="#roulette"
                                                                                      title="Life Вконтакте" target="_blank"
                                                                                      rel="noopener noreferrer" class="jsx-3833067127"><svg
                                                                    class="jsx-3833067127 icon" width="20" height="20"
                                                                    viewBox="0 0 20 20"
                                                                    xmlns="http://www.w3.org/2000/svg" fill="#5181B8">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                      d="M13.07 0H6.93C1.327 0 0 1.327 0 6.93v6.14C0 18.673 1.327 20 6.93 20h6.14c5.603 0 6.93-1.327 6.93-6.93V6.93C20 1.327 18.66 0 13.07 0zm3.077 14.27h-1.454c-.55 0-.72-.438-1.708-1.44-.86-.833-1.242-.946-1.454-.946-.296 0-.38.085-.38.494v1.313c0 .353-.114.564-1.045.564-1.539 0-3.246-.931-4.446-2.667-1.807-2.54-2.3-4.446-2.3-4.841 0-.212.084-.41.493-.41h1.454c.367 0 .508.17.65.565.72 2.075 1.919 3.895 2.413 3.895.183 0 .268-.084.268-.55V8.102c-.056-.988-.579-1.073-.579-1.426 0-.17.141-.339.367-.339h2.287c.31 0 .423.17.423.537v2.893c0 .31.141.424.226.424.184 0 .339-.113.678-.452 1.044-1.172 1.792-2.978 1.792-2.978.099-.212.268-.41.635-.41h1.454c.438 0 .536.226.438.537-.184.847-1.962 3.359-1.962 3.359-.156.254-.212.367 0 .65.155.211.663.649 1.002 1.044.62.705 1.1 1.298 1.228 1.708.14.409-.07.62-.48.62z">
                                                                </path>
                                                            </svg></a></li>
                                                    <li class="styles_item__Xa6mw"><a href="#roulette"
                                                                                      title="Life Telegram" target="_blank"
                                                                                      rel="noopener noreferrer" class="jsx-59187528"><svg
                                                                    class="jsx-59187528 icon" width="21" height="18"
                                                                    viewBox="0 0 21 18"
                                                                    xmlns="http://www.w3.org/2000/svg" fill="#039BE5">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                      d="M10.424 14.155l.631-.61h.002l.085.061c.047.033.091.063.135.097l1.642 1.204c.931.683 1.863 1.367 2.797 2.049.853.624 1.601.344 1.835-.679l.005-.025 1.062-4.967c.602-2.815 1.204-5.63 1.804-8.447l.091-.414c.098-.437.196-.874.235-1.316.077-.883-.563-1.322-1.388-1.006l-8.166 3.13-4.739 1.816-1.402.536c-1.322.504-2.643 1.009-3.96 1.525a3.384 3.384 0 0 0-.901.531c-.288.24-.242.568.072.777.186.116.388.205.599.267 1.405.443 2.813.88 4.224 1.309.162.035.29.16.328.322.316.979.636 1.957.955 2.935.283.865.566 1.73.846 2.596.082.252.231.37.498.384.393.022.701-.126.974-.393.575-.562 1.153-1.12 1.736-1.682zm-2.621.71l-.021.09H7.78l-.045-.108a1.803 1.803 0 0 1-.05-.126l-.37-1.13c-.392-1.2-.785-2.4-1.186-3.597-.068-.202-.02-.29.15-.396 1.428-.891 2.854-1.784 4.28-2.676 1.902-1.19 3.803-2.38 5.707-3.568.173-.105.36-.184.555-.236.057-.015.128.013.198.041.031.013.062.026.092.034a1.023 1.023 0 0 0-.03.089c-.022.068-.044.136-.09.178-.43.394-.865.784-1.301 1.174l-.606.542-1.657 1.485c-1.687 1.512-3.374 3.024-5.067 4.53a.743.743 0 0 0-.26.543c-.067.82-.144 1.639-.222 2.457l-.052.56a.811.811 0 0 1-.023.114z">
                                                                </path>
                                                            </svg></a></li>
                                                    <li class="styles_item__Xa6mw"><a href="#roulette"
                                                                                      title="Life ОК" target="_blank"
                                                                                      rel="noopener noreferrer" class="jsx-635468258"><svg
                                                                    class="jsx-635468258 icon" width="12" height="20"
                                                                    viewBox="0 0 12 20"
                                                                    xmlns="http://www.w3.org/2000/svg" fill="#EE8208">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                      d="M11 5a5 5 0 0 1-5 5 5.006 5.006 0 0 1-5-5 5 5 0 1 1 10 0zM8.5 5a2.5 2.5 0 1 0-5 0 2.5 2.5 0 0 0 5 0z">
                                                                </path>
                                                                <path
                                                                        d="M11.094 13.992A1.88 1.88 0 0 0 12 12.403a1.366 1.366 0 0 0-.814-1.252 1.593 1.593 0 0 0-1.6.143c-2.137 1.473-5.035 1.473-7.172 0a1.601 1.601 0 0 0-1.6-.143c-.504.234-.82.72-.814 1.252.001.64.342 1.236.907 1.588a9.474 9.474 0 0 0 2.343 1.06c.141.04.287.079.436.114L1.27 17.401a1.455 1.455 0 0 0-.034 2.139 1.666 1.666 0 0 0 2.301-.005L6 17.124 8.47 19.54c.615.6 1.628.615 2.262.034a1.455 1.455 0 0 0-.003-2.177l-2.414-2.233c.15-.036.296-.075.438-.115a9.445 9.445 0 0 0 2.341-1.057z">
                                                                </path>
                                                            </svg></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="styles_notification__3i9H2" id="/p_block=header-notification">
                                <a href="#roulette">
                                    <div class="styles_root__2bZ38"><button
                                                class="styles_root__1lEzr styles_isHeader__1996v" type="button"><svg
                                                    width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                      d="M18.38 14.548c-1.626-1.407-3.13-3.391-3.13-8.345A5.21 5.21 0 0 0 10.045 1a5.21 5.21 0 0 0-5.204 5.203c0 4.958-1.504 6.94-3.132 8.346A2.06 2.06 0 0 0 1 16.102c0 .327.265.592.592.592h5.617A2.903 2.903 0 0 0 10.046 19a2.903 2.903 0 0 0 2.836-2.306H18.5a.592.592 0 0 0 .591-.592c0-.599-.26-1.166-.71-1.554zm-8.334 3.268a1.717 1.717 0 0 1-1.609-1.122h3.217a1.717 1.717 0 0 1-1.608 1.122zm-7.56-2.373a.87.87 0 0 0-.07.067h15.26a.897.897 0 0 0-.069-.066c-2.483-2.147-3.542-4.91-3.542-9.241a4.024 4.024 0 0 0-4.019-4.02 4.024 4.024 0 0 0-4.02 4.02c0 4.334-1.059 7.098-3.54 9.24z"
                                                      stroke="#9A9A9A" stroke-width=".6" fill="#9A9A9A"></path>
                                            </svg></button>
                                        <div class="styles_content__2-bRZ styles_bottom__NMJNi styles_right__Ic7F4">
                                            <p class="styles_root__8aOtz">Уведомления отключены</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="styles_user__2pkeq" id="/p_block=header-profile">
                                <a href="#roulette"><button class="styles_root__2MISd" type="button"><svg class=""
                                                                                                          width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                                                                          xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M12.15 11.16c1.35-1.44 2.25-3.6 2.25-5.76C14.4 2.43 11.97 0 9 0S3.6 2.43 3.6 5.4c0 2.16.9 4.32 2.25 5.76-1.815.33-3.554 1.038-5.356 2.054a.98.98 0 0 0-.494.857v2.219c0 .472.33.882.794.97 2.72.516 5.5.74 8.206.74 2.706 0 5.487-.224 8.206-.74a.982.982 0 0 0 .794-.97v-2.22a.98.98 0 0 0-.494-.856c-1.802-1.016-3.541-1.724-5.356-2.054zM5.4 5.4c0-1.98 1.62-3.6 3.6-3.6s3.6 1.62 3.6 3.6c0 2.7-1.8 5.4-3.6 5.4S5.4 8.1 5.4 5.4zm10.8 10.17c-2.43.36-4.86.63-7.2.63-2.43 0-4.77-.18-7.2-.63v-1.08c2.43-1.26 4.86-1.98 7.2-1.98s4.77.63 7.2 1.98v1.08z"
                                                  fill="#9A9A9A"></path>
                                        </svg></button></a>
                            </div>
                            <a href="#roulette">
                                <div class="styles_search__2-2ML" id="/p_block=header-search"><svg width="18"
                                                                                                   height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M18 16.701l-4.918-4.918C14.01 10.578 14.66 9 14.66 7.33 14.66 3.34 11.412 0 7.33 0A7.286 7.286 0 0 0 0 7.33a7.286 7.286 0 0 0 7.33 7.33c1.67 0 3.247-.557 4.454-1.578L16.7 18 18 16.701zM7.5 13C4.424 13 2 10.556 2 7.547 2 4.444 4.424 2 7.5 2 10.483 2 13 4.444 13 7.547 12.907 10.556 10.483 13 7.5 13z">
                                        </path>
                                    </svg></div>
                            </a>
                        </div>
                        <div class="styles_menu__21CHx"><a href="#roulette"><button id="burgerMenu"
                                                                                    class="burger-menu styles_root__1jT3Y" type="button"><span
                                            class="styles_icon__cNGCI"></span></button></a></div>
                    </div>
                </div>
            </div>
            <div class="main styles_contentWrapper__DiQKK">
                <div class="main-container styles_content__1DvHl">
                    <div class="container rebild">
                        <div>
                            <h1 class="styles_title__1Tc08">Не ждите беды: очищение сосудов&nbsp;– ключ к
                                здоровому сердцу и
                                избавлению от хронических&nbsp;заболеваний</h1>

                            <time class="VHduO _2Yn0N styles_meta__3gXff"><span
                                        class="startdate styles_metaItem__1aUkA" format="dayI&nbsp;monthS year" daysago="5"></span>
                            </time>
<!--                            <h2 class="_3j3bx _2zYE5 _1CM5L">-->
                                <div class="styles_itemWrap__1xl9u">
                                    <p class="styles_subtitle__3I1PB"
                                       style="margin-bottom:15px;"><strong>ИЗВЕСТНЫЙ ВРАЧ РАССКАЗАЛ О
                                                ПРОСТОМ&nbsp;МЕТОДЕ.</strong></p>
                                </div>
                                <div class="styles_itemWrap__1xl9u">
                                    <p class="styles_subtitle__3I1PB"
                                       style="margin-bottom:0;">
                                        <strong>Узнайте, как избавиться от&nbsp;гипертонии всего за&nbsp;месяц
                                                и вылечить 9&nbsp;из 10&nbsp;«неизлечимых» заболеваний.</strong>
                                    </p>
                                </div>
                                <div class="div-block-2 _2x6gg"
                                     style="width: 100%;max-width: 1400px;height: auto;margin-bottom:-20px;align-items: flex-start; background-color: #fff;">
                                    <div class="div-block-3">
                                        <img alt="" class="image"
                                             src="static/images/6086c6067e67b1220a7eef4e_5eddfdf0ad2c2afcfb7139e6_5e5951628870165244d16c2d_br.png"
                                             loading="lazy" style="width:38px;">
                                        <div class="text-block-2 lt10">Почему загрязнение сосудов смертельно&nbsp;опасно?
                                        </div>
                                    </div>
                                    <div class="div-block-3">
                                        <img alt="" class="image"
                                             src="static/images/6086c6067e67b1220a7eef4e_5eddfdf0ad2c2afcfb7139e6_5e5951628870165244d16c2d_br.png"
                                             loading="lazy" style="width:38px;">
                                        <div class="text-block-2 lt11">Какие отложения
                                            повреждают&nbsp;сосуды?
                                        </div>
                                    </div>
                                    <div class="div-block-3">
                                        <img alt="" class="image"
                                             src="static/images/6086c6067e67b1220a7eef4e_5eddfdf0ad2c2afcfb7139e6_5e5951628870165244d16c2d_br.png"
                                             loading="lazy" style="width:38px;">
                                        <div class="text-block-2 lt12">Симптомы и последствия нарушения
                                            кровообращения.
                                        </div>
                                    </div>
                                    <div class="div-block-3" style="margin-bottom:0;">
                                        <img alt="" class="image"
                                             src="static/images/6086c6067e67b1220a7eef4e_5eddfdf0ad2c2afcfb7139e6_5e5951628870165244d16c2d_br.png"
                                             loading="lazy" style="width:38px;">
                                        <div class="text-block-2">
                                            Безопасный метод самостоятельной очистки
                                                сосудов.
                                        </div>
                                    </div>
                                </div>
                                <div class="paragraph">
                                    На эти вопросы ответил известный врач&#8209;кардиолог, член
                                        Европейской ассоциации сердечного ритма&nbsp;– Александр Леонидович Мясников.
                                </div>
                                <img alt="" class="ma"
                                     src="static/images/dottor-Mozzi-e1417521140768-750x400.jpg"
                                     loading="lazy" style="margin:0 auto 20px; width: 100%;">
                                <p class="paragraph lt15 styles_description__3MXZh">Александр Леонидович вылечил более 5000&nbsp;пациентов с различными сердечно&#8209;сосудистыми заболеваниями.</p>
                                <p class="paragraph lt15">Он абсолютно убежден, что наши кровеносные
                                    сосуды являются источником 90%&nbsp;проблем организма, и наше
                                    благополучие зависит от их&nbsp;состояния.</p>
<!--                            </h2>-->
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY" >Почему загрязнение&nbsp;сосудов смертельно&nbsp;опасно?</h2>
                            <p class="paragraph lt17"><strong>Александр Леонидович, вы
                                    считаете, что здоровье организма на&nbsp;90% зависит от&nbsp;сосудов.
                                    Почему?</strong></p>
                            <p class="paragraph lt15">Какой орган самый большой в теле человека?
                                Это не&nbsp;печень и даже не&nbsp;кожа. Самый большой орган&nbsp;– это наша сердечно&#8209;сосудистая
                                система.
                            </p>

                            <img alt="" class="ma"
                                 src="static/images/6086c6067e67b102097eef55_5eddfdf0ad2c2aa2f37139c3_5e558a6caacc1f50a3a007b5_s_3.jpg"
                                 width="315" loading="lazy" style="margin:0 auto 15px;">
                            <p class="_2x6gg styles_description__3MXZh" style="margin: 15px auto 30px 0;">
                                Длина кровеносной
                                    системы человека вместе с артериями, венами и капиллярами
                                    составляет примерно 100&nbsp;000&nbsp;км&nbsp;– это в 2,5&nbsp;раза превышает длину
                                    экватора&nbsp;Земли.
                            </p>

                            <p class="paragraph lt15">Кровеносные сосуды&nbsp;– это не&nbsp;просто
                                каналы, по которым течет кровь. От их состояния зависит здоровье
                                всего организма. Снижение эластичности и проходимости сосудов
                                приводит&nbsp;к:
                            <p class="paragraph lt15"><strong>– нарушению кровообращения в
                                        ногах:</strong> варикозное расширение вен,
                                    стойкие отеки и постоянное чувство тяжести в&nbsp;ногах, онемение
                                    или, наоборот, нестерпимое жжение в&nbsp;ступнях;</p>
                            <p class="paragraph lt15"><strong>– закупорке сосудов
                                        печени:</strong> гепатит, горечь
                                        во&nbsp;рту;</p>
                            <p class="paragraph lt15"><strong>– ухудшению кровоснабжения суставов:</strong> 
                                    разрушение хрящей с
                                    развитием остеохондроза и&nbsp;грыж;</p>
                            <p class="paragraph lt15"><strong>– нарушению кровообращения в органах
                                        малого&nbsp;таза:</strong> снижение потенции, простатит;</p>
                            
                            <p class="paragraph lt15"><strong>– ослаблению и воспалению
                                        сосудов прямой кишки:</strong> геморрой;</p>
                            
                            <p class="paragraph lt15"><strong>– воспалению глазных кровеносных
                                        сосудов:</strong> снижение зрения и появление
                                    мушек, катаракта, покраснение глаз и микрокровоизлияния;</p>
                            
                            <p class="paragraph lt15"><strong>– нарушению мозгового
                                        кровообращения:</strong> головокружение, звон в
                                    ушах и забывчивость&nbsp;– лишь некоторые из симптомов.
                                    Зайти в комнату и забыть, зачем вы это сделали. Или когда часто используемое слово
                                    вертится на кончике языка, но вы не&nbsp;в состоянии его&nbsp;вспомнить.
                                    Все это признаки ухудшения состояния сосудов
                                    головного&nbsp;мозга.</p>
                            <p class="paragraph _2x6gg fr">
                                <strong class="lt21">И, конечно же, самая
                                    распространенная сердечно&#8209;сосудистая проблема&nbsp;– высокое
                                    кровяное давление. В&nbsp;84% случаев именно гипертония становится причиной инсультов и
                                    инфарктов. </strong>
                            </p>
                            <p class="paragraph lt22">Поэтому я не устаю повторять: если вы
                                хотите <strong>вести здоровую и полноценную жизнь,</strong> вы&nbsp;должны <strong>очищать
                                    свои кровеносные сосуды.</strong></p>

                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Какие отложения повреждают сосуды?</h2>

                            <img alt="" class="ma"
                                 src="static/images/6086c6067e67b196d87eef4f_5eddfdf0ad2c2a08717139c7_5e558a6caacc1f34b8a007c9_tr_3.jpg"
                                 width="315" loading="lazy"
                                 style="margin:0 auto 15px;width:100%;">
                            <div class="styles_description__3MXZh" >
                                6,5&nbsp;кг общая масса примесей, накопленных в кровеносных сосудах к 50&nbsp;годам.
                            </div>
                            <p class="paragraph lt30">Из них 5&nbsp;кг&nbsp;– <strong class="lt27" style="font-size:20px;">холестерин.</strong>
                                Он блокирует кровеносные сосуды, сужая их просвет в 4&#8209;5&nbsp;раз и нарушая кровоток. В
                                результате повышается артериальное давление, появляются мигрени, боли в суставах, быстрая
                                утомляемость и&nbsp;апатия.
                            </p>
                            <p class="paragraph _2x6gg" >
                                <strong class="lt31">Нормальный диаметр
                                    венозного просвета обычно равен диаметру пальца. 5&nbsp;кг холестериновых бляшек могут
                                    уменьшить
                                    просвет всего до 4&nbsp;мм.</strong>
                            </p>

                            <p class="paragraph lt34"><strong class="lt27" style="font-size:20px;">Сгустки
                                    крови.</strong> Отложения в виде сгустков крови могут
                                достигать «всего» 800&nbsp;граммов, максимум&nbsp;– 1&nbsp;кг. Но
                                реальная опасность в их нестабильности. Тромб может в любой момент оторваться от стенки
                                сосуда и начать циркулировать по кровеносной системе.</p>
                            <p class="paragraph">Если тромб достаточно большой, он может
                                закупорить вену и вызвать ишемию&nbsp;– полное прекращение притока
                                крови к органу, обслуживаемому этим&nbsp;сосудом.</p>
                            <p class="paragraph">Ишемический инсульт, вызываемый
                                закупоркой кровеносного сосуда в ногах, приводит к
                                некрозу и&nbsp;гангрене.</p>
                            <p class="paragraph lt36"><strong class="lt27" style="font-size:20px;">Фосфат
                                    кальция.</strong> Фосфат кальция в сосудах&nbsp;– это
                                остатки химических препаратов и пищевых добавок. К 50&nbsp;годам
                                в сосудах головного мозга может накапливаться до
                                <strong>300&#8209;400&nbsp;граммов таких отложений.</strong>
                            </p>
                            <p class="paragraph">Опасность фосфата кальция в том, что он имеет
                                острую кристаллическую структуру. В результате даже небольшой спазм сосуда, вызванный
                                стрессом или физической нагрузкой, может привести к перфорации и разрыву сосуда. Разрыв
                                церебрального
                                сосуда приводит к геморрагическому инсульту.</p>
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Симптомы и последствия нарушения кровообращения</h2>
                            <ul style="padding-left: 22px;">
                                <li class="list-item"><strong class="lt51">Головная боль.<br></strong><span
                                            class="si">Сужение просвета сосудов приводит к нарушению кровообращения и кислородному голоданию. Как&nbsp;следствие&nbsp;– постоянные головные боли и риск&nbsp;инсульта.</span>
                                </li>

                                <li class="list-item"><strong class="lt53">Звон в
                                        ушах.<br></strong><span class="si">От едва слышимого
                                                            свиста до визжащего шума, нарушающего
                                                            концентрацию. Это результат повышенного давления в
                                                            сосудах головного мозга, воздействующего на барабанную перепонку.</span>
                                </li>

                                <li class="list-item"><strong class="lt55">Головокружение.<br></strong><span
                                            class="si">Ощущение опьянения и внезапное
                                                            головокружение&nbsp;– свидетельство того, что вестибулярный аппарат «голодает» из‑за нехватки питательных веществ.</span>
                                </li>

                                <li class="list-item"><strong class="lt57">Бессонница.<br></strong><span
                                            class="si">Вас весь день клонит в&nbsp;сон, а ночью вы не&nbsp;можете уснуть? Это вызвано недостаточным кровоснабжением гипофиза, который вырабатывает гормон&nbsp;сна мелатонин.</span>
                                </li>

                                <li class="list-item"><strong class="lt59">Быстрая утомляемость.<br></strong><span
                                            class="si">Совершенно нет сил, не&nbsp;хочется ничего делать? Просто ваше тело пытается минимизировать активность из&#8209;за недостаточного снабжения органов питательными веществами.</span>
                                </li>

                                <li class="list-item"><strong class="lt61">Боль и дискомфорт в&nbsp;груди.<br></strong><span
                                            class="si">Стеснение или боль в груди, часто сопровождается одышкой. Появляется в результате сужения просвета артерий, вызывающего развитие атеросклероза и ишемической болезни&nbsp;сердца.</span>
                                </li>

                                <li class="list-item"><strong class="lt61">Нарушение
                                        зрения.<br></strong><span class="si">Мушки
                                                            перед глазами и затуманенное
                                                            зрение&nbsp;– симптомы плохого
                                                            состояния&nbsp;сосудов.</span></li>

                                <li class="list-item"><strong class="lt63">Отеки.<br></strong><span class="si">Закупоренные кровеносные сосуды затрудняют отток крови, что приводит к нарушению электролитного обмена. Как&nbsp;следствие&nbsp;– опухание конечностей и отек внутренних органов.</span>
                                </li>
                            </ul>

                            <p class="paragraph">Есть ли у вас какие‑либо из этих симптомов? Это означает, что ваши
                                кровеносные сосуды отчаянно пытаются вас предупредить об ухудшении&nbsp;здоровья.</p>

                            <p class="paragraph _2x6gg">
                                <strong class="lt66">После 45&nbsp;лет необходимо чистить сосуды.</strong>
                            </p>

                            <p class="paragraph">Если вы <strong>старше 45&nbsp;лет</strong> и никогда не&nbsp;принимали
                                никаких средств для очищения сосудов&nbsp;– я вам
                                гарантирую, что <strong>у вас точно есть какие&#8209;то&nbsp;проблемы.</strong></p>
                            <p class="paragraph lt41">Засорение сосудов холестерином, тромбами и их
                                кальцификация являются естественным процессом старения.
                                Однако вредная пища, наркотики, курение и алкоголь
                                ускоряют этот процесс в 5&#8209;8&nbsp;раз.</p>

                            <p class="paragraph">Вы страдаете от резких
                                скачков артериального давления? Вас приходится постоянно пить&nbsp;таблетки?
                                Это означает, что только&nbsp;30% ваших кровеносных сосудов все еще
                                здоровы и свободны. <strong>Остальные&nbsp;70% густо покрыты
                                    холестериновыми бляшками, сгустками крови и&nbsp;кальцием.</strong></p>
                            <p class="paragraph">По этой причине минимальный стресс, перемены
                                погоды и незначительная физическая активность оказывают сильное
                                негативное влияние на&nbsp;самочувствие.</p>

                            <p class="paragraph _2x6gg" >
                                Миллионы людей игнорируют начальные признаки сердечно-сосудистых заболеваний&nbsp;– 57%&nbsp;из
                                них в результате <strong class="lt66">умирают от&nbsp;инфаркта.</strong>
                            </p>
                            <p class="paragraph lt67">Очень часто люди имеют сразу несколько симптомов в различных
                                комбинациях. Иногда&nbsp;– все&nbsp;одновременно. Обычно к лечению такого типа проблем
                                подходят «индивидуально». То есть для каждого симптома используются отдельные препараты.
                                Таблетки от давления, кремы от варикоза, свечи от геморроя, гель от остеохондроза. И,
                                конечно же, обезболивающие, обезболивающие и еще&nbsp;раз обезболивающие.</p>
                            <p class="paragraph _2x6gg" >
                                Многие лекарства <strong>не&nbsp;лечат.</strong>
                            </p>

                            <p class="paragraph">Вам не нужно тратить тысячи&nbsp;евро на препараты для временного снятия
                                симптомов. Просто <strong>устраните причину&nbsp;– очистите&nbsp;сосуды.</strong></p>
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Безопасный метод самостоятельной очистки сосудов</h2>
                            <img alt="" class="ma" src="static/images/franco-berrino-01.jpg" width="315" loading="lazy" style="margin:0 auto 20px;width:100%;">

                            <p class="paragraph">Для безопасной очистки
                                сосудов существует только <strong>одно средство с безупречной
                                    репутацией: <a href="#roulette">Kardisen.</a></strong> Это
                                средство продлевает жизнь на 11&#8209;17&nbsp;лет, наполняет энергией
                                и молодостью&nbsp;– и все это без побочных&nbsp;эффектов.</p>
                            <p class="paragraph">Капли <a href="#roulette">Kardisen</a> являются на </strong>100%&nbsp;натуральными,</strong>
                                производятся из природных компонентов и активных концентратов, полученных из экстрактов
                                растений.
                            <p class="paragraph"><strong>Очищать сосуды средством
                                    Kardisen&nbsp;– это естественно и безопасно,</strong> как
                                пить травяной чай. Он уступает по эффективности только
                                хирургической очистке сосудов. Но в отличие от операции, после
                                него нет&nbsp;осложнений или побочных эффектов. Средство
                                синергетически очищает сердечно&#8209;сосудистую систему: от самых
                                толстых крупных артерий до мельчайших капилляров.</p>
                            <p class="paragraph fl _2x6gg">
                                За <strong>один курс</strong> Kardisen удаляет до 4&nbsp;кг
                                холестериновых бляшек, до 1&nbsp;кг тромбов и растворяет
                                350&#8209;400&nbsp;г отложений кальция.
                            </p>
                            <p class="paragraph lt73"><strong>Эффект от применения средства заметен уже с первых дней&nbsp;приема:</strong>
                            </p>
                            <ul style="padding-left: 20px">
                                <li class="list-item"><strong class="lt87">Проходят головные боли,</strong> уходит шум в
                                    ушах. Мозг при правильном питании снова начинает работать более эффективно. Мысли
                                    становятся яснее и точнее.
                                </li>
                                <li class="list-item"><strong class="lt87">Обостряются ощущения,</strong> зрение становится
                                    четче, усиливается вкус, запахи становятся более интенсивными.
                                </li>
                                <li class="list-item"><strong class="lt87">Исчезают головокружения</strong> и одышка, уходит
                                    бессонница, вы снова полны&nbsp;сил и энергии.
                                </li>
                                <li class="list-item"><strong class="lt87">Укрепляются суставы</strong> из&#8209;за
                                    улучшения их&nbsp;смазки.
                                </li>
                                <li class="list-item">Аритмия и тахикардия больше не&nbsp;возникают, <strong class="lt87">сердце
                                        бьется ровно и спокойно.</strong></li>
                            </ul>

                            <p class="paragraph fl _2x6gg">
                                Риск сердечного приступа <strong>сведен к&nbsp;нулю.</strong>
                            </p>
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY fh">Чем обусловлена высокая эффективность средства&nbsp;Kardisen?</h2>
                            <p class="paragraph lt79">Капли <a href="#roulette"><b>Kardisen</b></a>
                                содержат высококонцентрированные природные экстракты, которые начинают действовать в течение
                                получаса после приема внутрь, как только «пробуждаются» натуральные компоненты. Вот почему
                                <a href="#roulette"><b>Kardisen</b></a> так&nbsp;эффективен.</p>
                            <p class="paragraph lt79">Состав средства <strong>легко
                                    всасывается</strong> стенками пищевода и желудка. Поэтому <a
                                        href="#roulette"><b>Kardisen</b></a> не&nbsp;вызывает изжоги,
                                горечи во рту, отрыжки и не&nbsp;раздражает кишечник. <a
                                        href="#roulette"><b>Kardisen</b></a> без&nbsp;колебаний могут принимать
                                даже люди, страдающие язвой&nbsp;желудка.</p>
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY fh">Этапы очистки сосудов средством Kardisen</h2>
                            <p class="paragraph">Kardisen благодаря
                                    высокому содержанию эфирных масел, дубильных веществ,
                                    флавоноидов, фитостеролов, аминокислот и витаминов очень
                                    быстро и эффективно очищает стенки сосудов. В&nbsp;результате кровь вновь может
                                    беспрепятственно поступать в самые отдаленные органы
                                    и&nbsp;капилляры.</p>
                            <p class="paragraph lt82"><a href="#roulette"><b>Kardisen</b></a>
                                работает в три&nbsp;этапа:</p>
                            <ul style="padding-left: 20px">
                                <li class="list-item"><strong class="lt83">Растворяет
                                        отложения.<br></strong><span class="si">Растворяет атеросклеротические бляшки,
                                                            тромбы и отложения кальция. Восстанавливает просвет сосудов и кровоток до нормы.</span>
                                </li>
                                <li class="list-item"><strong class="lt85">Устраняет
                                        последствия плохого кровообращения.<br></strong><span
                                            class="si">Уменьшаются гипертония,
                                                            головная боль, варикозное расширение вен, тромбозы,
                                                            геморрой и простатит. Устраняется шум в ушах,
                                                            головокружение, метеоризм, нарушение зрения и
                                                            спутанность сознания. Вес и жировой обмен
                                                            нормализуются.</span></li>
                                <li class="list-item"><strong class="lt87">Повышает прочность
                                        и эластичность сосудистых стенок.<br></strong><span
                                            class="si">Предотвращается
                                                            образование новых бляшек и значительно снижается
                                                            риск&nbsp;инсульта.</span></li>
                            </ul>


                            <p class="paragraph _2x6gg" >
                                <strong class="lt99">Капли Kardisen&nbsp;– ключ к здоровому сердцу и долголетию.</strong>
                            </p>

                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Эффект бабочки после курса средства Kardisen</h2>
                            <p class="paragraph"><strong class="lt98"><a href="#roulette">Kardisen</a>
                                    похож на
                                    взмахивающую крыльями бабочку, запускающую удивительную
                                    цепную реакцию. Начав с чистки сосудов, <span
                                            style="font-weight:700;">Kardisen</span>
                                    постепенно запускает цепную реакцию по оздоровлению
                                    организма.</strong></p>
                            <h2 class="heading-2 heading-2-left" style="border-bottom: none;">
                                <img alt="" class="ma" src="static/images/check.svg" width="315"
                                     loading="lazy" style="margin:0 auto 0px;">
                                <strong class="lt27" style="font-size:20px;">Заряжает энергией</strong>
                            </h2>
                            <p class="paragraph lt101">Разрушение отложений на стенках сосудов позволит избежать
                                атеросклероза
                                и его негативных последствий.<br>
                                <br>Сосуды беспрепятственно доставляют
                                кислород к каждому органу и клетке организма. Ваше кровообращение заметно улучшено,
                                и вы чувствуете небывалый приток&nbsp;сил и&nbsp;энергии.
                            </p>
                            <h2 class="heading-2 heading-2-left" style="border-bottom: none;">
                                <img alt="" class="ma" src="static/images/check.svg" width="315"
                                     loading="lazy" style="margin:0 auto 0px;">

                                <strong class="lt27" style="font-size:20px;">Нормализует обмен веществ</strong>

                            </h2>
                            <p class="paragraph lt103">Улучшение кровоснабжения в органах брюшной полости,
                                включая желудок и кишечник, позволяет качественно переваривать пищу и усваивать
                                питательные вещества.<br>

                                <br>Движение крови и лимфы в органах пищеварения восстановлено.
                                Организм получает все необходимые микро&#8209; и макроэлементы.</p>
                            <h2 class="heading-2 heading-2-left" style="border-bottom: none;">
                                <img alt="" class="ma" src="static/images/check.svg" width="315"
                                     loading="lazy" style="margin:0 auto 0px;">

                                <strong class="lt27" style="font-size:20px;">Устраняет отеки</strong>
                            </h2>
                            <p class="paragraph lt105">Очистка сосудов улучшает кровоток в почках,
                                что помогает им эффективно фильтровать кровь и выводить жидкость из&nbsp;организма.<br>

                                <br> Больше нет отеков, вы спокойно носите любимую обувь.
                                Риск развития почечной недостаточности сведен к&nbsp;нулю.
                            </p>
                            <h2 class="heading-2 heading-2-left" style="border-bottom: none;">
                                <img alt="" class="ma" src="static/images/check.svg" width="315"
                                     loading="lazy" style="margin:0 auto 0px;">

                                <strong class="lt27" style="font-size:20px;">Защищает мозг</strong>
                            </h2>
                            <p class="paragraph lt107">Здоровые сосуды имеют минимальную вероятность поражения и
                                разрыва.<br>
                                <br> Вы не переживаете об инсультах и других сосудистых происшествиях, которые
                                могут привести к когнитивным проблемам (нарушение мышления, памяти, внимания, речи,
                                ориентации).</p>

                            <h2 class="heading-2 heading-2-left" style="border-bottom: none;">
                                <img alt="" class="ma" src="static/images/check.svg" width="315"
                                     loading="lazy" style="margin:0 auto 0px;">

                                <strong class="lt27" style="font-size:20px;">Избавляет от бессонницы</strong>
                            </h2>
                            <p class="paragraph lt111">Мозг получает по чистым сосудам достаточно кислорода для
                                регуляции циклов сна и бодрствования.<br>
                                <br>И как только вы оказались в постели, вы быстро и сладко засыпаете. Прошли те дни, когда
                                вы
                                ворочались и не&nbsp;могли уснуть.
                            </p>
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Как можно получить Kardisen?</h2>

                            <p class="paragraph lt113"><strong>Насколько нам известно, <a
                                            href="#roulette">Kardisen</a> исчез из
                                    большинства аптек. Почему?</strong></p>
                            <p class="paragraph">К сожалению, да. <a
                                        href="#roulette"><b>Kardisen</b></a> отсутствует в аптеках с
                                начала&nbsp;года, потому что врачи и фармацевты боятся потерять прибыль от продажи
                                отпускаемых по&nbsp;рецепту лекарств.</p>
                            <p class="paragraph">Ведь <a
                                        href="#roulette"><b>Kardisen</b></a>&nbsp;– это средство, которое покупаешь раз в
                                5‑7&nbsp;лет. К тому же, после чистки сосудов каплями <b>Kardisen</b> люди перестают ходить
                                в аптеки! Они больше не покупают препараты для снижения артериального давления, от
                                сердечного тонуса, болей в суставах, астмы и даже диабета. И, конечно же, это приводит к
                                значительным финансовым потерям&nbsp;аптек.</p>
                            <p class="paragraph">По этой причине аптечные сети хотели установить максимально возможную цену
                                на&nbsp;<b>Kardisen.</b> Стоимость средства стала бы невероятно высокой. Поэтому
                                производитель расторг договоры со всеми аптеками и решил распространять <b>Kardisen</b>
                                только через Интернет. Благодаря этому <a
                                        href="#roulette"><b>Kardisen</b></a> теперь доступен по льготной&nbsp;программе.</p>


                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Льготная программа "Здоровые сосуды"</h2>
                            <img alt="" class="ma" src="static/order_tube.png" width="315"
                                 loading="lazy" style="margin:0 auto 20px;width:100%;max-width:260px;">
                            <p class="paragraph lt114">Производитель при поддержке Европейского
                                общества кардиологов запустил льготную программу в рамках
                                проекта телемедицины (медицина через&nbsp;Интернет).</p>
                            <p class="paragraph">В рамках этой программы, любой желающий, проживающий
                                {{country_name_locational}}, может получить
                                <a
                                        href="#roulette"><b>Kardisen</b></a> <strong>абсолютно&nbsp;бесплатно</strong> до
                                <span class="nowdate"
                                      format="dayI&nbsp;monthS year"
                                      daysint></span>
                                включительно.
                            </p>
                            <p class="paragraph">Чтобы получить <b>Kardisen</b>
                                бесплатно по льготной программе, вы должны выполнить
                                следующие&nbsp;условия:</p>
                            <div class="div-block-2 bt2" style="margin-bottom:30px;">
                                <div class="text-block-6">
                                    <strong class="lt115">Условия получения средства
                                        Kardisen:</strong>
                                </div>
                                <ul style="margin-bottom:0;padding-left:30px;">
                                    <li class="list-item"><strong class="lt116">Только для
                                            личного использования<br></strong><span class="si">Необходимо для
                                                                борьбы с перекупщиками, пытающимися купить Kardisen оптом
                                                                для перепродажи по завышенной&nbsp;цене.</span>
                                    </li>
                                    <li class="list-item" style="margin-bottom:0;"><strong
                                                class="lt118">Зарегистрироваться через официальную
                                            форму программы<br></strong><span class="si">Официальная
                                                                форма&nbsp;–
                                                                гарантия качества и защита от
                                                                перекупщиков.</span></li>
                                </ul>
                            </div>
                            <h2 class="Text_root__1rV-_ Text_size-large-xs__3fDJw Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-bold__yEdXP Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M indentRules_block__iwiZV styles_heading__2mJ-- styles_h3__31bNY">Избавьтесь от проблем с давлением и верните здоровье своему&nbsp;сердцу!
                            </h2>
                            <font id="roulette"></font>
                            <!--{{start_form}}-->
                            <center>
                                <div class="bgn">
                                    <p class="paragraph"
                                       style="margin-top:5px;text-align:center;margin-bottom:15px;">
                                        <strong class="lt120">Как долго будет действовать льготная программа?</strong>
                                    </p>
                                    <div class="countdown-block" id="form1">
                                        <div class="countdown-container">
                                            <h3 class="lt121">Акция действительна до</h3>
                                            <div class="countdown">
                                                <div class="countdown-item timer-hours" id="hour1">
                                                    02
                                                </div>
                                                <div class="countdown-divider lt122">
                                                    :
                                                </div>
                                                <div class="countdown-item timer-minutes" id="min1">
                                                    38
                                                </div>
                                                <div class="countdown-divider lt123">
                                                    :
                                                </div>
                                                <div class="countdown-item timer-seconds" id="sec1">
                                                    43
                                                </div>
                                            </div>
                                            <div class="countdown-text">
                                                <span class="lt124">Часы</span><span
                                                        class="lt125">Минуты</span><span
                                                        class="lt126">Секунды</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="best-form">
                                        <div class="wrap">
                                            <div class="product">
                                                <div class="left"><img alt=""
                                                                       src="static/order_tube.png"
                                                                       loading="lazy"></div>
                                                <div class="right">
                                                    <div class="price">
                                                                        <span
                                                                                style="text-transform:uppercase;">БЕСПЛАТНО</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <form action="" method="post" style="max-width: 308px">
                                                    <div class="name-input">
                                                        <select
                                                                name="order[country]"></select>
                                                    </div>
                                                    <div class="name-input">
                                                        <input autocomplete="name" id="name-input"
                                                               name="order[fio]" type="text"
                                                               placeholder="Ваше имя">
                                                    </div>
                                                    <div class="phone-input">
                                                        <input autocomplete="tel" id="phone-input"
                                                               maxlength="20" name="order[phone]"
                                                               type="tel" placeholder="Номер телоефона"
                                                               required>
                                                    </div>
                                                    <button class="button-submit" type="submit"
                                                            style="margin-top:15px;"
                                                            onclick="$(this).closest('form').submit();return false;"><span
                                                                class="button-submit-text lt129">ПОЛУЧИТЬ
                                                                            БЕСПЛАТНО</span></button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--{{end_form}}-->
                            </center>

                            <div class="styles_root__2iik7">
                                <div class="styles_titleWrapper__zwj2-">
                                    <h3 style="letter-spacing:normal; text-transform:uppercase; font-size: 30px;"
                                        class="Text_root__1rV-_ Text_size-medium__2-xOZ Text_color-black__eOYaI Text_textAlign-left__3gMUE Text_whiteSpace-normal__1ATx6 Text_fontWeight-medium__2bDOk Text_textTransform-none__XTjFr Text_fontType-roboto__3Nq6M styles_title__APWfy">
                                        Комментарий</h3>
                                </div>
                                <div class="styles_commentsContentWrapper__10Ncp">
                                    <div class="styles_root__2FDPr">

                                        <div class="comment" style="margin-top:30px;">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b1b89d7eef54_11.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt131"><span class="b"><strong>Арина</strong>
                                                                <font class="mycity pl_city_stock5"></font>
                                                            </span><b>Kardisen</b>&nbsp;- самое лучшее средство. Через 2&nbsp;недели
                                                забыла о давлении, которое тревожило пол&nbsp;жизни!
                                            </p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b1753e7eef4b_19.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt132"><span class="b"><strong>Милана
                                                                    Йоххайм</strong>
                                                                <font class="mycity pl_city_stock6"></font>
                                                            </span><a href="#roulette"><b>Kardisen</b></a> доставили за
                                                4&nbsp;дня! Заказывала для&nbsp;мамы. Надеюсь поможет. Очень благодарна
                                                производителю за возможность найти такое
                                                средство хотя б в интернете! Еще&nbsp;и&nbsp;бесплатно!</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b186037eef5e_28.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt133"><span class="b"><strong>Нина
                                                                    Баффо</strong>
                                                                <font class="mycity pl_city_stock4"></font>
                                                            </span>Капли <a href="#roulette"><b>Kardisen</b></a> это
                                                средство нового поколения, когда такое было чтоб полностью
                                                вылечить все болезни и без&nbsp;побочных эффектов! Неудивительно что
                                                аптеки хотят нажиться на&nbsp;нем!
                                            </p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b113957eef52_20.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt134"><span class="b"><strong>Лиза</strong>
                                                                <font class="mycity pl_city_stock7"></font>
                                                            </span>У меня уже было 2&nbsp;микроинсульта, сказали никаких
                                                стрессов, активностей и прочего. Чувствовала себя овощем. Но эти
                                                капли вернули краски в мою жизнь, теперь как будто
                                                заново&nbsp;родилась</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b148137eef5f_7.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt135"><span class="b"><strong>Елена
                                                                    Бек</strong>
                                                                <font class="mycity pl_city_more5"></font>
                                                            </span><strong></strong>Скажите, пожалуйста, как можно
                                                получить
                                                Kardisen бесплатно? Я хочу&nbsp;попробовать.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b1ee9a7eef5b_27.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt137"><span class="b"><strong>Доктор
                                                                    Александр&nbsp;Мясников</strong>
                                                                <font class="mycity pl_city_more10"></font>
                                                            </span><strong></strong>Елена, чтобы
                                                получить оригинальный Kardisen, заполните форму в конце статьи и
                                                дождитесь звонка консультанта. Получите свою посылку и смело
                                                начинайте&nbsp;курс.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b148137eef5f_7.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt137"><span class="b"><strong>Елена
                                                                    Бек</strong>
                                                                <font class="mycity pl_city_more5"></font>
                                                            </span><strong></strong>Спасибо,&nbsp;доктор.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b1ff427eef47_16.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt138"><span
                                                        class="b"><strong>Руслана</strong>
                                                                <font class="mycity pl_city_stock2"></font>
                                                            </span>Забрала посылку с почты, заказала для бабушки,&nbsp;спасибо!
                                            </p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b1d9c37eef53_18.png"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt139"><span class="b"><strong>Рита
                                                                    Шмидт</strong>
                                                                <font class="mycity pl_city_stock9"></font>
                                                            </span>Спасибо производителю за Kardisen! Попробовала, стало
                                                действительно легче. Давление уже не&nbsp;скачет, даже не&nbsp;чувствую
                                                его. Так что думаю, все будет&nbsp;хорошо!
                                            </p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b14de57eef50_26.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt140"><span class="b"><strong>Галина</strong>
                                                                <font class="mycity pl_city_more5"></font>
                                                            </span>Думаю, пора&nbsp;попробовать=)</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b161dd7eef5d_25.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt141"><span class="b"><strong>Андрей</strong>
                                                                <font class="mycity pl_city_stock1"></font>
                                                            </span>Я взял 2&#8209;месячный курс <a
                                                        href="#roulette"><b>Кардисена</b></a> для родителей.
                                                Наверное, оставлю заявку чтобы и себе взять, пусть
                                                лежит в аптечке на всякий случай.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b140d57eef64_9.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt142"><span class="b"><strong>Карина</strong>
                                                                <font class="mycity pl_city_stock10"></font>
                                                            </span>Спасибо! Жду&nbsp;посылку.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b179557eef4d_14.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt143"><span class="b"><strong>Артем</strong>
                                                                <font class="mycity pl_city_stock5"></font>
                                                            </span>А долго будет действовать&nbsp;программа?</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b1ee9a7eef5b_27.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt145"><span class="b"><strong>Доктор Александр&nbsp;Мясников</strong>
                                                                <font class="mycity pl_city_stock10"></font>
                                                            </span>Льготная программа
                                                действует
                                                до <span class="nowdate" format="dayI&nbsp;monthS year"
                                                         daysint></span> включительно. Но советую поторопиться,
                                                потому что льготных упаковок с каждой минутой становиться все&nbsp;меньше.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b1aec37eef51_4.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt145"><span class="b"><strong>Леонид</strong>
                                                                <font class="mycity pl_city_stock1"></font>
                                                            </span>Уже опробовал результат отличный, и родителям
                                                заказал.
                                                Больше нет&nbsp;смысла ходить в аптеки и выкидывать кучу&nbsp;денег.</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b12b337eef49_17.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt146"><span class="b"><strong>Алина</strong>
                                                                <font class="mycity pl_city_stock4"></font>
                                                            </span>Очень эффективное средство от проблем с давлением!
                                                Сейчас
                                                стабильно 120&nbsp;на&nbsp;80!</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b11df07eef48_23.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt147"><span class="b"><strong>Богдана
                                                                    Шредер</strong>
                                                                <font class="mycity pl_city_stock3"></font>
                                                            </span>А как долго его доставляют?</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b178f87eef65_33.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt148"><span class="b"><strong>Кристина
                                                                    Крейцман</strong>
                                                                <font class="mycity pl_city_stock8"></font>
                                                            </span>Мне пришел за 3&nbsp;дня, но говорили доставка
                                                3&#8209;5&nbsp;дней</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b147c77eef4c_15.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt149"><span class="b"><strong>Виктория
                                                                    Розен</strong>
                                                                <font class="mycity pl_city_stock9"></font>
                                                            </span>Сдала анализы, сказали что очень высокий холестерин,
                                                назначили кучу таблеток. Рассказала подруге, а она мне ссылку на
                                                эту статью и сказала заказывать пока льготная программа идет,
                                                не&nbsp;пожалею. Пью уже неделю и
                                                не могу поверить своим ощущениям. Хотела избавиться от
                                                холестерина, а залатала весь&nbsp;организм!</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3" sizes="(max-width: 479px) 86vw, 62px"
                                                 src="static/images/6086c6067e67b118107eef63_34.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt150"><span
                                                        class="b"><strong>Алла</strong>
                                                                <font class="mycity pl_city_stock2"></font>
                                                            </span>Спасибо за акцию, а то найти эффективное и не&nbsp;за
                                                все
                                                деньги мира средство... это задание со&nbsp;звездочкой. Заказала
                                                подругам,
                                                пусть тоже почуствуют эффект&nbsp;бабочки! </p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b10ac27eef60_31.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt151"><span class="b"><strong>Евгения
                                                                    Поль</strong>
                                                                <font class="mycity pl_city_stock6"></font>
                                                            </span>Я аллергик и с точностью могу заявить, что средство
                                                гипоаллергенно и эффективно! Давление и головные боли полностью
                                                прошли, даже суставы перестали&nbsp;хрустеть!</p>
                                        </div>
                                        <div class="comment">
                                            <img alt="" class="image-3"
                                                 src="static/images/6086c6067e67b1f1877eef59_38.jpg"
                                                 width="62" loading="lazy">
                                            <p class="paragraph-3 lt152"><span class="b"><strong>Линда</strong>
                                                                <font class="mycity pl_city_more4"></font>
                                                            </span>Не верила до последнего, что такое возможно! Но
                                                заполнила
                                                <a href="#roulette"><b>официальную&nbsp;форму,</b></a> дождалась свои
                                                капельки, прошла курс и теперь порхаю как&nbsp;бабочка!
                                                Рекомендую&nbsp;всем!
                                            </p>
                                        </div>
                                        <a class="button-submit" href="#roulette"><span
                                                    class="button-submit-text lt153">ПОЛУЧИТЬ БЕСПЛАТНО</span></a>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="styles_rightColumn__35ZQl styles_rightColumnBasic__3mOm8">
                    <div class="styles_root__kqnU_ sticky-aside">
                        <img loading="lazy" src="static/images/prod.png"
                             style="width:100%;max-width:220px;margin:0 auto;" alt="">
                        <a href="#roulette"><button>ОФОРМИТЬ ЗАКАЗ</button></a>
                    </div>
                </div>
            </div>
            <div class="styles_container__1lDqG">
                <h3 class="styles_title__1nLY1">Новости партнеров</h3>
                <section id="" class="styles_root__3JmMv">
                    <div class="styles_carouselEx__wrap__38FER">
                        <div class="styles_carouselEx__22_X8">
                            <div class="styles_carouselEx__item__wrap__2FbXh">
                                <div class="style_exchange__26oU9 styles_item__FuTs3 styles_prettyFooter__1blrQ">
                                    <a target="_blank" rel="noopener noreferrer" class="" href="#roulette">
                                        <div class="style_mediaWrap__2IpTm">
                                            <div class="styles_root__3MXhb style_media__2XDtc"><img
                                                        class="styles_element__ggnUE"
                                                        src="static/images/11388995.jpeg" loading="lazy"></div>
                                        </div>
                                        <div class="style_textContent__1irQI">
                                            <p class="style_title__32KGJ">Выставка авиатехники пройдет
                                                {{country_name_locational}}
                                            </p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="styles_carouselEx__item__wrap__2FbXh">
                                <div class="style_exchange__26oU9 styles_item__FuTs3 styles_prettyFooter__1blrQ">
                                    <a target="_blank" rel="noopener noreferrer" class="" href="#roulette">
                                        <div class="style_mediaWrap__2IpTm">
                                            <div class="styles_root__3MXhb style_media__2XDtc"><img
                                                        class="styles_element__ggnUE"
                                                        src="static/images/11376655.jpeg" loading="lazy"></div>
                                        </div>
                                        <div class="style_textContent__1irQI">
                                            <p class="style_title__32KGJ">Как мед помогает бороться со
                                                старением: новое исследование</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="styles_carouselEx__item__wrap__2FbXh">
                                <div class="style_exchange__26oU9 styles_item__FuTs3 styles_prettyFooter__1blrQ">
                                    <a target="_blank" rel="noopener noreferrer" class="" href="#roulette">
                                        <div class="style_mediaWrap__2IpTm">
                                            <div class="styles_root__3MXhb style_media__2XDtc"><img
                                                        class="styles_element__ggnUE"
                                                        src="static/images/0c499e174a69d2ef09b8a70ef8beb814.jpeg"
                                                        loading="lazy"></div>
                                        </div>
                                        <div class="style_textContent__1irQI">
                                            <p class="style_title__32KGJ">Когда женщина закидывает ногу
                                                на ногу: вот что это означает</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="styles_carouselEx__item__wrap__2FbXh">
                                <div class="style_exchange__26oU9 styles_item__FuTs3 styles_prettyFooter__1blrQ">
                                    <a target="_blank" rel="noopener noreferrer" class="" href="#roulette">
                                        <div class="style_mediaWrap__2IpTm">
                                            <div class="styles_root__3MXhb style_media__2XDtc"><img
                                                        class="styles_element__ggnUE"
                                                        src="static/images/11376254.jpeg" loading="lazy"></div>
                                        </div>
                                        <div class="style_textContent__1irQI">
                                            <p class="style_title__32KGJ">Мало кто знал: названо
                                                уникальное свойство меда</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="styles_carouselEx__item__wrap__2FbXh">
                                <div class="style_exchange__26oU9 styles_item__FuTs3 styles_prettyFooter__1blrQ">
                                    <a target="_blank" rel="noopener noreferrer" class="" href="#roulette">
                                        <div class="style_mediaWrap__2IpTm">
                                            <div class="styles_root__3MXhb style_media__2XDtc"><img
                                                        class="styles_element__ggnUE"
                                                        src="static/images/f7b386b90498c54a6b1d48076547ec3d.jpeg"
                                                        loading="lazy"></div>
                                        </div>
                                        <div class="style_textContent__1irQI">
                                            <p class="style_title__32KGJ">Об этой каше все забыли, а
                                                зря: она вкусная и полезная</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <center>
                <div class="styles_root__2bZ38" style="margin-bottom:30px;"><a href="#roulette"><svg
                                style="cursor:pointer;color:#FF0A0A" width="74" height="28" viewBox="0 0 74 28"
                                fill="#FF0A0A" xmlns="http://www.w3.org/2000/svg">
                            <path
                                    d="M7.863 0H0v28h19v-6.292H7.863V0zM22 28h9V0h-9v28zm12 0h7.877V16.943h8.746v-6.292h-8.746V6.292H53V0H34v28zM55 0v28h19v-6.293H62.77v-4.764h8.911V10.65H62.77V6.255H74V0H55z"
                                    fill-rule="evenodd" clip-rule="evenodd"></path>
                        </svg></a>
                </div>
            </center>

<script src="static/dist/bundle.js"></script>
</body>
</html>
