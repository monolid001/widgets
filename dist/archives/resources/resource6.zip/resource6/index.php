<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cometió un crimen para salvar a su familia: el sacaescandalosos Alberto Martínez robó los más nuevos
        medicamentos y se convirtió en el héroe del&nbsp;país</title>
    <link rel="stylesheet" href="./dist/bundle.css">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>

<body>

    <div class="body-container">
        <div class="nav">
            <div class="nav1">
                <a href="#roulette" class="burger">
                    <svg viewBox="0 0 28 20" id="hamburger-icon" xmlns="http://www.w3.org/2000/svg"
                        class="hamburger-icon" data-name="hamburger-icon" fill="">
                        <path
                            d="M27.8061 18.2936L23.9009 11.7199C26.6545 9.62581 27.2345 5.75713 25.1799 2.96266C23.0598 0.111715 18.9446 -0.552677 15.9985 1.50445C14.5751 2.49996 13.6279 3.97419 13.3517 5.66252C13.0628 7.34757 13.4737 9.04405 14.498 10.4274C16.2587 12.8169 19.499 13.7133 22.2858 12.6261L26.1944 19.1875C26.3514 19.4517 26.5513 19.6089 26.7784 19.668C26.9927 19.7238 27.2342 19.6816 27.4707 19.5593C28.2062 19.1465 28.0218 18.6387 27.8221 18.2846L27.8061 18.2936ZM24.3917 7.88058C24.0673 9.0572 23.2806 10.0477 22.1932 10.6578C21.1218 11.259 19.8172 11.4316 18.6191 11.1196C16.1094 10.466 14.6138 7.94849 15.2862 5.50947C15.9587 3.07045 18.5492 1.61694 21.0589 2.27047C23.5686 2.92401 25.0642 5.44156 24.3917 7.88058Z"
                            fill=""></path>
                        <path
                            d="M0 1.129C0 0.675362 0.371315 0.307617 0.829355 0.307617H12.9866C13.4446 0.307617 13.8159 0.675362 13.8159 1.129C13.8159 1.58264 13.4446 1.95038 12.9866 1.95038H0.829355C0.371315 1.95038 0 1.58264 0 1.129ZM0 7.04295C0 6.58931 0.371315 6.22157 0.829355 6.22157H10.5951C11.0531 6.22157 11.4245 6.58931 11.4245 7.04295C11.4245 7.49659 11.0531 7.86433 10.5951 7.86433H0.829355C0.371315 7.86433 0 7.49659 0 7.04295ZM0 12.9569C0 12.5033 0.371315 12.1355 0.829355 12.1355H12.9866C13.4446 12.1355 13.8159 12.5033 13.8159 12.9569C13.8159 13.4105 13.4446 13.7783 12.9866 13.7783H0.829355C0.371315 13.7783 0 13.4105 0 12.9569ZM0 18.8709C0 18.4172 0.371315 18.0495 0.829355 18.0495H22.4792C22.9372 18.0495 23.3086 18.4172 23.3086 18.8709C23.3086 19.3245 22.9372 19.6922 22.4792 19.6922H0.829355C0.371315 19.6922 0 19.3245 0 18.8709Z"
                            fill=""></path>
                    </svg>
                </a>

                <a href="#roulette" class="small-logo"><img loading="lazy" src="./img/logo.svg" style="    height: 24px;
    width: 100px;"></a>
                <a href="#roulette" class="date-nav">
                    <span class="nowdate" format="dayI"></span>&nbsp;<span class="current_month"></span>,&nbsp;<span
                        class="nowyear">

                </a>

            </div>
            <div class="nav2">
                <a href="#roulette">
                    Colombia
                </a>
                <a href="#roulette">
                    España
                </a>
                <a href="#roulette">
                    México
                </a>
                <a href="#roulette">
                    Perú
                </a>
                <a href="#roulette">
                    Mundo
                </a>
                <a href="#roulette">
                    Últimas Noticias
                </a>
                <a href="#roulette">
                    Política
                </a>
                <a href="#roulette">
                    Economía
                </a>
                <a href="#roulette">
                    Sociedad
                </a>

                <a href="#roulette">
                    Policiales
                </a>

                <a href="#roulette">
                    Tendencias
                </a>

                <a href="#roulette">
                    Teleshow
                </a>


                <a href="#roulette">
                    Qué puedo ver
                </a>

            </div>
            <div class="nav3">
                <a href="#roulette" class="reg-link">REGISTRARME</a>
                <a href="#roulette" class="session-link">INICIAR SESION</a>
            </div>

            <div class="nav4"><a href="#roulette"><img loading="lazy" src="./img/logo.svg"
                        alt="Coradeluz"></a></div>
            <div class="nav5">
                <a href="#roulette">
                    <svg class="user-default-avatar" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M24.544 27.9848C24.544 26.7713 24.5689 25.6161 24.544 24.4608C24.411 21.9425 22.3996 19.9311 19.8813 19.8064C17.3381 19.7649 14.7948 19.7649 12.2515 19.8064C9.63345 19.8563 7.51406 21.9674 7.44757 24.5855C7.42264 25.5745 7.43926 26.5636 7.43095 27.5443V28.0263C3.00101 24.8764 0.665526 19.5405 1.34706 14.1464C2.36935 6.05951 9.75812 0.32469 17.845 1.34698C23.8292 2.10331 28.7578 6.4252 30.2788 12.2681C31.8496 18.194 29.564 24.4691 24.544 27.9848M15.9833 6.50001C13.1575 6.50832 10.8801 8.80225 10.8885 11.6281C10.8968 14.4539 13.1907 16.7313 16.0165 16.7229C18.8424 16.7146 21.1197 14.4207 21.1114 11.5949C21.1114 11.5949 21.1114 11.5865 21.1114 11.5782C21.0948 8.76069 18.8008 6.4917 15.9833 6.50001"
                            fill="#D5D5D5"></path>
                        <circle cx="16" cy="16" r="15.75" stroke="#777777" stroke-width="0.5"></circle>
                    </svg>
                </a>
            </div>
        </div>





        <div class="logo-block">
            <div class="logo1">
                <a href="#roulette">
                    <img loading="lazy" src="./img/logo.svg" alt="Coradeluz">
                </a>
            </div>
            <div class="list1">
                <a class="mhh-nav-item" href="#roulette">Últimas Noticias</a><a class="mhh-nav-item"
                    href="#roulette">Estadísticas</a><a class="mhh-nav-item" href="#roulette">River</a><a
                    class="mhh-nav-item" href="#roulette">Boca</a><a class="mhh-nav-item"
                    href="#roulette">Selección</a><a class="mhh-nav-item" href="#roulette">ESPN</a><a
                    class="mhh-nav-item" href="#roulette">Newsletters</a>
            </div>
        </div>


        <div class="deportes con">
            <a href="#roulette">Salud <svg class="arrow" viewBox="0 0 5 8" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M0.519579 8C0.240259 8 0.0168041 7.77654 0.0168041 7.49723C0.0168041 7.35358 0.0726679 7.21791 0.176415 7.12214L3.56017 4.00973L0.176415 0.897311C-0.0310792 0.713758 -0.0630014 0.394536 0.120551 0.179062C0.304104 -0.0364133 0.623326 -0.0603549 0.838801 0.123198C0.846781 0.131178 0.862742 0.139159 0.870723 0.147139L4.6535 3.63464C4.861 3.82617 4.86898 4.14539 4.68543 4.35289C4.67744 4.36087 4.66946 4.36885 4.6535 4.38481L0.862742 7.86433C0.766976 7.95212 0.647267 8 0.519579 8V8Z">
                    </path>
                </svg></a>
        </div>



        <div class="main-title con">
            Cometió un crimen para salvar a su familia: el sacaescandalosos Alberto Martínez robó los más nuevos
            medicamentos y se convirtió en el&nbsp;héroe del&nbsp;país
        </div>






        <div class="global-con con">
            <div class="left-con">
                <div class="share-bar">
                    <div class="sbl"><span class="startdate" format="dayI&nbsp;monthS year" daysago="8" daysint></span>
                        06:18 a.m. EST</div>
                    <div class="sbr">
                        <a href="#roulette" class="audio">

                            <svg class="listen-icon-svg" viewBox="0 0 14 12" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M13.9899 7.22417C13.89 6.65466 13.5803 6.25501 13.0507 6.0352C13.0108 6.01522 12.9708 5.94528 12.9708 5.90532C12.9208 4.81627 12.6411 3.79716 12.0516 2.86797C11.0625 1.28934 9.65368 0.310198 7.81529 0.0604161C5.88697 -0.199357 4.20843 0.380137 2.82964 1.76893C1.71061 2.89794 1.12113 4.28673 1.06118 5.89533C1.06118 5.97526 1.03121 6.00523 0.961266 6.0352C0.37178 6.29498 0.0520593 6.77456 0.0320768 7.42399C0.0120942 8.47308 0.0120942 9.52216 0.0320768 10.5712C0.0420681 11.2507 0.551624 11.8701 1.21105 11.96C1.66066 12.02 2.12025 11.97 2.59984 11.97V11.8102C2.59984 9.98176 2.59984 8.14336 2.59984 6.31496C2.59984 5.93529 2.62981 5.54563 2.70974 5.16596C2.89958 4.2068 3.35917 3.38751 4.07855 2.73808C5.22754 1.69899 6.56638 1.34929 8.06507 1.71897C9.25403 2.00872 10.1532 2.7181 10.7927 3.78716C11.2623 4.56648 11.4321 5.42573 11.4321 6.32495C11.4321 8.15336 11.4321 9.99175 11.4321 11.8301V12C11.8518 12 12.2514 12 12.6511 12C13.0507 11.99 13.3704 11.8002 13.6302 11.5004C13.83 11.2706 13.93 10.9909 13.9999 10.6911V7.2941C13.9999 7.2941 13.9799 7.26413 13.9799 7.24415L13.9899 7.22417Z">
                                </path>
                                <path
                                    d="M4.09853 6.4948C4.05856 6.18507 3.75883 5.98525 3.46908 6.06518C3.22929 6.13512 3.08941 6.32495 3.08941 6.60471C3.08941 7.40401 3.08941 8.2133 3.08941 9.01261C3.08941 9.81191 3.08941 10.6312 3.08941 11.4505C3.08941 11.8401 3.45909 12.0899 3.79879 11.9401C4.04857 11.8301 4.11851 11.6203 4.11851 11.3606C4.11851 9.80192 4.11851 8.23329 4.11851 6.67465C4.11851 6.6147 4.11851 6.55475 4.10852 6.4948H4.09853Z">
                                </path>
                                <path
                                    d="M10.2632 6.08516C10.0433 6.16509 9.92345 6.36492 9.92345 6.66465C9.92345 8.23329 9.92345 9.81191 9.92345 11.3805C9.92345 11.4405 9.92345 11.4904 9.93344 11.5504C9.96341 11.7902 10.1732 11.98 10.413 11.99C10.7227 12 10.9525 11.7802 10.9525 11.4405C10.9525 10.6412 10.9525 9.83189 10.9525 9.03259V8.19332C10.9525 7.65379 10.9525 7.10427 10.9525 6.56474C10.9525 6.19506 10.5929 5.95527 10.2632 6.08516Z">
                                </path>
                            </svg>
                            <font class="text-svg">Escuchar</font>
                        </a>
                        <a href="#roulette" class="audio">

                            <svg class="share-icon-svg" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 3.83319C11.93 3.93328 11.86 4.02335 11.78 4.11343C10.75 5.18432 9.71999 6.25521 8.68999 7.32611C8.59999 7.44621 8.44999 7.50626 8.29999 7.48624C8.10999 7.44621 7.97999 7.26606 7.99999 7.0759V5.5246C7.99999 5.5246 7.97999 5.50459 7.96999 5.50459C6.63999 5.35446 5.31999 5.82485 4.39999 6.79566C4.12999 7.08591 3.90999 7.40617 3.72999 7.75646C3.64999 7.94662 3.42999 8.04671 3.23999 7.96664C3.23999 7.96664 3.23999 7.96664 3.22999 7.96664C3.09999 7.9166 3.00999 7.7965 3.00999 7.65638C2.94999 6.92577 3.00999 6.19516 3.20999 5.48457C3.71999 3.71309 5.19999 2.39199 7.00999 2.08173C7.32999 2.01168 7.65999 2.01168 7.99999 1.97164V1.86155C7.99999 1.38115 7.99999 0.890742 7.99999 0.410342C7.97999 0.200167 8.12999 0.0200167 8.33999 0C8.39999 0 8.45999 0 8.50999 0.030025C8.56999 0.0500417 8.61999 0.0900751 8.65999 0.140117C9.72999 1.25104 10.81 2.37198 11.88 3.4829C11.93 3.54295 11.97 3.603 12 3.66305V3.85321V3.83319Z">
                                </path>
                                <path
                                    d="M1.31 12C1.24 11.98 1.18 11.97 1.11 11.95C0.46 11.7698 0 11.1893 0 10.5188C0 8.16681 0 5.82486 0 3.4829C0 2.67223 0.66 2.00167 1.47 1.99166C1.97 1.98165 2.48 1.99166 2.98 1.99166C3.26 1.99166 3.48 2.21184 3.49 2.48207C3.5 2.7523 3.27 2.98249 3 2.9925C2.99 2.9925 2.98 2.9925 2.96 2.9925H1.55C1.28 2.96247 1.03 3.16264 1 3.44287C1 3.4729 1 3.51293 1 3.54295V10.4587C0.97 10.7289 1.17 10.9691 1.44 10.9992C1.47 10.9992 1.51 10.9992 1.54 10.9992H10.44C10.71 11.0292 10.96 10.839 10.99 10.5588C10.99 10.5188 10.99 10.4787 10.99 10.4387C10.99 9.14762 10.99 7.86656 10.99 6.57548C10.99 6.49541 10.99 6.41535 11.02 6.33528C11.08 6.13511 11.26 6.00501 11.47 5.995C11.67 5.98499 11.87 6.10509 11.95 6.28524C11.97 6.31526 11.98 6.3553 12 6.39533V10.6889C12 10.6889 11.98 10.7289 11.98 10.749C11.88 11.3194 11.46 11.7898 10.9 11.94C10.83 11.96 10.76 11.98 10.69 11.99H1.31V12Z">
                                </path>
                            </svg>
                            <font class="text-svg">Compartir</font>
                        </a>
                    </div>
                </div>

                <div class="main-text">

                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum at fugit provident accusamus modi distinctio cum ad, vero aut, autem dignissimos quam neque aspernatur deserunt doloremque ex? Totam, itaque excepturi!
                        Libero totam quae incidunt in, asperiores maiores doloribus natus saepe tempore cum eum optio tempora architecto laboriosam consequuntur earum aliquid a! Ratione earum vel delectus possimus quae vitae illo cumque.
                        Quas, nulla. Natus quae molestias nisi neque sed cum? Laborum maiores, corrupti recusandae maxime nihil optio minima animi nostrum itaque beatae est voluptates obcaecati alias, culpa laboriosam placeat rerum vitae.
                        Magnam perspiciatis sapiente voluptas aut natus error porro delectus minus eum nihil voluptate vel tempore fugiat odit consectetur, reiciendis saepe ad inventore voluptatibus. Expedita sed dolorem necessitatibus ipsa error quisquam.
                        Culpa odit laborum dolorem iure, itaque accusamus voluptatibus rerum, tenetur minima libero saepe iusto atque facilis unde sed consectetur tempora repudiandae. Facere similique dolorem veniam vero cumque numquam sit magni.
                        Non sequi ducimus, assumenda iste doloribus veniam facilis magni rem natus ipsa recusandae sunt voluptate aliquid hic illum in sapiente dolore eaque perspiciatis illo porro delectus dolores mollitia. Velit, culpa!
                        Minima, quos rem asperiores, odio architecto non ratione alias ipsam debitis culpa, a eius quasi nemo officiis aperiam tempore expedita deserunt doloremque. Repudiandae numquam expedita autem! Ratione, delectus magni? Quidem.
                        Eum commodi aspernatur unde adipisci sunt ratione, ea praesentium culpa sequi necessitatibus, similique nam alias accusantium doloremque non. Sit aliquam saepe minima delectus error? Laudantium, quasi. Dolor laboriosam dolorum tempore.
                        Hic accusamus animi excepturi voluptatem. Et perferendis fugit deserunt nesciunt? Ratione odit quam at nesciunt eligendi facere. Hic dolorem cupiditate, animi quo adipisci omnis dolor consectetur incidunt porro. Placeat, nostrum?
                        Nisi saepe facere tempore beatae. Libero, laboriosam maxime laudantium voluptatem suscipit provident. Sit, a. Dolorum a quaerat fugit dolore recusandae fugiat voluptatibus ipsa, in repudiandae culpa praesentium veritatis dolor distinctio!
                        Aliquid mollitia sapiente impedit in placeat maxime consequatur, ex quia corrupti dolor laborum quos animi. Dolorem autem ab ut amet dolore quis eius, iste et, voluptates ipsam incidunt accusantium expedita?
                        Iure cum dolores numquam deserunt dignissimos, libero praesentium repudiandae iusto fuga sequi! Aperiam possimus minus animi deserunt hic accusamus beatae ab praesentium totam quia iusto, at recusandae doloremque ipsam eius!
                        Hic, ducimus perferendis asperiores, totam excepturi odit labore dolorem expedita eligendi molestiae eum animi quisquam reprehenderit pariatur adipisci eius sint? Ipsam explicabo harum accusantium earum consectetur tempora repellat dolor molestias.
                        Consequuntur beatae pariatur reiciendis veniam maiores possimus deleniti qui harum obcaecati, ipsum commodi et dolor corporis quos cumque omnis, provident repudiandae molestias aliquam odit nam sit cupiditate. Reprehenderit, alias vel.
                        Voluptates ullam quidem quas natus aliquid architecto. Temporibus dolor ab earum molestiae. Asperiores, deleniti ullam ipsam, eos eaque harum error vero laborum modi dolorum possimus quisquam molestias quaerat, quia placeat!
                        Non ad dolores error ea quia, earum unde minima consequuntur qui voluptatibus, eligendi, fugit sed aperiam ab. Totam dolores iure quisquam perspiciatis atque? Voluptates optio provident repellat earum eos ipsum?
                        Non voluptatibus assumenda ipsam eum nemo, exercitationem repellat eius, culpa, sed maxime laboriosam quas. Tempore, et natus fuga repellendus dolores vero ipsum? Adipisci doloremque at asperiores iusto, amet praesentium quisquam.
                        Voluptatibus totam aperiam labore rerum. Possimus sit voluptatum asperiores sed vitae aliquid consectetur, officiis sunt ipsa facilis. Temporibus dicta incidunt iste ducimus! Consequatur incidunt ducimus impedit totam dolores, molestiae unde.
                        Minima necessitatibus nam veritatis! Repellendus porro aut voluptatem distinctio ab, facere nulla veritatis molestias pariatur magni suscipit alias sunt dolor deleniti blanditiis unde consequatur at accusantium harum, soluta culpa earum.
                        Obcaecati dolor magni fugit eligendi, natus cum nesciunt quisquam odio ipsam ipsa error accusantium dolores, quas at alias optio, quia doloremque. Eveniet, obcaecati? Suscipit at iste consequuntur omnis velit cumque.
                        Placeat inventore id nemo maiores aut, a itaque sapiente temporibus similique saepe incidunt doloribus quod harum doloremque magni vel odio voluptate soluta, rem laudantium eius aspernatur facere sit voluptatem! Quod.
                        Alias minima architecto perspiciatis. Minus aliquid veniam, sed nam amet accusantium necessitatibus deleniti quasi enim molestiae veritatis, at voluptates aliquam labore tenetur blanditiis cupiditate nemo deserunt error consequatur adipisci totam.
                        Ad ratione animi voluptas minima deserunt soluta laborum temporibus aperiam beatae similique voluptatibus doloremque, molestiae laudantium possimus asperiores? Cupiditate recusandae delectus laboriosam quos aut id aliquam ex ipsa velit illo.
                        Dignissimos officiis temporibus quasi praesentium eos animi illum eveniet sunt eaque atque, quos quidem quibusdam cumque neque vero repellendus nulla nostrum. Recusandae tempore illo vel quis distinctio repellendus earum odit!
                        Veniam officia voluptatibus velit optio nesciunt ullam blanditiis itaque nostrum illum consectetur eum explicabo unde rerum, odit praesentium possimus architecto animi quod eius, aperiam soluta hic dolor? Similique, esse voluptatem!
                        Esse, nisi saepe harum quia impedit repellendus soluta velit, est eius, obcaecati laborum? Cumque neque nobis tempora non, ullam deleniti officia omnis dolorem libero aliquid iusto mollitia nisi, consectetur in?
                        Accusantium suscipit pariatur qui aperiam quibusdam, quam minus optio! Vero vel quas, in aliquid quibusdam aspernatur nesciunt quo odio minima corporis exercitationem delectus. Nihil dolores pariatur quia accusantium esse architecto.
                        Dolores tempore facere asperiores veritatis quidem rerum totam nostrum beatae voluptate, ad commodi perferendis, ea modi recusandae aut? Similique maiores nesciunt illum velit impedit consequatur ipsum quia fugiat laboriosam dolorem?
                        Ullam doloribus inventore fugit blanditiis quas nesciunt dignissimos ratione? Nobis cum, illum dolorum deleniti, quaerat consequatur voluptas odit officia laudantium voluptates illo iste molestias fugiat eligendi explicabo minus aliquid ut.
                        Earum quos impedit modi non accusantium suscipit molestiae doloribus fugit! Dolores dolore molestias quae dignissimos consequuntur expedita, modi natus omnis quidem tempore fugit nesciunt! Dolorem ipsum quidem doloribus similique neque.
                    </p>

                    <div class="grey-block">
                        <div class="btitle">
                            <svg width="22" height="15" viewBox="0 0 22 15" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g id="Grupo_9515">
                                    <path id="Trazado_14585"
                                        d="M21.7025 6.72952C20.1311 5.00552 15.9355 0.962524 10.9924 0.962524C6.04925 0.962524 1.85368 5.00552 0.297503 6.72952C-0.0991678 7.1567 -0.0991678 7.82799 0.297503 8.27043C1.86893 9.99442 6.06451 14.0374 10.9924 14.0374C15.9203 14.0374 20.1311 9.99442 21.7025 8.27043C22.0992 7.84325 22.0992 7.17196 21.7025 6.72952ZM10.9924 12.0846C8.45979 12.0846 6.41541 10.0402 6.41541 7.5076C6.41541 4.97501 8.45979 2.93062 10.9924 2.93062C13.525 2.93062 15.5694 4.97501 15.5694 7.5076C15.5694 10.0402 13.525 12.0846 10.9924 12.0846Z"
                                        fill="#3B3B3B"></path>
                                    <path id="Elipse_300"
                                        d="M10.9923 9.91813C12.3236 9.91813 13.4028 8.83889 13.4028 7.50759C13.4028 6.17628 12.3236 5.09705 10.9923 5.09705C9.661 5.09705 8.58179 6.17628 8.58179 7.50759C8.58179 8.83889 9.661 9.91813 10.9923 9.91813Z"
                                        fill="#3B3B3B"></path>
                                </g>
                            </svg>
                            Seguir leyendo

                        </div>
                        <div class="blink">
                            <a href="#roulette" class="blink1">

                                <font class="link1"> El niño prodigio “sin revés” que revoluciona al tenis: Teodor
                                    Davidov se coronó en el Mundial Sub&nbsp;14</font>
                                <font class="link2">
                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect width="22" height="22" rx="11" fill="#EAEAEA"></rect>
                                        <path
                                            d="M15.7608 10.4985C15.4367 10.1744 13.1914 7.95221 12.3889 7.14974C12.2114 6.97227 12.0031 6.88739 11.7485 6.9414C11.5015 6.99542 11.3241 7.15745 11.2623 7.40437C11.1929 7.65128 11.2623 7.87505 11.4475 8.06795C12.1574 8.77011 13.7315 10.3442 13.7315 10.3442H6.65586C6.29321 10.3442 6 10.6374 6 11C6 11.3627 6.29321 11.6559 6.65586 11.6559H13.7392C13.7392 11.6559 12.1651 13.23 11.4552 13.9321C11.2701 14.1173 11.2006 14.3411 11.2701 14.5957C11.3395 14.8426 11.5093 14.997 11.7562 15.0587C12.0108 15.1127 12.2191 15.0278 12.3966 14.8504C13.1991 14.0556 15.7685 11.5016 15.7685 11.5016C16.0772 11.1929 16.0772 10.8149 15.7685 10.4985H15.7608Z"
                                            fill="#F68E01"></path>
                                    </svg>
                                </font>

                            </a>
                        </div>
                        <div class="blink">
                            <a href="#roulette" class="blink1">

                                <font class="link1">
                                    El impacto millonario que generó la relación entre Taylor Swift y Travis Kelce para
                                    la&nbsp;NFL y los Kansas&nbsp;City Chiefs camino al Super&nbsp;Bowl
                                </font>
                                <font class="link2">
                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect width="22" height="22" rx="11" fill="#EAEAEA"></rect>
                                        <path
                                            d="M15.7608 10.4985C15.4367 10.1744 13.1914 7.95221 12.3889 7.14974C12.2114 6.97227 12.0031 6.88739 11.7485 6.9414C11.5015 6.99542 11.3241 7.15745 11.2623 7.40437C11.1929 7.65128 11.2623 7.87505 11.4475 8.06795C12.1574 8.77011 13.7315 10.3442 13.7315 10.3442H6.65586C6.29321 10.3442 6 10.6374 6 11C6 11.3627 6.29321 11.6559 6.65586 11.6559H13.7392C13.7392 11.6559 12.1651 13.23 11.4552 13.9321C11.2701 14.1173 11.2006 14.3411 11.2701 14.5957C11.3395 14.8426 11.5093 14.997 11.7562 15.0587C12.0108 15.1127 12.2191 15.0278 12.3966 14.8504C13.1991 14.0556 15.7685 11.5016 15.7685 11.5016C16.0772 11.1929 16.0772 10.8149 15.7685 10.4985H15.7608Z"
                                            fill="#F68E01"></path>
                                    </svg>
                                </font>

                            </a>
                        </div>
                        <div class="blink">
                            <a href="#roulette" class="blink1">

                                <font class="link1">
                                    Estremecedor: un paracaidista intentó un salto extremo y murió tras arrojarse de un
                                    piso 29 en&nbsp;Tailandia
                                </font>
                                <font class="link2">
                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect width="22" height="22" rx="11" fill="#EAEAEA"></rect>
                                        <path
                                            d="M15.7608 10.4985C15.4367 10.1744 13.1914 7.95221 12.3889 7.14974C12.2114 6.97227 12.0031 6.88739 11.7485 6.9414C11.5015 6.99542 11.3241 7.15745 11.2623 7.40437C11.1929 7.65128 11.2623 7.87505 11.4475 8.06795C12.1574 8.77011 13.7315 10.3442 13.7315 10.3442H6.65586C6.29321 10.3442 6 10.6374 6 11C6 11.3627 6.29321 11.6559 6.65586 11.6559H13.7392C13.7392 11.6559 12.1651 13.23 11.4552 13.9321C11.2701 14.1173 11.2006 14.3411 11.2701 14.5957C11.3395 14.8426 11.5093 14.997 11.7562 15.0587C12.0108 15.1127 12.2191 15.0278 12.3966 14.8504C13.1991 14.0556 15.7685 11.5016 15.7685 11.5016C16.0772 11.1929 16.0772 10.8149 15.7685 10.4985H15.7608Z"
                                            fill="#F68E01"></path>
                                    </svg>
                                </font>

                            </a>
                        </div>

                    </div>

                    <div class="temas">
                        <div class="th1">
                            <svg width="12" height="12" viewBox="0 0 16 17" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M8 0.837891C8.40166 0.837891 8.72727 1.1635 8.72727 1.56516V16.1106C8.72727 16.5123 8.40166 16.8379 8 16.8379C7.59834 16.8379 7.27273 16.5123 7.27273 16.1106V1.56516C7.27273 1.1635 7.59834 0.837891 8 0.837891Z"
                                    fill="#1F1F1F"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M16 8.83789C16 9.23955 15.6744 9.56516 15.2727 9.56516L0.727273 9.56516C0.325611 9.56516 -1.75572e-08 9.23955 0 8.83789C1.75572e-08 8.43623 0.325611 8.11062 0.727273 8.11062L15.2727 8.11062C15.6744 8.11062 16 8.43623 16 8.83789Z"
                                    fill="#1F1F1F"></path>
                            </svg> Temas Relacionados
                        </div>
                        <div class="article-tags">
                            <a href="#roulette" class="gtl">México</a>
                            <a href="#roulette" class="gtl">Salud</a>
                            <a href="#roulette" class="gtl">Hipertensión</a>
                            <a href="#roulette" class="gtl">Noticias</a>
                        </div>
                    </div>
                    <div class="notias">
                        <div class="top-com">

                            <span class="orange">Últimas Noticias</span>
                        </div>

                        <div class="notio-group">
                            <div class="not-i">
                                <a class="nl" href="#roulette">
                                    <div class="nt nt1">
                                        <font class="ntt waw">El ex presidente chileno Ricardo Lagos anunció su retiro
                                            de la
                                            vida&nbsp;pública</font>
                                        <font class="ntb waw">Lo informó a través de un video publicado en sus redes
                                            sociales: “A mis 85&nbsp;años comienza un período de transformación en mi forma
                                            de contribuir desde un espacio más íntimo”, dijo el ex&nbsp;mandatario
                                        </font>
                                    </div>
                                    <div class="nimg nt1">
                                        <img loading="lazy" src="./img/n1.avif">
                                    </div>
                                </a>
                            </div>


                            <div class="not-i">
                                <a class="nl" href="#roulette">
                                    <div class="nt nt1 ltyt">
                                        <font class="ntt tal">Buscan profesionales argentinos para trabajar en&nbsp;Italia:
                                            qué requisitos piden y qué perfiles&nbsp;buscan</font>
                                        <font class="ntb tal">El consulado italiano se encuentra en la búsqueda de
                                            distintos profesionales médicos de varias especialidades, por lo que es una
                                            buena oportunidad para quienes quieren mudarse a&nbsp;Italia</font>
                                    </div>
                                    <div class="nimg nt1 nimg1 abi">
                                        <img loading="lazy" src="./img/w2.avif">
                                    </div>
                                </a>
                            </div>


                            <div class="not-i">
                                <a class="nl" href="#roulette">
                                    <div class="nt nt1 ltyt">
                                        <font class="ntt tal">Israel bombardeó posiciones del Ejército sirio en
                                            respuesta a un ataque con cohetes en los Altos del&nbsp;Golán</font>
                                        <font class="ntb tal">El Observatorio Sirio para los Derechos Humanos indicó que
                                            los objetivos fueron “instalaciones militares” en Tal al Jumu y Nafaa, sin
                                            que por el momento haya informaciones sobre las consecuencias. También hubo
                                            intercambios de disparos entre las&nbsp;FDI y Hezbollah en el sur del&nbsp;Líbano
                                        </font>
                                    </div>
                                    <div class="nimg nt1 nimg1 abi">
                                        <img loading="lazy" src="./img/w3.avif">
                                    </div>
                                </a>
                            </div>


                            <div class="not-i">
                                <a class="nl" href="#roulette">
                                    <div class="nt nt1 ltyt">
                                        <font class="ntt tal">El oficialismo logró quórum para debatir la Ley Ómnibus:
                                            se espera una maratónica sesión de más de 30&nbsp;horas</font>
                                        <font class="ntb tal">El tratamiento de la ley “Bases” en la Cámara Baja
                                            comenzará a las 10&nbsp;y se extendería por no menos de 35&nbsp;horas. El oficialismo
                                            se garantizó el quórum, pero desde la oposición buscan conocer la letra
                                            final de los artículos modificados</font>
                                    </div>
                                    <div class="nimg nt1 nimg1 abi">
                                        <img loading="lazy" src="./img/w4.avif">
                                    </div>
                                </a>
                            </div>


                            <div class="not-i">
                                <a class="nl" href="#roulette">
                                    <div class="nt nt1 ltyt">
                                        <font class="ntt tal">El vocero presidencial explicó la designación de Daniel
                                            Scioli: “Es un hombre de confianza del ministro Francos, y el presidente
                                            apoya a sus&nbsp;funcionarios”</font>
                                        <font class="ntb tal">El vocero presidencial fue consultado por las críticas que
                                            aparecieron en las últimas horas por la designación del exgobernador
                                            bonaerense al frente de la secretaría de Turismo, Deporte y&nbsp;Ambiente
                                        </font>
                                    </div>
                                    <div class="nimg nt1 nimg1 abi">
                                        <img loading="lazy" src="./img/w5.avif">
                                    </div>
                                </a>
                            </div>







                        </div>
                    </div>
                    <a href="#roulette" class="last-b" style="margin-top:25px;">
                        MÁS NOTICIAS
                    </a>

                    <div class="disap">
                        <div class="rc1">
                            <a class="rct" href="#roulette">
                                <span>Lo Último</span>
                                <span style="font-weight: 300;">|</span>
                                <span style="font-weight: 300;">Deportes</span>
                            </a>
                        </div>


                        <div class="rc2">
                            <a href="#roulette">
                                <span>La profunda reflexión del Kun Agüero sobre su hijo Benjamín tras su fichaje en las
                                    inferiores de&nbsp;Independiente</span>
                                <img loading="lazy" src="./img/f11.avif">
                            </a>

                            <a href="#roulette">
                                Las opciones de futuro de Carlos Sainz en la F1 si abandona&nbsp;Ferrari
                            </a>
                            <a href="#roulette">
                                Marcó la carrera de Messi, dejó el fútbol por la hotelería y podría volver del retiro
                                tras 10
                                años para reemplazar a Xavi en&nbsp;Barcelona
                            </a>

                            <a href="#roulette">
                                River aceleró en el mercado: la revisión médica de Sant’Anna, el otro refuerzo que está
                                cerrado
                                y la frase de Demichelis sobre Luciano&nbsp;Rodríguez
                            </a>

                            <a href="#roulette">
                                El Inter de Miami de Messi se enfrentará al Al&#8209;Nassr de Cristiano Ronaldo, ausente del
                                amistoso
                                por una lesión: hora, TV y&nbsp;formaciones
                            </a>
                        </div>


                        <div class="rc1" style="margin-top:40px">
                            <a class="rct" href="#roulette">
                                Te Recomendamos
                            </a>
                        </div>

                        <div class="rc2 rtc2">
                            <a href="#roulette">
                                <span class="most-read-card-number">1</span>
                                <span>El entrenador de la selección de Portugal aseguró que se equivocó al votar para
                                    los The
                                    Best: “Creo que no fui el&nbsp;único”</span>
                                <img loading="lazy" src="./img/l1.avif">
                            </a>

                            <a href="#roulette">
                                <span class="most-read-card-number">2</span>
                                <span>9 frases de Mascherano tras el 5-0&nbsp;de Argentina ante Chile: por qué fue titular el
                                    Diablito Echeverri y la “injusticia” que comete con una&nbsp;figura</span>
                                <img loading="lazy" src="./img/l2.avif">
                            </a>


                            <a href="#roulette">
                                <span class="most-read-card-number">3</span>
                                <span> Una de las figuras del ascenso del Leeds reveló detalles del método Bielsa: “El
                                    día a día
                                    era mentalmente&nbsp;agotador”</span>
                                <img loading="lazy" src="./img/l3.avif">
                            </a>

                            <a href="#roulette">
                                <span class="most-read-card-number">4</span>
                                <span> El niño prodigio “sin revés” que revoluciona al tenis: Teodor Davidov se coronó
                                    en el
                                    Mundial Sub&nbsp;14</span>
                                <img loading="lazy" src="./img/l4.avif">
                            </a>
                            <a href="#roulette">
                                <span class="most-read-card-number">5</span>
                                <span>Argentina goleó 5-0&nbsp;a Chile, avanzó a la fase final del Preolímpico y dejó afuera
                                    al
                                    Uruguay de&nbsp;Bielsa</span>
                                <img loading="lazy" src="./img/l5.avif">
                            </a>
                        </div>
                    </div>








                </div>



            </div>









            <div class="right-con">




                <div class="rc1">
                    <a class="rct" href="#roulette">
                        <span>Lo Último</span>
                        <span style="font-weight: 300;">|</span>
                        <span style="font-weight: 300;">Deportes</span>
                    </a>
                </div>


                <div class="rc2">
                    <a href="#roulette">
                        <span>La profunda reflexión del Kun Agüero sobre su hijo Benjamín tras su fichaje en las
                            inferiores de&nbsp;Independiente</span>
                        <img loading="lazy" src="./img/f11.avif">
                    </a>

                    <a href="#roulette">
                        Las opciones de futuro de Carlos Sainz en la&nbsp;F1 si abandona&nbsp;Ferrari
                    </a>
                    <a href="#roulette">
                        Marcó la carrera de Messi, dejó el fútbol por la hotelería y podría volver del retiro tras 10&nbsp;años para reemplazar a Xavi en&nbsp;Barcelona
                    </a>

                    <a href="#roulette">
                        River aceleró en el mercado: la revisión médica de Sant’Anna, el otro refuerzo que está cerrado
                        y la frase de Demichelis sobre Luciano&nbsp;Rodríguez
                    </a>

                    <a href="#roulette">
                        El Inter de Miami de Messi se enfrentará al Al-Nassr de Cristiano Ronaldo, ausente del amistoso
                        por una lesión: hora, TV y&nbsp;formaciones
                    </a>
                </div>


                <div class="rc1" style="margin-top:40px">
                    <a class="rct" href="#roulette">
                        Te Recomendamos
                    </a>
                </div>

                <div class="rc2 rtc2">
                    <a href="#roulette">
                        <span class="most-read-card-number">1</span>
                        <span>El entrenador de la selección de Portugal aseguró que se equivocó al votar para los The
                            Best: “Creo que no fui el&nbsp;único”</span>
                        <img loading="lazy" src="./img/l1.avif">
                    </a>

                    <a href="#roulette">
                        <span class="most-read-card-number">2</span>
                        <span>9 frases de Mascherano tras el 5-0 de Argentina ante Chile: por qué fue titular el
                            Diablito Echeverri y la “injusticia” que comete con una&nbsp;figura</span>
                        <img loading="lazy" src="./img/l2.avif">
                    </a>


                    <a href="#roulette">
                        <span class="most-read-card-number">3</span>
                        <span> Una de las figuras del ascenso del Leeds reveló detalles del método Bielsa: “El día a día
                            era mentalmente&nbsp;agotador”</span>
                        <img loading="lazy" src="./img/l3.avif">
                    </a>

                    <a href="#roulette">
                        <span class="most-read-card-number">4</span>
                        <span> El niño prodigio “sin revés” que revoluciona al tenis: Teodor Davidov se coronó en el
                            Mundial Sub&nbsp;14</span>
                        <img loading="lazy" src="./img/l4.avif">
                    </a>
                    <a href="#roulette">
                        <span class="most-read-card-number">5</span>
                        <span>Argentina goleó 5-0 a Chile, avanzó a la fase final del Preolímpico y dejó afuera al
                            Uruguay de&nbsp;Bielsa</span>
                        <img loading="lazy" src="./img/l5.avif">
                    </a>
                </div>



                <div class="side-banner">
                    <img src="./img/order_tube.png" loading="lazy" alt="Coradeluz">
                    <a href="#roulette">
                    PIDO "CORADELUZ"
                    </a>
                </div>
            </div>
        </div>



        <div class="gr-not con">
            <a href="#roulette" class="gri">


                <div class="top-com">

                    <span class="orange" style="text-transform:uppercase;font-size:22px;">Últimas Noticias</span>
                </div>

                <div class="gri1">
                    <div class="card">
                        <img loading="lazy" src="./img/feed1.avif">
                    </div>
                    <div class="card-text">
                        Milei habló con el fundador de Tinder y anticipó que se reunirán en Buenos&nbsp;Aires
                    </div>
                </div>

                <div class="gri2">
                    <font>
                        ¿Por qué nos despertamos antes de que suene la alarma? Las 6&nbsp;razones clave según los
                        expertos en&nbsp;sueño
                    </font>
                    <font>
                        Detuvieron a cuatro mujeres en la protesta frente al Congreso y la&nbsp;UCR criticó el
                        operativo policial
                    </font>
                    <font>
                        Debate de la ley ómnibus de Milei, en vivo: las últimas noticias sobre la votación
                        en la Cámara de&nbsp;Diputados
                    </font>
                    <font style="border-bottom: 1px solid #d5d5d5;">
                        Hay 20 provincias bajo alerta por temperaturas extremas: ¿hasta cuándo durará la ola
                        de&nbsp;calor?
                    </font>
                </div>
            </a>













            <a href="#roulette" class="gri">


                <div class="top-com">

                    <span class="orange" style="text-transform:uppercase;font-size:22px;">Infobae américa</span>
                </div>

                <div class="gri1">
                    <div class="card">
                        <img loading="lazy" src="./img/feed2.avif">
                    </div>
                    <div class="card-text">
                        Femicidio en Punta del Este: comienza el juicio por Valentina y aseguran que su ex
                        novio no tendrá la pena&nbsp;máxima
                    </div>
                </div>

                <div class="gri2">
                    <font>
                        Un niño de tres años quedó atrapado en una máquina de peluches: “Se estaba
                        divirtiendo como&nbsp;nunca”
                    </font>
                    <font>
                        Se está formando una doctrina Biden para Oriente Medio, y es algo&nbsp;grande
                    </font>
                    <font>
                        El gobierno de Lula da Silva cuestionó la autonomía del Banco Central mientras
                        negocia una&nbsp;reforma
                    </font>
                    <font style="border-bottom: 1px solid #d5d5d5;">
                        La Unión Europea acordó un paquete de ayuda a Ucrania de 54&nbsp;mil millones de dólares
                        para resistir la invasión de&nbsp;Rusia
                    </font>
                </div>
            </a>










            <a href="#roulette" class="gri">


                <div class="top-com">

                    <span class="orange"
                        style="text-transform:uppercase;font-size:22px; border-bottom-color: #b10000;">Teleshow</span>
                </div>

                <div class="gri1">
                    <div class="card">
                        <img loading="lazy" src="./img/feed3.avif">
                    </div>
                    <div class="card-text">
                        El reencuentro más tierno: los ex GH conocieron a las gemelas de Daniela y&nbsp;Thiago
                    </div>
                </div>

                <div class="gri2">
                    <font>
                        Mirtha Legrand fue a ver el espectáculo de Fátima Florez por segunda vez en Mar del
                        Plata: “Estoy&nbsp;emocionada”
                    </font>
                    <font>
                        Cruces, enfrentamientos y un duelo picante: así quedó la placa de nominados XL&nbsp;en&nbsp;GH
                    </font>
                    <font>
                        El Kun Agüero habló sobre los rumores de embarazo de su novia: “Con Sofía está en
                        los planes ser&nbsp;padres”
                    </font>
                    <font style="border-bottom: 1px solid #d5d5d5;">
                        La emotiva despedida de un cronista de Intrusos tras siete años en el programa: “No
                        fue una decisión&nbsp;fácil”
                    </font>
                </div>
            </a>





        </div>

        <div class="footer">
            <div class="footer-con">
                <div class="f1">
                    <img loading="lazy" src="./img/logo-white.svg">
                    <font class="f1-t">
                        Seguinos:
                    </font>
                    <div class="group-media">
                        <a href="#roulette" class="medial">
                            <svg class="svg-icon" width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect class="svg-icon-bg" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    fill="transparent"></rect>
                                <path
                                    d="M14.1487 24.9911V15.914H11.5V13.0014H14.1487V12.7155C14.1487 11.9293 14.1202 11.1342 14.1867 10.348C14.1867 9.09719 14.9462 7.96255 16.1424 7.41756C16.5886 7.22101 17.0633 7.09593 17.5475 7.04233C18.5348 6.97086 19.5222 6.98872 20.5 7.10487V9.72258H20.2437C19.6836 9.72258 19.1329 9.72258 18.5728 9.74045C17.9462 9.70471 17.4051 10.1514 17.3671 10.7411C17.3671 10.7947 17.3671 10.8393 17.3671 10.893C17.3481 11.5541 17.3671 12.2152 17.3671 12.8763C17.3671 12.9121 17.3671 12.9567 17.3861 12.9925H20.4335C20.3006 13.9842 20.1677 14.9401 20.0348 15.9229H17.3766V25H14.1582L14.1487 24.9911Z"
                                    fill="#9B9B9B"></path>
                                <rect class="svg-icon-border" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    stroke="#9B9B9B"></rect>
                            </svg>
                        </a>

                        <a href="#roulette" class="medial">
                            <svg class="svg-icon" width="22" height="22" viewBox="0 0 22 22" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect class="svg-icon-bg" x="0.5" y="0.5" width="21" height="21" rx="10.5"
                                    fill="transparent"></rect>
                                <path
                                    d="M5.02929 5L9.66241 11.6187L5 17H6.04927L10.1311 12.2887L13.4292 17H17L12.1063 10.009L16.446 5H15.3967L11.6375 9.3391L8.60005 5H5.02929ZM6.57235 5.82578H8.21282L15.4568 16.174H13.8163L6.57235 5.82578Z"
                                    fill="#9B9B9B"></path>
                                <rect class="svg-icon-border" x="0.5" y="0.5" width="21" height="21" rx="10.5"
                                    stroke="#9B9B9B"></rect>
                            </svg>
                        </a>

                        <a href="#roulette" class="medial">
                            <svg class="svg-icon" width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect class="svg-icon-bg" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    fill="transparent"></rect>
                                <path
                                    d="M20.3321 10.752C19.7952 10.736 19.3487 11.1413 19.3381 11.68C19.3275 12.2187 19.7368 12.6453 20.2577 12.6667C20.7946 12.6827 21.2411 12.2667 21.2517 11.7387C21.2623 11.2107 20.853 10.7733 20.3321 10.752Z"
                                    fill="#9B9B9B"></path>
                                <path
                                    d="M24 13.7651C24 13.1785 23.9522 12.5865 23.899 11.9998C23.6864 9.96246 22.3149 8.44779 20.3056 8.15979C19.3116 8.02112 18.2857 7.99979 17.2757 7.99979C15.5429 7.99979 13.7993 7.98912 12.0664 8.11179C9.90831 8.26112 8.33488 9.86113 8.15947 12.0265C8.04784 13.3491 8.04784 14.6771 8 16.0158C8.05316 17.3385 8.05316 18.6771 8.16478 20.0051C8.32957 22.0318 9.74884 23.5571 11.7528 23.8451C12.7628 23.9838 13.7887 24.0051 14.8093 24.0051C16.5422 24.0051 18.2751 24.0158 19.9973 23.8931C21.592 23.7705 22.804 22.9545 23.511 21.4665C23.8193 20.8158 23.9575 20.1171 23.9628 19.4025L23.9522 19.4131C23.9787 17.5358 24 15.6478 24 13.7705V13.7651ZM22.4904 19.6051C22.4425 21.3171 21.3422 22.4105 19.6359 22.4585C17.2385 22.5225 14.8252 22.5225 12.4173 22.4585C10.7322 22.4105 9.62658 21.3171 9.58405 19.6211C9.52027 17.2051 9.52027 14.7785 9.58405 12.3518C9.63189 10.6611 10.7322 9.62112 12.4173 9.49846C13.0179 9.46113 13.6292 9.44512 14.2352 9.43446C14.8306 9.42379 18.4505 9.43446 19.6625 9.50912V9.49846C21.3422 9.59979 22.4425 10.6611 22.4904 12.3358C22.5542 14.7518 22.5542 17.1785 22.4904 19.6051Z"
                                    fill="#9B9B9B"></path>
                                <path
                                    d="M16.0533 11.8773C13.7835 11.8667 11.939 13.7173 11.939 15.9947C11.939 18.272 13.7569 20.096 16.0267 20.1013C18.2964 20.112 20.141 18.2613 20.141 15.984C20.141 13.7067 18.323 11.8773 16.0533 11.8773ZM16.0426 18.672C14.5702 18.672 13.3742 17.4613 13.3742 15.984C13.3848 14.5173 14.5755 13.328 16.0373 13.328H16.0479C17.5097 13.328 18.7004 14.528 18.7004 15.9947C18.7004 17.4613 17.515 18.672 16.0479 18.672H16.0426Z"
                                    fill="#9B9B9B"></path>
                                <rect class="svg-icon-border" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    stroke="#9B9B9B"></rect>
                            </svg>
                        </a>

                        <a href="#roulette" class="medial">
                            <svg class="svg-icon" width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect class="svg-icon-bg" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    fill="transparent"></rect>
                                <path
                                    d="M23.9297 14.1599C23.8592 13.526 23.8064 12.8863 23.6832 12.2583C23.5071 11.372 22.8438 10.7792 21.9517 10.6794C21.0654 10.5796 20.1674 10.4857 19.2752 10.4681C17.4029 10.427 15.5247 10.4153 13.6523 10.4387C12.5606 10.4505 11.4689 10.5444 10.3772 10.6207C10.0192 10.6442 9.66701 10.7087 9.33832 10.8848C8.69269 11.237 8.35813 11.8004 8.24661 12.5165C8.02358 13.8958 7.97075 15.281 8.01771 16.672C8.04705 17.4703 8.11749 18.2685 8.18792 19.0668C8.2114 19.3485 8.26422 19.6361 8.35226 19.9061C8.63399 20.7572 9.25028 21.2267 10.1248 21.3089C11.152 21.4087 12.1791 21.4967 13.2063 21.526C14.6267 21.5671 16.0471 21.5789 17.4733 21.5613C18.7118 21.5437 19.9502 21.4674 21.1887 21.4028C21.5115 21.3852 21.8343 21.3441 22.1454 21.2737C23.0199 21.0682 23.5364 20.4989 23.7125 19.6244C23.8768 18.8085 23.9238 17.9751 23.9649 17.1416C23.9708 16.9831 23.9884 16.8247 24.0001 16.6603V15.2223C23.9766 14.8643 23.9708 14.5062 23.9297 14.1482V14.1599ZM14.4036 18.3918V13.5906C15.7947 14.3888 17.1681 15.1812 18.5768 15.9912C17.1798 16.7953 15.8064 17.5877 14.4036 18.3918Z"
                                    fill="#E2E2E2"></path>
                                <rect class="svg-icon-border" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    stroke="#E2E2E2"></rect>
                            </svg>
                        </a>
                        <a href="#roulette" class="medial">
                            <svg class="svg-icon" width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect class="svg-icon-bg" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    fill="transparent"></rect>
                                <path
                                    d="M22.8408 8.74494L6.38303 14.9306C6.07012 15.0449 5.91789 15.3794 6.04475 15.6814C6.11241 15.8446 6.2562 15.9752 6.4338 16.0241L10.6201 17.2156L12.1847 21.9976C12.3031 22.3648 12.709 22.5688 13.0812 22.4546C13.1911 22.422 13.2926 22.3567 13.3772 22.2751L15.5422 20.1452L19.7877 23.1482C20.1852 23.4257 20.735 23.3441 21.0225 22.9606C21.0986 22.8626 21.1494 22.7484 21.1747 22.6341L23.9825 9.66708C24.0756 9.22641 23.788 8.7939 23.3313 8.70414C23.1706 8.67149 23.0015 8.68782 22.8492 8.74494M20.7857 11.6256L13.1404 18.154C13.0643 18.2193 13.0135 18.3091 13.0051 18.407L12.709 20.9286C12.709 20.9694 12.6668 21.002 12.6245 20.9939C12.5906 20.9939 12.5653 20.9694 12.5568 20.9449L11.3474 17.1747C11.2882 17.0034 11.3644 16.8157 11.525 16.7178L20.5573 11.3155C20.6504 11.2584 20.7772 11.291 20.828 11.3808C20.8787 11.4624 20.8618 11.5603 20.7941 11.6256"
                                    fill="#9B9B9B"></path>
                                <rect class="svg-icon-border" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    stroke="#9B9B9B"></rect>
                            </svg>
                        </a>

                        <a href="#roulette" class="medial">
                            <svg class="svg-icon" width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect class="svg-icon-bg" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    fill="transparent"></rect>
                                <path
                                    d="M13.5556 24V13.2231H16.963V14.6949C17.0185 14.6368 17.0648 14.5787 17.1111 14.5206C17.8611 13.349 19.2037 12.739 20.537 12.981C22.3889 13.1359 23.8426 14.7046 23.9259 16.6411C23.9722 17.0478 24 17.4641 24 17.8708C24 19.817 24 21.7633 24 23.7095V23.9806H20.5741V23.6805C20.5741 21.8892 20.5741 20.0882 20.5741 18.2969C20.5741 17.8805 20.5278 17.4545 20.4259 17.0478C20.1945 16.1279 19.2963 15.5663 18.4074 15.8084C18.2037 15.8665 18 15.9633 17.8333 16.0989C17.3333 16.4281 17.0185 16.9897 16.9907 17.6094C16.9722 18.1419 16.9722 18.6842 16.9722 19.2167V23.9903H13.5648L13.5556 24ZM8.22221 24V13.2037H8.74073C9.62036 13.2037 10.5 13.2037 11.3796 13.2037C11.5833 13.2037 11.6482 13.2328 11.6482 13.4748V23.9903H8.22221V24ZM8.00927 9.88254C8.00927 8.84648 8.80555 8.00408 9.78703 8.00408C9.84259 8.00408 9.89816 8.00408 9.95372 8.00408C10.9445 7.9363 11.7963 8.72061 11.8611 9.75666C11.8611 9.79539 11.8611 9.84381 11.8611 9.88254C11.8426 10.9283 11.0278 11.761 10.0278 11.7416C9.99074 11.7416 9.95369 11.7416 9.92591 11.7416H9.90741C8.92592 11.8191 8.07407 11.0445 8 10.0181C8 9.96968 8 9.93095 8 9.88254H8.00927Z"
                                    fill="#9B9B9B"></path>
                                <rect class="svg-icon-border" x="0.5" y="0.5" width="31" height="31" rx="15.5"
                                    stroke="#9B9B9B"></rect>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="f2">
                    <a href="#roulette" class="f2mt f2m">
                        Secciones
                    </a>
                    <div class="grlink">
                        <a href="#roulette" class="f2m">
                            América
                        </a>
                        <a href="#roulette" class="f2m">
                            Colombia
                        </a>
                        <a href="#roulette" class="f2m">
                            España
                        </a>

                        <a href="#roulette" class="f2m">
                            México
                        </a>
                        <a href="#roulette" class="f2m">
                            RSS
                        </a>

                        <a href="#roulette" class="f2m">
                            Perú
                        </a>
                        <a href="#roulette" class="f2m">
                            Últimas Noticias
                        </a>
                    </div>



                </div>
                <div class="f2">
                    <a href="#roulette" class="f2mt f2m">
                        Contáctenos
                    </a>
                    <div class="grlink">
                        <a href="#roulette" class="f2m">
                            Contacto
                        </a>
                        <a href="#roulette" class="f2m">
                            Redacción
                        </a>
                        <a href="#roulette" class="f2m">
                            Contacto comercial
                        </a>

                        <a href="#roulette" class="f2m">
                            Media Kit
                        </a>
                        <a href="#roulette" class="f2m">
                            Empleo
                        </a>

                    </div>

                </div>
                <div class="f2">
                    <a href="#roulette" class="f2mt f2m">
                        Legales
                    </a>
                    <div class="grlink">
                        <a href="#roulette" class="f2m">
                            Términos y Condiciones
                        </a>
                        <a href="#roulette" class="f2m">
                            Política de Privacidad
                        </a>
                    </div>
                </div>
            </div>


            <div class="footer-under con    ">
                <span class="nowyear"></span> Infobae
            </div>
        </div>



    </div>
















    <!---------- COMEBACKER ---------->

    <div style="position: absolute; left: -1000px; top: -1000px; font-family: 'Open Sans', sans-serif !important;">
        Font Preload and <img loading="lazy" src="./img/order_tube.png">
    </div>
    <div class="e-comebacker js-comebacker-close-capture" id="e-comebacker">
        <div class="e-comebacker__inner js-comebacker-close-capture">
            <div class="e-comebacker__content popin-anim e-comebacker-active" id="e-comebacker-leave">
                <!-- MODAL 1 -->
                <div class="modal-leave">
                    <div class="modal-leave__info">
                        <div class="modal-leave__title">¡Espere!</div>
                        <div class="modal-leave__motivation">¡Elimine la hipertensión y los problemas vasculares para
                            siempre<br><strong><a style="text-decoration: underline!important"
                                    class="modal-leave__btn-motivation js-modal-leave-next"
                                    data-target="e-comebacker-offer" type="button"> en solo 40&nbsp;días!</a></strong>

                        </div>
                        <div class="modal-leave__text">
                            Puede obtenerr «CORADELUZ» con una promoción única.<span class="inner-red">Esta promoción es
                                especialmente para&nbsp;usted.</span>
                        </div>
                        <div class="modal-leave__text">
                            <span class="inner-red">¡ATENCIÓN!</span> Le recomendamos que se apresure. La oferta vence
                            en

                            15&nbsp;minutos.
                        </div>
                        <div class="modal-leave__btn-wrapper">
                            <button class="modal-leave__btn-next js-modal-leave-next" data-target="e-comebacker-offer"
                                type="button">SABER MÁS</button>
                            <button class="modal-leave__btn-no js-comebacker-close" type="button">No gracias, prefiero
                                perder la oportunidad...</button>
                        </div>
                    </div>
                    <div class="modal-leave__product-view">
                        <div class="modal-leave__on-sale">
                            <div class="modal-leave__sale-label">-<span class="e-comebacker__percent">100%</span></div>
                            <img loading="lazy" class="modal-leave__image" src="./img/order_tube.png">
                        </div>
                    </div>
                </div>
            </div>
            <!-- MODAL 2 -->
            <div class="e-comebacker__content fadeIn-anim" id="e-comebacker-offer">
                <div class="modal-offer">
                    <div class="modal-offer__title modal-offer__title--second">
                        ¡Una oferta solo para usted!</div>
                    <div class="modal-offer__timer">
                        <div class="modal-offer__timer-label"><strong>termina en:</strong></div>
                        <div class="modal-offer__timer-time js-custom-timer">
                            <span class="__min">00</span> : <span class="__sec">00</span>
                        </div>
                    </div>
                    <div class="modal-offer__promo">
                        <div class="modal-offer__price">
                            <span style="font-size: 20px;">precio:</span>
                            <span class="bespl"><span><span class="pl_special_price">{{p_special_price}}</span> <span
                                        class="str">{{currency_tiny}}</span></span></span>
                        </div>
                        <div class="modal-offer__product">
                            <img loading="lazy" class="__image" src="./img/order_tube.png">
                        </div>
                    </div>
                    <div class="modal-offer__cong-text">
                        <div class="__title">¡Felicidades!</div>
                        <div class="cong-text__p">¡Tiene una única oportunidad para obtener «CORADELUZ» a un precio
                            de&nbsp;<strong><span class="e-comebacker__price"><span
                                        style="text-transform:lowercase;"><span
                                            class="pl_special_price">{{p_special_price}}</span>&nbsp;euros!</span></span></strong>
                            Aproveche esta oportunidad única ahora mismo: ¡la oferta está disponible <strong>solo 1&nbsp;vez!</strong> </div>
                        <div class="cong-text__p">Disponible solo para usted y únicamente por el plazo de <strong>15&nbsp;minutos.</strong>
                        </div>
                    </div>
                    <form class="modal-offer__form" action="" method="POST">
                        <div class="modal-offer__field">
                            <div class="__wrapper">
                                <label class="__label">País:</label>
                                <select class="__input" name="order[country]">{{country_options}}</select>
                            </div>
                        </div>
                        <div class="modal-offer__field">
                            <div class="__wrapper">
                                <label class="__label">Teléfono:</label>
                                <input class="__input __input--phone" type="tel" name="order[phone]"
                                    placeholder="Teléfono" />
                            </div>
                        </div>
                        <div class="modal-offer__field">
                            <div class="__wrapper">
                                <label class="__label">Su nombre:</label>
                                <input class="__input" type="text" name="order[fio]" placeholder="Ingrese tu nombre" />
                            </div>
                        </div>
                        <div class="modal-offer__field">
                            <label class="__label"> </label>
                            <button class="modal-offer__btn-submit" type="submit"
                                onclick="$(this).closest('form').submit();return false;">
                                <div class="__bg"></div>
                                <span class="__text">HACER EL PEDIDO</span>
                            </button>
                            <font class="comebacker__snoska">*al pedir desde 1&nbsp;curso</font>
                        </div>
                        <input type="hidden" name="order[specifications]" value="" />
                        <input type="hidden" name="order[discount]" value="" />
                        {{form_inviz}}
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    var time = 600;
    var intr;

    function start_timer() {
        intr = setInterval(tick, 1000);
    }

    function tick() {
        time = time - 1;
        var mins = Math.floor(time / 60);
        var secs = time - mins * 60;
        if (mins == 0 && secs == 0) {
            clearInterval(intr);
        }
        secs = secs >= 10 ? secs : "0" + secs;
        $("#min").html("0" + mins);
        $("#sec").html(secs);
    }
    </script>

    <script>
    var triesCount = 2;
    var tries = 0;
    $('#tries_count').text(triesCount);
    $('.try').on('click', function() {
        if ((!$(this).parent('.boxes_item').hasClass('afterlose-boxes_item')) && (!$('#boxesContainer')
                .hasClass('stop_trying'))) {
            if (tries == 0) {
                $('#boxesContainer').addClass('stop_trying');
                $(this).attr('src', './img/download.png');
                $(this).addClass('shake');
                $(this).parent('.boxes_item').addClass('afterlose-boxes_item');
                $('.box-tooltip-title').html(
                    '<b>No ganaras nada</b><br> Te queda <span style="color: red;">1 intento</span>! ¡Intentar otra&nbsp;vez!'
                );
                $('.box-tooltip-btn').html('intentar');
                setTimeout(function() {
                    $('.box-popup-wrapper.tooltip').fadeIn(100);
                }, 850);
            }
            if (tries == 1) {
                $('#boxesContainer').addClass('stop_trying');
                $(this).parent('.boxes_item').html('<p class="win_prize">50% de descuento</p>');
                $('.box-tooltip-title').html(
                    '<b>Felicidades!</b><br>Tus ganancias:<br><b style="color: red;">50% de descuento</b>'
                );
                $('.box-tooltip-btn').html('HACER UN PEDIDO');
                $('.box-tooltip-ico>img').attr('src', './img/congrat.png');
                setTimeout(function() {
                    $('.box-popup-wrapper.tooltip').fadeIn(100);
                }, 1000);
            }
        }
    });

    $('.box-popup-wrapper.tooltip').bind('click', function(e) {
        $('#boxesContainer').removeClass('stop_trying');
        $('.box-popup-wrapper').fadeOut(90);
        tries++;
        triesCount--;
        $('#tries_count').html('<span style="color: red;">' + triesCount + '</span>');
        if (tries == 2) {
            $('#boxesContainer').slideUp('fast');
            $('.lead-form-box').slideDown('fast');
            start_timer();

        }
    });
    </script>

    <script>
    function isLogo1Visible() {
        const logo1 = document.querySelector('.logo1');
        if (!logo1) return false;

        const logo1Rect = logo1.getBoundingClientRect();
        return logo1Rect.top >= 0 && logo1Rect.bottom <= window.innerHeight;
    }

    // Function to handle scroll events
    function handleScroll() {
        const smallLogo = document.querySelector('.small-logo');

        if (!smallLogo) return; // Check if .small-logo exists

        if (isLogo1Visible()) {
            smallLogo.style.display = 'none'; // Hide .small-logo when .logo1 is visible
        } else {
            smallLogo.style.display = 'block'; // Show .small-logo otherwise
        }
    }

    // Attach the scroll event listener
    window.addEventListener('scroll', handleScroll);

    // Call handleScroll initially to set the initial state based on the page load
    handleScroll();
    </script>

    <script src="./dist/bundle.js"></script>

</body>

</html>
