import '../css/main.scss';
//------------------------


 // Months in Spanish
 const monthsInSpanish = [
    'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
    'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'
];

// Get the current date and month
const currentDate = new Date();
const currentMonth = currentDate.getMonth(); // 0-based index

// Get the <span> element with the class "current_month"
const currentMonthElement = document.querySelector('.current_month');

// Set the innerHTML of the element to the current month in Spanish
currentMonthElement.innerHTML = monthsInSpanish[currentMonth];



 const target = 'a[href^="#"]';
 
 function getElementY(query) {
     if(document.querySelector(query) !== null && document.querySelector(query) !== undefined) {
         return window.pageYOffset + document.querySelector(query).getBoundingClientRect().top;
     }
 }

 document.querySelectorAll(target).forEach(anchor => {
     anchor.addEventListener('click', function (e) {
         e.preventDefault();

         if(this.getAttribute('href') !== '#') {
             const targetID = this.getAttribute('href');
             const target_Y = getElementY(targetID);

             let scroll = (targetY) => {
                 window.scrollTo({
                     top: targetY,
                     behavior: 'smooth'
                 })
                 setTimeout(() => {
                     const targetY_again = getElementY(targetID);
                     if (targetY !== targetY_again) {
                         scroll(targetY_again)
                     }
                 }, 700)
             }
             scroll(target_Y)

         }
     });
 });




 $(document).ready(function() {
    setTimeout(function() {
        $('.ffl').addClass('ffl__anim')
    }, 300)
})

$(window).on('load resize', function() {
    let fflHeight = $('.ffl').outerHeight();
    if ($(window).width() < 469 && !$('.ffl').hasClass('ffl__out')) {
        $('.footer').css('padding-bottom', fflHeight + 'px')
    } else {
        $('.footer').css('padding-bottom', '0')
    }
})

$('.ffl__close, .ffl__btn').on('click', function(){
    $('.ffl').addClass('ffl__out')
    $('.footer').css('padding-bottom', '0')
})

jQuery( document ).ready(function() {
    $('.ffl__close, .ffl__btn').on('click', function(){
        $('.ffl').addClass('ffl__out')
        $('.footer').css('padding-bottom', '0')
    })
});