window.addEventListener('scroll', function () {
	var scrollPosition = window.scrollY;
	var headerElement = document.querySelector('.css-11afnc1');

	if (scrollPosition > 200) {
		headerElement.style.display = 'block';
	} else {
		headerElement.style.display = 'none';
	}
});
