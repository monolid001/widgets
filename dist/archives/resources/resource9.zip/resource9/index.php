<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover"
      id="MetaViewport"
    />
    <meta
      name="robots"
      content="max-snippet:-1, max-image-preview:large, max-video-preview:-1"
    />
    <title>
      Der neue Methode zur Reinigung der Augengefäße wird die Blutversorgung der
      Linse wiederherstellen und für immer von Augenkrankheiten befreien!
    </title>
    <meta name="language" content="de" />
    <meta
      name="theme-color"
      content="#FFFFFF"
      media="(prefers-color-scheme: light)"
    />
    <meta
      name="theme-color"
      content="#0A0C14"
      media="(prefers-color-scheme: dark)"
    />
    <link rel="stylesheet" href="./dist/bundle.css" />

    <script
      src="https://code.jquery.com/jquery-3.7.1.min.js"
      integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
      crossorigin="anonymous"
    ></script>
  </head>

  <body id="tonline-top" class>
    <div id="__next">
      <header class="css-1fezxdr" data-testid="PageHeader" role="banner">
        <div class="css-1x2681d">
          <nav class="css-889j7l">
            <div class="css-1l6c000">
              <div class="css-kvylio">
                <a class="css-15b93or" href="#roulette" tabindex="0"
                  ><span class="css-s5xdrg"
                    ><i class="css-zjik7"
                      ><img
                        loading="lazy"
                        src="./fonts/cloudy-c241b61050ca74e919de22ed36892d12.svg"
                        alt="Teilweise bewölkt"
                        title="Teilweise bewölkt"
                        width="21"
                        height="21"
                        class="css-4zleql"
                        decoding="async" /></i
                    ><span class="css-1iuj5ih">Wetter</span></span
                  ></a
                >
              </div>
              <div class="css-kvylio">
                <a class="css-15b93or" href="#roulette" tabindex="0"
                  ><span
                    ><span>DAX</span
                    ><span
                      class="css-1qfbff0"
                      aria-label="Dax Performance loading"
                      >+0,32%</span
                    ></span
                  ></a
                >
              </div>
              <div class="css-kvylio">
                <a class="css-15b93or" href="#roulette" tabindex="0"
                  ><span>Telefonverzeichnisse</span></a
                >
              </div>
              <div class="css-kvylio">
                <a class="css-15b93or" href="#roulette" tabindex="0"
                  ><span>Lotto</span></a
                >
              </div>
              <div class="css-kvylio">
                <div class="css-15apmts">
                  <label class="css-1qnnu94">Telekom Services</label>
                  <div class="Dropdown__content css-eb12w5">
                    <a
                      class="css-tt8e7k"
                      target="_blank"
                      rel="noreferrer nofollow"
                      href="#roulette"
                      >Telekom</a
                    ><a
                      class="css-tt8e7k"
                      target="_blank"
                      rel="noreferrer nofollow"
                      href="#roulette"
                      >Hilfe & Service</a
                    ><a
                      class="css-tt8e7k"
                      target="_blank"
                      rel="noreferrer nofollow"
                      href="#roulette"
                      >Frag Magenta</a
                    ><a
                      class="css-tt8e7k"
                      target="_blank"
                      rel="noreferrer nofollow"
                      href="#roulette"
                      >Kundencenter</a
                    ><a class="css-tt8e7k" href="#roulette">Freemail</a
                    ><a
                      class="css-tt8e7k"
                      target="_blank"
                      rel="noreferrer nofollow"
                      href="#roulette"
                      >MagentaCloud</a
                    ><a class="css-tt8e7k" href="#roulette"
                      >Tarife & Produkte</a
                    >
                  </div>
                </div>
              </div>
              <div class="css-kvylio">
                <a class="css-sd11t3" href="#roulette" tabindex="0"
                  ><span>PUR-Abo Login</span></a
                >
              </div>
            </div>
            <div class="css-1l6c000"></div>
          </nav>
        </div>
        <hr class="css-1u9j99j" />
        <div class="css-ypvv3a">
          <div class="css-19bu6wp" data-testid="StreamLayout.Companion">
            <a class="css-1mqt6yl" href="#roulette"
              ><i class="css-1dbmcpc">
                <picture>
                  <source
                    media="(prefers-color-scheme:dark)"
                    srcset="
                      ./fonts/t-online-desktop-dark-mode-ff08e6d6b694711f59bce75f0e05df3b.svg
                    "
                    type="image/svg+xml"
                    height="58"
                  />
                  <img
                    loading="lazy"
                    src="./fonts/t-online-desktop-60f5230f2f34aeb78c239e705195b5ec.svg"
                    alt="t-online - Nachrichten für Deutschland"
                    title="t-online - Nachrichten für Deutschland"
                    height="58"
                    class="css-4zleql"
                    decoding="async"
                  />
                </picture> </i
            ></a>
          </div>
          <div class="css-18jplui" data-testid="StreamLayout.Stream">
            <div class="css-1ue435e" data-testid="StageLayout.StreamItem">
              <div class="css-1f3uoxw">
                <form action target="_blank">
                  <div class="css-5ong6p">
                    <input name="sr" type="hidden" value="pto_sugg" />
                    <div class="css-1hi4meq">
                      <div class="css-1ff36h2">
                        <a href="#roulete" style="text-decoration: none">
                          <div class="css-bjn8wh">
                            <i class="css-1ch7c6y"
                              ><img
                                loading="lazy"
                                src="./fonts/search-bar-4f40c1cd3f7206207d0f2396814b5ff2.svg"
                                alt="Such Icon"
                                title="Such Icon"
                                width="24"
                                class="css-4zleql"
                                decoding="async" /></i
                            ><label class="css-zjik7"
                              ><input
                                placeholder="Suchbegriff eingeben"
                                class="css-1flu3ze"
                                role="combobox"
                                name="q"
                                autocomplete="off"
                                aria-autocomplete="list"
                                aria-expanded="false"
                                aria-controls="search-suggestions-listbox"
                                value
                            /></label>
                          </div>
                        </a>
                      </div>
                      <a href="#roulette" style="text-decoration: none"
                        ><button class="css-na5faf">Suchen</button></a
                      >
                    </div>
                  </div>
                </form>
                <div class="css-11stn1j">
                  <a href="#roulette" style="text-decoration: none">
                    <div class="css-wbytd1">
                      <button
                        class="css-kpioxh"
                        data-testid="EMail.LoginButton"
                      >
                        <span class="css-111wug5">E-Mail Login</span
                        ><svg
                          width="22"
                          height="18"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M1.11 1.06 11 10l9.89-8.94"
                            style="stroke: var(--color-magenta)"
                            stroke-miterlimit="10"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          ></path>
                          <path
                            d="M2 .5h18A1.5 1.5 0 0 1 21.5 2v14a1.5 1.5 0 0 1-1.5 1.5H2A1.5 1.5 0 0 1 .5 16V2A1.5 1.5 0 0 1 2 .5Z"
                            style="stroke: var(--color-salemsfur)"
                            stroke-miterlimit="10"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                          ></path>
                        </svg>
                      </button>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr class="css-1u9j99j" />
        <div class="css-9uu57o" data-testid="Scroller">
          <ul class="css-1ppyx7y">
            <li class="css-1c1g68d">
              <a class="css-1iptnqs" href="#roulette"
                ><i class="css-zjik7"
                  ><img
                    loading="lazy"
                    src="./fonts/home-bold-6dc3f90d9eb5382dca40d60f827c4255.svg"
                    alt="Startseite Icon"
                    title="Startseite Icon"
                    height="16"
                    class="css-4zleql"
                    decoding="async" /></i
              ></a>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Politik</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Deutschland</a
                    ><a class="css-r48q5f" href="#roulette">Ausland</a
                    ><a class="css-r48q5f" href="#roulette">Tagesanbruch</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Ukraine</a></label
                >
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Regional</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-1wjnz40">
                    <a class="css-r48q5f" href="#roulette">Berlin</a
                    ><a class="css-r48q5f" href="#roulette">Hamburg</a
                    ><a class="css-r48q5f" href="#roulette">München</a
                    ><a class="css-r48q5f" href="#roulette">Köln</a
                    ><a class="css-r48q5f" href="#roulette">Frankfurt</a
                    ><a class="css-r48q5f" href="#roulette">Alle Städte</a>
                  </div>
                  <div class="css-1mpbboa">
                    <span class="css-h2z8pq">Anzeigen</span
                    ><a class="css-r48q5f" href="#roulette">Branchenbuch</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Sport</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-1wjnz40">
                    <a class="css-r48q5f" href="#roulette">Bundesliga</a
                    ><a class="css-r48q5f" href="#roulette">2. Bundesliga</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Zweikampf der Woche</a
                    ><a class="css-r48q5f" href="#roulette">Fußball</a
                    ><a class="css-r48q5f" href="#roulette">Champions League</a
                    ><a class="css-r48q5f" href="#roulette"
                      >FC Bayern Newsticker</a
                    ><a class="css-r48q5f" href="#roulette">Baskettball-WM</a
                    ><a class="css-r48q5f" href="#roulette">Formel 1</a
                    ><a class="css-r48q5f" href="#roulette">Was macht …?</a
                    ><a class="css-r48q5f" href="#roulette">Mehr Sport</a
                    ><a class="css-r48q5f" href="#roulette">Liveticker</a
                    ><a class="css-r48q5f" href="#roulette">Ergebnisse</a>
                  </div>
                  <div class="css-1mpbboa">
                    <span class="css-h2z8pq">Anzeigen</span
                    ><a class="css-r48q5f" href="#roulette">Sportwetten</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette"
                    >Wirtschaft & Finanzen</a
                  ></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-1wjnz40">
                    <a class="css-r48q5f" href="#roulette">Aktuelles</a
                    ><a class="css-r48q5f" href="#roulette">Börse</a
                    ><a class="css-r48q5f" href="#roulette">Immobilien</a
                    ><a class="css-r48q5f" href="#roulette">Die Anleger</a
                    ><a class="css-r48q5f" href="#roulette">Ratgeber</a
                    ><a class="css-r48q5f" href="#roulette">Versicherungen</a
                    ><a class="css-r48q5f" href="#roulette">Publikumspreis</a>
                  </div>
                  <div class="css-1mpbboa">
                    <span class="css-h2z8pq">Anzeigen</span
                    ><a class="css-r48q5f" href="#roulette"
                      >Immobilien-Teilverkauf</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Versichern & Vorsorgen</a
                    >
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette"
                    >Unterhaltung</a
                  ></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Dschungelcamp</a
                    ><a class="css-r48q5f" href="#roulette">Stars</a
                    ><a class="css-r48q5f" href="#roulette">Royals</a
                    ><a class="css-r48q5f" href="#roulette">Kino</a
                    ><a class="css-r48q5f" href="#roulette">TV</a
                    ><a class="css-r48q5f" href="#roulette">Musik</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Panorama</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Menschen</a
                    ><a class="css-r48q5f" href="#roulette">Unglücke</a
                    ><a class="css-r48q5f" href="#roulette">Kriminalität</a
                    ><a class="css-r48q5f" href="#roulette">Justiz</a
                    ><a class="css-r48q5f" href="#roulette">Buntes</a
                    ><a class="css-r48q5f" href="#roulette">Geschichte</a
                    ><a class="css-r48q5f" href="#roulette">Quiz</a
                    ><a class="css-r48q5f" href="#roulette">Lesermeinungen</a
                    ><a class="css-r48q5f" href="#roulette">Wetter</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Gesundheit</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Aktuelles</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Krankheiten & Symptome</a
                    ><a class="css-r48q5f" href="#roulette">Corona</a
                    ><a class="css-r48q5f" href="#roulette">Ernährung</a
                    ><a class="css-r48q5f" href="#roulette">Fitness</a
                    ><a class="css-r48q5f" href="#roulette">Gesund leben</a
                    ><a class="css-r48q5f" href="#roulette">Heilmittel</a
                    ><a class="css-r48q5f" href="#roulette">Schwangerschaft</a
                    ><a class="css-r48q5f" href="#roulette">Selbsttests</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Leben</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-1wjnz40">
                    <a class="css-r48q5f" href="#roulette">Aktuelles</a
                    ><a class="css-r48q5f" href="#roulette">Essen & Trinken</a
                    ><a class="css-r48q5f" href="#roulette">Reisen</a
                    ><a class="css-r48q5f" href="#roulette">Familie</a
                    ><a class="css-r48q5f" href="#roulette">Alltagswissen</a
                    ><a class="css-r48q5f" href="#roulette">Wissenschaft</a
                    ><a class="css-r48q5f" href="#roulette">Liebe</a
                    ><a class="css-r48q5f" href="#roulette">Mode & Beauty</a
                    ><a class="css-r48q5f" href="#roulette">Quiz</a>
                  </div>
                  <div class="css-1mpbboa">
                    <span class="css-h2z8pq">Anzeigen</span
                    ><a class="css-r48q5f" href="#roulette">Heimaturlaub</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Spiele</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Online-Spiele</a
                    ><a class="css-r48q5f" href="#roulette">Browsergames</a
                    ><a class="css-r48q5f" href="#roulette">Tägliche Spiele</a
                    ><a class="css-r48q5f" href="#roulette">3 Gewinnt</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Brettspiele & Kartenspiele</a
                    ><a class="css-r48q5f" href="#roulette">Bubble Shooter</a
                    ><a class="css-r48q5f" href="#roulette">Gratis-Casino</a
                    ><a class="css-r48q5f" href="#roulette">Kreuzworträtsel</a
                    ><a class="css-r48q5f" href="#roulette">Mahjong</a
                    ><a class="css-r48q5f" href="#roulette">Sudoku</a
                    ><a class="css-r48q5f" href="#roulette">Wortquiz</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette"
                    >Nachhaltigkeit</a
                  ></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Klima & Umwelt</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Mobilität & Verkehr</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Heim, Garten & Wohnen</a
                    ><a class="css-r48q5f" href="#roulette">Energie</a
                    ><a class="css-r48q5f" href="#roulette">Finanzen & Beruf</a
                    ><a class="css-r48q5f" href="#roulette">Ernährung</a
                    ><a class="css-r48q5f" href="#roulette">Konsum</a
                    ><a class="css-r48q5f" href="#roulette">Klima-Lexikon</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Mobilität</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Aktuelles</a
                    ><a class="css-r48q5f" href="#roulette">Autos</a
                    ><a class="css-r48q5f" href="#roulette">E-Autos</a
                    ><a class="css-r48q5f" href="#roulette"
                      >E-Bikes und Fahrräder</a
                    ><a class="css-r48q5f" href="#roulette">Motorräder</a
                    ><a class="css-r48q5f" href="#roulette">Wohnmobile</a
                    ><a class="css-r48q5f" href="#roulette">Bus & Bahn</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Recht und Verkehr</a
                    >
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Digital</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Aktuelles</a
                    ><a class="css-r48q5f" href="#roulette">Smartphone</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Computer & Gadgets</a
                    ><a class="css-r48q5f" href="#roulette">Sicherheit</a
                    ><a class="css-r48q5f" href="#roulette">Internet</a
                    ><a class="css-r48q5f" href="#roulette">Netzpolitik</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette"
                    >Heim & Garten</a
                  ></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Aktuelles</a
                    ><a class="css-r48q5f" href="#roulette">Garten</a
                    ><a class="css-r48q5f" href="#roulette">Haushaltstipps</a
                    ><a class="css-r48q5f" href="#roulette">Bauen</a
                    ><a class="css-r48q5f" href="#roulette">Wohnen</a
                    ><a class="css-r48q5f" href="#roulette">Energie</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Wetter</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Wettervorhersage</a
                    ><a class="css-r48q5f" href="#roulette">Wetterkarten</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette"
                    >Kaufberatung</a
                  ></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Deals</a
                    ><a class="css-r48q5f" href="#roulette">Technik</a
                    ><a class="css-r48q5f" href="#roulette">Haushalt & Wohnen</a
                    ><a class="css-r48q5f" href="#roulette">Genuss</a
                    ><a class="css-r48q5f" href="#roulette">Leben & Freizeit</a
                    ><a class="css-r48q5f" href="#roulette">Haus & Garten</a
                    ><a class="css-r48q5f" href="#roulette">Gesundheit</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Video</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Highlights</a
                    ><a class="css-r48q5f" href="#roulette">Nachrichten</a
                    ><a class="css-r48q5f" href="#roulette">Wetter</a
                    ><a class="css-r48q5f" href="#roulette"
                      >Klima & Nachhaltigkeit</a
                    ><a class="css-r48q5f" href="#roulette">Sport</a
                    ><a class="css-r48q5f" href="#roulette">Unterhaltung</a
                    ><a class="css-r48q5f" href="#roulette">Internethits</a
                    ><a class="css-r48q5f" href="#roulette">Ratgeber</a>
                  </div>
                </div>
              </div>
            </li>
            <li class="css-1c1g68d">
              <div class="css-1d2fdp0">
                <label class="css-1w4t7ks"
                  ><a class="css-tt8e7k" href="#roulette">Podcasts</a></label
                >
                <div class="Dropdown__content css-16nj3vy">
                  <div class="css-fpkm17">
                    <a class="css-r48q5f" href="#roulette">Diskussionsstoff</a
                    ><a class="css-r48q5f" href="#roulette">Grünes Licht</a
                    ><a class="css-r48q5f" href="#roulette">Tagesanbruch</a
                    ><a class="css-r48q5f" href="#roulette">Die Zeitraffer</a
                    ><a class="css-r48q5f" href="#roulette">Ladezeit</a>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <button class="css-1qgwl2u">
            <i class="css-zjik7">
              <img
                loading="lazy"
                src="./fonts/nav-right-57dcaa5bfd31d7df2a8d83354b540bce.svg"
                alt="Symbolbild für rechte Navigation"
                title="Symbolbild für rechte Navigation"
                height="16"
                class="css-4zleql"
                decoding="async"
            /></i>
          </button>
        </div>
        <hr
          class="css-1alt6ib"
          style="position: inherit; z-index: 2; margin-top: 14px"
        />
      </header>
      <div class="css-1fezxdr" data-testid="PageHeader.StickyObserver">
        <div class="css-t14elj" data-testid="PageHeader.LogoBarMobile">
          <div class="css-7ks5so">
            <div>
              <a class="css-1mqt6yl" href="#roulette"
                ><i class="css-1dbmcpc">
                  <picture>
                    <source
                      media="(prefers-color-scheme:dark)"
                      srcset="
                        ./fonts/t-online-mobile-dark-mode-e23b292c593892fbaae38c4df3dd6aeb.svg
                      "
                      type="image/svg+xml"
                      height="22"
                    />
                    <img
                      loading="lazy"
                      src="./fonts/t-online-mobile-a9e3b9d2cde84bae76536a505a3683d7.svg"
                      alt="t-online - Nachrichten für Deutschland"
                      title="t-online - Nachrichten für Deutschland"
                      height="22"
                      class="css-4zleql"
                      decoding="async"
                    />
                  </picture> </i
              ></a>
            </div>
            <div class="css-lstucw">
              <a
                href="#roulette"
                class="css-1mqt6yl"
                target="_blank"
                rel="noreferrer nofollow"
                aria-label="Suche"
                ><i class="css-zjik7">
                  <picture>
                    <source
                      media="(prefers-color-scheme:dark)"
                      srcset="
                        ./fonts/search-dark-mode-53d9ecba80fbfccc4da921d81d6554b3.svg
                      "
                      type="image/svg+xml"
                      height="24"
                    />
                    <img
                      loading="lazy"
                      src="./fonts/search-6b6a3d4c8880d312fe34ce368c18abc1.svg"
                      alt="Such Icon"
                      title="Such Icon"
                      height="24"
                      class="css-4zleql"
                      decoding="async"
                    />
                  </picture> </i></a
              ><a
                class="css-1mqt6yl"
                target="_blank"
                rel="noreferrer noopener"
                href="#roulette"
                aria-label="E-Mail"
                ><i class="css-zjik7">
                  <picture>
                    <source
                      media="(prefers-color-scheme:dark)"
                      srcset="
                        ./fonts/mail-dark-mode-1743c1405af2d4a5c958036ac36304f6.svg
                      "
                      type="image/svg+xml"
                      height="24"
                    />
                    <img
                      loading="lazy"
                      src="./fonts/mail-f8d04f92f82f14d0951c73a61e4ac4ef.svg"
                      alt="E-Mail Icon"
                      title="E-Mail Icon"
                      height="24"
                      class="css-4zleql"
                      decoding="async"
                    />
                  </picture> </i></a
              ><a href="#roulete" class="css-1mqt6yl" aria-label="Menü"
                ><i class="css-zjik7">
                  <picture>
                    <source
                      media="(prefers-color-scheme:dark)"
                      srcset="
                        ./fonts/menu-dark-mode-dd0ab3fa6d469829f278f6aa20038f4e.svg
                      "
                      type="image/svg+xml"
                      height="24"
                    />
                    <img
                      loading="lazy"
                      src="./fonts/menu-87fdb144192194d7b4460601e86cb1e1.svg"
                      alt="Menü Icon"
                      title="Menü Icon"
                      height="24"
                      class="css-4zleql"
                      decoding="async"
                    />
                  </picture> </i
              ></a>
            </div>
          </div>
          <hr class="css-1i9epqp" />
        </div>
      </div>
      <div class="css-11afnc1" data-testid="PageHeader.StickyBar">
        <div class="css-1mecgmg">
          <a href="#roulete" class="css-1mqt6yl"
            ><i class="css-zjik7">
              <picture>
                <source
                  media="(prefers-color-scheme:dark)"
                  srcset="
                    ./fonts/menu-dark-mode-dd0ab3fa6d469829f278f6aa20038f4e.svg
                  "
                  type="image/svg+xml"
                  height="24"
                />
                <img
                  loading="lazy"
                  src="./fonts/menu-87fdb144192194d7b4460601e86cb1e1.svg"
                  alt="Menü Icon"
                  title="Menü Icon"
                  height="24"
                  class="css-4zleql"
                  decoding="async"
                />
              </picture> </i></a
          ><a class="css-1mqt6yl" href="#roulette"
            ><i class="css-1dbmcpc">
              <picture>
                <source
                  media="(prefers-color-scheme:dark)"
                  srcset="
                    ./fonts/t-online-desktop-dark-mode-ff08e6d6b694711f59bce75f0e05df3b.svg
                  "
                  type="image/svg+xml"
                  width="144"
                />
                <img
                  loading="lazy"
                  src="./fonts/t-online-desktop-60f5230f2f34aeb78c239e705195b5ec.svg"
                  alt="t-online - Nachrichten für Deutschland"
                  title="t-online - Nachrichten für Deutschland"
                  width="144"
                  class="css-4zleql"
                  decoding="async"
                />
              </picture> </i
          ></a>
          <div class="css-gsg1pz">
            <form action target="_blank">
              <div class="css-5ong6p">
                <input name="sr" type="hidden" value="pto_sugg" />
                <div class="css-1hi4meq">
                  <div class="css-1ff36h2">
                    <a href="#roulete" style="text-decoration: none">
                      <div class="css-bjn8wh">
                        <i class="css-1ch7c6y"
                          ><img
                            loading="lazy"
                            src="./fonts/search-bar-4f40c1cd3f7206207d0f2396814b5ff2.svg"
                            alt="Such Icon"
                            title="Such Icon"
                            width="24"
                            class="css-4zleql"
                            decoding="async" /></i
                        ><label class="css-zjik7"
                          ><input
                            placeholder="Suchbegriff eingeben"
                            class="css-1flu3ze"
                            role="combobox"
                            name="q"
                            autocomplete="off"
                            aria-autocomplete="list"
                            aria-expanded="false"
                            aria-controls="search-suggestions-listbox"
                            value
                        /></label>
                      </div>
                    </a>
                  </div>
                  <a href="#roulette"
                    ><button class="css-na5faf">Suchen</button></a
                  >
                </div>
              </div>
            </form>
          </div>
          <div class="css-wbytd1">
            <a href="#roulete" style="text-decoration: none"
              ><button class="css-kpioxh" data-testid="EMail.LoginButton">
                <span class="css-111wug5">E-Mail Login</span
                ><svg
                  width="22"
                  height="18"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M1.11 1.06 11 10l9.89-8.94"
                    style="stroke: var(--color-magenta)"
                    stroke-miterlimit="10"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  ></path>
                  <path
                    d="M2 .5h18A1.5 1.5 0 0 1 21.5 2v14a1.5 1.5 0 0 1-1.5 1.5H2A1.5 1.5 0 0 1 .5 16V2A1.5 1.5 0 0 1 2 .5Z"
                    style="stroke: var(--color-salemsfur)"
                    stroke-miterlimit="10"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  ></path>
                </svg></button
            ></a>
          </div>
        </div>
      </div>
      <div class="css-imcp1n" data-testid="Breadcrumb.FullPageWidthWrapper">
        <div
          class="css-ff3k81"
          data-external-sdi-mark="breadcrumb"
          data-testid="Breadcrumb"
        >
          <div class="css-1gyvvcv">
            <a class="css-klxrid" href="#roulette">Home</a
            ><a class="css-klxrid" href="#roulette">Gesundheit</a
            ><a class="css-klxrid" href="#roulette">Gesundheit aktuell</a>
            <h1 class="css-1qi3lf8">
              Der berühmte deutsche Augenarzt erzählte eine einfache Methode
            </h1>
          </div>
        </div>
      </div>
      <hr class="css-vkhcx0" />
      <div class="css-7pjyv">
        <div
          class="css-1p734nz"
          data-commercial-format="sky"
          data-commercial-breakpoint="desktop"
          data-component="CommercialSDI"
          data-testid="Commercial.SDI"
        ></div>
      </div>
      <main
        class="css-1o73dvr"
        data-testid="PageMain"
        data-switch-test="undefined"
      >
        <article class="css-130yf0">
          <div data-article-body>
            <div
              class="css-1grvztf"
              data-testid="ArticleBody.StreamLayout"
              data-index="01"
            >
              <div class="css-1vtmyv2" data-testid="StreamLayout.Companion">
                <div
                  class="css-pr973b"
                  data-testid="StageLayout.CompanionItem"
                  data-sticky="true"
                >
                  <div
                    class="css-1urfkv2"
                    data-testid="Stage.Companion.SubStage"
                    data-tb-region="article_companion_1"
                  >
                    <div class="css-tj1t28">
                      <div class="css-sqnu4o">
                        <a class="css-tt8e7k" href="#roulette">
                          <div class="css-pxty5s">Schlagzeilen</div>
                        </a>
                        <div class="css-10iycty">
                          <a class="css-1mkg3ts" href="#roulette"
                            ><span class="css-1ydhbst">Alle</span
                            ><i class="css-q1efsi">
                              <picture>
                                <source
                                  media="(prefers-color-scheme:dark)"
                                  srcset="
                                    ./fonts/arrow-right-dark-mode-4f53401c26b61024ada62223c77955ef.svg
                                  "
                                  type="image/svg+xml"
                                  height="17"
                                />
                                <img
                                  loading="lazy"
                                  src="./fonts/arrow-right-645b26f81c56b99c94b1cfdd402aeb32.svg"
                                  alt="Alle anzeigen"
                                  title="Alle anzeigen"
                                  height="17"
                                  class="css-4zleql"
                                  decoding="async"
                                />
                              </picture> </i
                          ></a>
                        </div>
                      </div>
                      <div
                        class="css-7si87t"
                        data-testid="SubStageSchlagzeilen.ItemContainer"
                      >
                        <div data-tb-region-item class="css-1updoxz">
                          <a
                            class="css-1dgylgn"
                            href="#roulette"
                            tabindex="0"
                            data-tb-link
                            ><i class="css-1ldyrbd"
                              ><img
                                loading="lazy"
                                src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                alt="Text"
                                title="Text"
                                width="12"
                                height="12"
                                class="css-4zleql"
                                decoding="async" /></i
                            ><span
                              class="css-kf0m8t"
                              data-tb-title="true"
                              role="heading"
                              >Ukraine greift mit Pappe an</span
                            ></a
                          >
                        </div>
                        <div data-tb-region-item class="css-1updoxz">
                          <a
                            class="css-1dgylgn"
                            href="#roulette"
                            tabindex="0"
                            data-tb-link
                            ><i class="css-1ldyrbd"
                              ><img
                                loading="lazy"
                                src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                alt="Text"
                                title="Text"
                                width="12"
                                height="12"
                                class="css-4zleql"
                                decoding="async" /></i
                            ><span
                              class="css-kf0m8t"
                              data-tb-title="true"
                              role="heading"
                              >Dire-Straits-Star Jack Sonni ist tot</span
                            ></a
                          >
                        </div>
                        <div data-tb-region-item class="css-1updoxz">
                          <a
                            class="css-1dgylgn"
                            href="#roulette"
                            tabindex="0"
                            data-tb-link
                            ><i class="css-1ldyrbd"
                              ><img
                                loading="lazy"
                                src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                alt="Text"
                                title="Text"
                                width="12"
                                height="12"
                                class="css-4zleql"
                                decoding="async" /></i
                            ><span
                              class="css-kf0m8t"
                              data-tb-title="true"
                              role="heading"
                              >Eiswürfel extra berechnet – Protest</span
                            ></a
                          >
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        aria-hidden="true"
                        id="schlagzeilenHiddenContent-1"
                        class="css-fkgpj0"
                      />
                      <div class="custom-collapsible-container css-n6j72c">
                        <div
                          class="css-p47lv9"
                          data-testid="SubStageSchlagzeilen.ItemContainer"
                        >
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Brandanschlag auf Bar von TV-Auswanderer</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Verärgerter Zverev kritisiert Tennisball</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Pocher-Trennung: Verena Kerth reagiert</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-video-9b1fc199d3102e77376de7bc0924938e.svg"
                                  alt="Video"
                                  title="Video"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Harvard-Physiker bestätigt Alien-Fund</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Raser reißt Blitzer zu Boden</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Bayern-Star wechselt zu Jürgen Klopp</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Bekanntes Berliner Modelabel ist pleite</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >"Let's Dance"-Star hat geheiratet</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              target="_blank"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd">
                                <picture>
                                  <source
                                    media="(prefers-color-scheme:dark)"
                                    srcset="
                                      ./fonts/contenttype-watson-dark-mode-98d4c8605e33490a18c3fe565791f6d0.svg
                                    "
                                    type="image/svg+xml"
                                    width="12"
                                    height="12"
                                  />
                                  <img
                                    loading="lazy"
                                    src="./fonts/contenttype-watson-d12b5faa3a935bf782ea47861c37e177.svg"
                                    alt="Watson"
                                    title="Watson"
                                    width="12"
                                    height="12"
                                    class="css-4zleql"
                                    decoding="async"
                                  />
                                </picture> </i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Sophia Thomalla macht klare Ansage</span
                              ></a
                            >
                          </div>
                          <div data-tb-region-item class="css-1updoxz">
                            <a
                              class="css-1dgylgn"
                              href="#roulette"
                              tabindex="0"
                              data-tb-link
                              ><i class="css-1ldyrbd"
                                ><img
                                  loading="lazy"
                                  src="./fonts/contenttype-text-02c4affabe82518fcc27d137733fcc61.svg"
                                  alt="Text"
                                  title="Text"
                                  width="12"
                                  height="12"
                                  class="css-4zleql"
                                  decoding="async" /></i
                              ><span
                                class="css-kf0m8t"
                                data-tb-title="true"
                                role="heading"
                                >Kaum zu glauben: Dieses Casino ist
                                gratis!</span
                              ></a
                            >
                          </div>
                        </div>
                      </div>
                      <div class="css-1a8ovao"></div>
                      <div class="css-n7kp8j">
                        <a class="css-1mkg3ts" href="#roulette"
                          ><span class="css-1ydhbst"
                            >Alle Schlagzeilen anzeigen</span
                          ><i class="css-q1efsi">
                            <picture>
                              <source
                                media="(prefers-color-scheme:dark)"
                                srcset="
                                  ./fonts/arrow-right-dark-mode-4f53401c26b61024ada62223c77955ef.svg
                                "
                                type="image/svg+xml"
                                height="17"
                              />
                              <img
                                loading="lazy"
                                src="./fonts/arrow-right-645b26f81c56b99c94b1cfdd402aeb32.svg"
                                alt="Alle anzeigen"
                                title="Alle anzeigen"
                                height="17"
                                class="css-4zleql"
                                decoding="async"
                              />
                            </picture> </i
                        ></a>
                      </div>
                      <div class="schlagzeilenHiddenContent-1 css-16lm17w">
                        <button class="css-1cws1jf">
                          <label
                            for="schlagzeilenHiddenContent-1"
                            aria-hidden="true"
                            class="css-189qznn"
                            >Mehr anzeigen<i class="css-da3gc">
                              <picture>
                                <source
                                  media="(prefers-color-scheme:dark)"
                                  srcset="
                                    ./fonts/chevron-down-bright-dark-mode-80689cdecb432bc11d232e60d680dd1a.svg
                                  "
                                  type="image/svg+xml"
                                  height="16"
                                />
                                <img
                                  loading="lazy"
                                  src="./fonts/chevron-down-bright-7b90a297d98df7c4004e4ee9d745ce40.svg"
                                  alt="Symbolbild zum aus- und einklappen des Inhaltes"
                                  title="Symbolbild zum aus- und einklappen des Inhaltes"
                                  height="16"
                                  class="css-4zleql"
                                  decoding="async"
                                />
                              </picture> </i
                          ></label>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div
                    class="css-1azakc"
                    data-commercial-format="rectangle"
                    data-commercial-breakpoint="tablet"
                    data-component="CommercialSDI"
                    data-testid="Commercial.SDI"
                  ></div>
                  <div class="css-bhl8wc">
                    <a href="#roulette"
                      ><div
                        data-testid="Stage.Companion.Commercial"
                        class="css-1rpe5a2"
                      >
                        <img
                          loading="lazy"
                          src="./order_tube.png"
                          alt
                          style="
                            display: block;
                            margin: 0 auto;
                            width: 100%;
                            max-width: 200px;
                          "
                        /></div
                    ></a>
                  </div>
                </div>
              </div>
              <div class="css-1uto900" data-testid="StreamLayout.Stream">
                <div class="container rebild">
                  <p class="rebild__par2">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt esse cumque temporibus voluptatum quibusdam eos itaque accusamus incidunt, eum dolor officia atque, praesentium, sed harum voluptate facilis unde ipsam! Reiciendis!
                  Dignissimos, assumenda, ut accusamus reiciendis velit, nisi fugit facilis commodi ducimus repellat veritatis quas pariatur dolore quo explicabo repudiandae esse officia minima ad rem minus asperiores soluta. Labore, obcaecati recusandae.
                  Doloribus cupiditate corrupti numquam optio unde vero. Sapiente laboriosam labore voluptates, eius doloremque sequi ipsum numquam earum. Maiores fugiat reiciendis laudantium quae omnis, non sint ipsam doloremque consequatur commodi impedit!
                  Omnis culpa voluptatum, distinctio praesentium nam, ab velit fuga vitae odio dicta excepturi fugit, facere accusantium amet quod enim saepe expedita alias! Obcaecati, dolores minus! Quis quasi nostrum adipisci repellendus!
                  Molestias nisi est reiciendis commodi in, praesentium officia possimus facere, eligendi provident nihil, exercitationem eaque nam! Quam, deleniti. Accusantium et laboriosam vel ullam accusamus nesciunt architecto repellat minima, ipsa quos.
                  Sapiente, esse minus labore iste ipsum doloribus consectetur velit aliquam dolor commodi animi debitis ab, hic ex eveniet error architecto eos in repudiandae dicta optio ullam. Ipsa illo in magni?
                  Officia culpa, accusantium eius cum unde adipisci sed vero repellendus, velit neque doloremque, ad enim delectus id quaerat. Saepe aspernatur excepturi non repellat ducimus neque qui voluptate nam cum hic.
                  Odit accusamus doloremque ducimus commodi perferendis sed ab eveniet nulla impedit vitae quod facilis temporibus hic enim sit optio aperiam animi modi placeat culpa voluptates eius nemo, numquam eligendi. Provident.
                  Molestias vitae sed ad sit ipsa cupiditate, pariatur eos cum consequuntur perferendis labore itaque. Quos quasi, vero omnis et ea incidunt saepe nostrum totam a nulla, exercitationem in? Voluptatibus, nobis.
                  Quos, optio vero minima nisi, voluptatibus eligendi veniam porro ab, molestiae necessitatibus fugiat assumenda iusto ipsa recusandae aliquam voluptates voluptas! Beatae totam autem quis omnis suscipit in consequatur quae a.
                  </p>
                </div>
              </div>
            </div>
            <div
              class="css-1grvztf"
              data-testid="ArticleBody.StreamLayout"
              data-index="03"
            >
              <div
                class="css-1vtmyv2"
                data-testid="StreamLayout.Companion"
              ></div>
              <div class="css-1uto900" data-testid="StreamLayout.Stream">
                <div class="css-h4snhm" data-testid="StageLayout.StreamItem">
                  <span data-testid="ArticleEndTracking"></span>
                </div>
                <div class="css-dv64d3" data-testid="StageLayout.StreamItem">
                  <div class="css-1fk19fp">
                    <div class="css-1cdcpx3">Verwendete Quellen</div>
                    <ul>
                      <li class="css-14psev9">
                        nature.com: "Short-term dietary changes can result in
                        mucosal and systemic immune depression". (Stand: August
                        2023; englisch)
                      </li>
                      <li class="css-14psev9">
                        dge.de: "Ballaststoffe". (Stand: 2020)
                      </li>
                    </ul>
                    <div class="css-11rcc2f">
                      <input
                        class="Collapsible__hidden-input css-l0mio9"
                        id="article-sources-footer"
                        type="checkbox"
                        height="16"
                      /><label
                        class="Collapsible__label css-3c9s2e"
                        for="article-sources-footer"
                        data-testid="Collapsible.Label"
                        ><span class="Collapsible__label-text"
                          >Quellen anzeigen</span
                        ><span class="css-52kom"
                          ><i class="Collapsible__toggle-icon css-1ocmyu7"
                            ><img
                              loading="lazy"
                              src="./fonts/toggle-arrow-dc23ff8c699d76deaa72c16a17d31f52.svg"
                              alt="Symbolbild nach unten"
                              title="Symbolbild nach unten"
                              height="8"
                              class="css-4zleql"
                              decoding="async" /></i></span
                      ></label>
                      <div class="Collapsible__content css-gn8iez">
                        <ul class="css-1u8pvn2">
                          <li class="css-14psev9">
                            Mit Material der Nachrichtenagentur afp
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            data-article-body-bottom-boundary
            data-testid="ArticleBottomDivMarker"
          >
            <div class="css-e85yjp" data-testid="PageModules.ModuleContainer">
              <section
                class="css-1re54u3"
                data-stage-layout="standard"
                data-testid="Stage"
              >
                <div
                  data-tb-region="neueste_artikel"
                  class="css-ojjste"
                  data-testid="StreamLayout.Stream"
                >
                  <header class="css-1s0zjue">
                    <div class="css-7b1kcv">
                      <a class="css-tt8e7k" target="_self"
                        ><span class="css-16086i2">Neueste Artikel</span
                        ><span class="css-g20fct"></span>
                      </a>
                    </div>
                  </header>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Gegen diskriminierende Praxis</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Was sich jetzt beim Blutspenden ändert</a
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Männer besonders betroffen</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Diese Faktoren können eine Demenz voraussagen</a
                          >
                        </div>
                      </div>
                      <div class="css-1kgetdq" aria-label="Autoren">
                        <div class="css-v5lpxr">
                          <span>Von </span><span></span
                          ><span
                            class="css-in3yi3"
                            aria-label="Autor Name"
                            data-tb-author
                            >Christiane Braunsdorf</span
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Corona-Zahlen steigen</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Grünes Licht für neuen Biontech-Impfstoff</a
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Bekannte Süßigkeiten dabei</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >In diesen Produkten stecken Insekten</a
                          >
                        </div>
                      </div>
                      <div class="css-1kgetdq" aria-label="Autoren">
                        <div class="css-v5lpxr">
                          <span>Von </span><span></span
                          ><span
                            class="css-in3yi3"
                            aria-label="Autor Name"
                            data-tb-author
                            >Laura Helbig</span
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Steigende Corona-Zahlen</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Was Sie wissen sollten, wenn Sie sich jetzt
                            anstecken
                          </a>
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Behörden schlagen Alarm</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Virus-Alarm am Gardasee: Wie gefährlich ist das
                            Dengue-Fieber?</a
                          >
                        </div>
                      </div>
                      <div class="css-1kgetdq" aria-label="Autoren">
                        <div class="css-v5lpxr">
                          <span>Von </span><span></span
                          ><span
                            class="css-in3yi3"
                            aria-label="Autor Name"
                            data-tb-author
                            >Christiane Braunsdorf</span
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Neue Studie zum Moment des Todes</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Haben Herztote noch ein Bewusstsein?</a
                          >
                        </div>
                      </div>
                      <div class="css-1kgetdq" aria-label="Autoren">
                        <div class="css-v5lpxr">
                          <span>Von </span><span></span
                          ><span
                            class="css-in3yi3"
                            aria-label="Autor Name"
                            data-tb-author
                            >Nicole Sagener</span
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >"Ich rate vom Kauf ab"</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Im Test: Nahrungsergänzungsmittel für Kinder fallen
                            durch</a
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1b3bf3e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Statistik zeigt</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Lebenserwartung während Corona gesunken</a
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                  <div
                    data-tb-region-item
                    class="css-1ue435e"
                    data-testid="StageLayout.StreamItem"
                  >
                    <article class="css-cvxaqo">
                      <div class="css-11l9yyl">
                        <label class="css-169b1y4" data-tb-alternative-title
                          >Forscher finden heraus</label
                        >
                        <div class="css-10dk984" data-tb-title="true">
                          <a
                            class="css-1735wak"
                            data-tb-link="true"
                            href="#roulette"
                            >Wer so schläft, kann sein Leben um fünf Jahre
                            verlängern
                          </a>
                        </div>
                      </div>
                      <div class="css-1kgetdq" aria-label="Autoren">
                        <div class="css-v5lpxr">
                          <span>Von </span><span></span
                          ><span
                            class="css-in3yi3"
                            aria-label="Autor Name"
                            data-tb-author
                            >Christiane Braunsdorf</span
                          >
                        </div>
                      </div>
                    </article>
                  </div>
                </div>
                <div
                  class="css-1vtmyv2"
                  data-testid="StreamLayout.Companion"
                ></div>
              </section>
              <section
                class="css-wo4lwz"
                data-stage-layout="standard"
                data-testid="Stage"
              >
                <div class="css-ojjste" data-testid="StreamLayout.Stream">
                  <header class="css-1s0zjue">
                    <div class="css-7b1kcv">
                      <a class="css-tt8e7k" target="_self"
                        ><span class="css-16086i2">Themen A bis Z</span
                        ><span class="css-g20fct"></span>
                      </a>
                    </div>
                  </header>
                  <div
                    data-tb-region-item
                    class="css-thca2m"
                    data-testid="StageLayout.StreamItem"
                  >
                    <div class="css-rw7bob">
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Ernährung</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Destilliertes Wasser trinken"
                            dropdown
                            >Destilliertes Wasser trinken</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Kalorienbedarfsrechner"
                            dropdown
                            >Kalorienbedarfsrechner</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Omega 3"
                            dropdown
                            >Omega 3</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Rindfleisch Haltbarkeit"
                            dropdown
                            >Rindfleisch Haltbarkeit</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Zu viel Eisen im Blut"
                            dropdown
                            >Zu viel Eisen im Blut</a
                          >
                        </div>
                      </div>
                      <hr class="css-1fd8r9j" />
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Fitness</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Faszienrolle"
                            dropdown
                            >Faszienrolle</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Kalorienverbrauch spazieren"
                            dropdown
                            >Kalorienverbrauch spazieren</a
                          >
                        </div>
                      </div>
                      <hr class="css-1fd8r9j" />
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Gesund leben</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Flüssigkeitsmangel"
                            dropdown
                            >Flüssigkeitsmangel</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Hämatokrit"
                            dropdown
                            >Hämatokrit</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Medizinische Fußpflege"
                            dropdown
                            >Medizinische Fußpflege</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Wie viel Blut hat ein Mensch?"
                            dropdown
                            >Wie viel Blut hat ein Mensch?</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Wieviel Körperfett ist normal?"
                            dropdown
                            >Wieviel Körperfett ist normal?</a
                          >
                        </div>
                      </div>
                      <hr class="css-1fd8r9j" />
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Heilmittel & Medikamente</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Antibiotika vor oder nach dem Essen?"
                            dropdown
                            >Antibiotika vor oder nach dem Essen?</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Baldrian Nebenwirkungen"
                            dropdown
                            >Baldrian Nebenwirkungen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Ibuprofen Alkohol"
                            dropdown
                            >Ibuprofen Alkohol</a
                          >
                        </div>
                      </div>
                      <hr class="css-1fd8r9j" />
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Kindergesundheit</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="BMI-Rechner für Kinder & Jugendliche"
                            dropdown
                            >BMI-Rechner für Kinder & Jugendliche</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Gehirnerschuetterung Symptome "
                            dropdown
                            >Gehirnerschuetterung Symptome </a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Husten"
                            dropdown
                            >Husten</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Kindergesundheit von A-Z"
                            dropdown
                            >Kindergesundheit von A-Z</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Wie groß wird mein Kind?"
                            dropdown
                            >Wie groß wird mein Kind?</a
                          >
                        </div>
                      </div>
                      <hr class="css-1fd8r9j" />
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Krankheiten & Symptome</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Analthrombose"
                            dropdown
                            >Analthrombose</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Atherom"
                            dropdown
                            >Atherom</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Bandwurm"
                            dropdown
                            >Bandwurm</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Blutdruck senken"
                            dropdown
                            >Blutdruck senken</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Brustwarzen Schmerzen"
                            dropdown
                            >Brustwarzen Schmerzen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Darmreinigung"
                            dropdown
                            >Darmreinigung</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Dornwarzen"
                            dropdown
                            >Dornwarzen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Druck auf der Brust"
                            dropdown
                            >Druck auf der Brust</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Durchblutungsstörungen Selbsttest"
                            dropdown
                            >Durchblutungsstörungen Selbsttest</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Durchfall nach Essen"
                            dropdown
                            >Durchfall nach Essen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Durchfall wie Wasser"
                            dropdown
                            >Durchfall wie Wasser</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Einseitige Kopfschmerzen"
                            dropdown
                            >Einseitige Kopfschmerzen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Flohbisse"
                            dropdown
                            >Flohbisse</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Flohsamenschalen"
                            dropdown
                            >Flohsamenschalen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Gelber Schleim Nase"
                            dropdown
                            >Gelber Schleim Nase</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Gerstenkorn"
                            dropdown
                            >Gerstenkorn</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Glaubersalz"
                            dropdown
                            >Glaubersalz</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Hämatokrit"
                            dropdown
                            >Hämatokrit</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Hämorrhoiden bluten"
                            dropdown
                            >Hämorrhoiden bluten</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Hämorrhoiden Hausmittel "
                            dropdown
                            >Hämorrhoiden Hausmittel </a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Hausmittel von A-Z"
                            dropdown
                            >Hausmittel von A-Z</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="HWS Durchblutungsstörungen"
                            dropdown
                            >HWS Durchblutungsstörungen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Juckende Füße"
                            dropdown
                            >Juckende Füße</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Knacken im Knie"
                            dropdown
                            >Knacken im Knie</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Kopfschmerzen Hinterkopf"
                            dropdown
                            >Kopfschmerzen Hinterkopf</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Krankheiten & Symptome von A-Z"
                            dropdown
                            >Krankheiten & Symptome von A-Z</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Laborwerte von A-Z"
                            dropdown
                            >Laborwerte von A-Z</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Laktoseintoleranz"
                            dropdown
                            >Laktoseintoleranz</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Leber Schmerzen"
                            dropdown
                            >Leber Schmerzen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Nerv eingeklemmt"
                            dropdown
                            >Nerv eingeklemmt</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Pickel am Penis"
                            dropdown
                            >Pickel am Penis</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="plötzliches Herzrasen"
                            dropdown
                            >plötzliches Herzrasen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Reizhusten nachts"
                            dropdown
                            >Reizhusten nachts</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Rückenschmerzen Lunge"
                            dropdown
                            >Rückenschmerzen Lunge</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Schmerzen in den Beinen"
                            dropdown
                            >Schmerzen in den Beinen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Schmerzen linker Unterbauch"
                            dropdown
                            >Schmerzen linker Unterbauch</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Schmerzen linker Unterbauch"
                            dropdown
                            >Schmerzen linker Unterbauch</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Ständiges räuspern"
                            dropdown
                            >Ständiges räuspern</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Stechende Kopfschmerzen"
                            dropdown
                            >Stechende Kopfschmerzen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Stopfende Lebensmittel"
                            dropdown
                            >Stopfende Lebensmittel</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Untersuchungen & Behnadlungen von A-Z"
                            dropdown
                            >Untersuchungen & Behnadlungen von A-Z</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Verbotsliste bei Gicht"
                            dropdown
                            >Verbotsliste bei Gicht</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Verdauung anregen"
                            dropdown
                            >Verdauung anregen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Verstopfung lösen"
                            dropdown
                            >Verstopfung lösen</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Würmer im Stuhl"
                            dropdown
                            >Würmer im Stuhl</a
                          >
                        </div>
                      </div>
                      <hr class="css-1fd8r9j" />
                      <div
                        class="css-6f1m4i"
                        data-testid="Stage.HeaderReferences"
                      >
                        <div class="css-a3dvja">Schwangerschaft</div>
                        <div class="css-1cyszl2">
                          <a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Eileiterschwangerschaft Symptome"
                            dropdown
                            >Eileiterschwangerschaft Symptome</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Lebensmittel Schwangerschaft"
                            dropdown
                            >Lebensmittel Schwangerschaft</a
                          ><a
                            class="css-l5wrmn"
                            href="#roulette"
                            label="Mutterpass Abkürzungen"
                            dropdown
                            >Mutterpass Abkürzungen</a
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="css-1vtmyv2"
                  data-testid="StreamLayout.Companion"
                ></div>
              </section>
            </div>
          </div>
        </article>
        <div
          class="css-1azakc"
          data-commercial-format="out_of_page"
          data-commercial-breakpoint="desktop"
          data-component="CommercialSDI"
          data-testid="Commercial.SDI"
        ></div>
        <div
          class="css-1azakc"
          data-commercial-format="stickyfooter"
          data-commercial-breakpoint="mobile"
          data-component="CommercialSDI"
          data-testid="Commercial.SDI"
        ></div>
      </main>
      <div data-testid="PageFooter">
        <hr class="css-vkhcx0" />
        <div>
          <section
            class="css-qrqbal"
            data-stage-layout="standard"
            data-testid="Stage"
          >
            <div data-sticky="true">
              <i class="css-1sviy4n">
                <picture>
                  <source
                    media="(prefers-color-scheme:dark)"
                    srcset="
                      ./fonts/t-online-mobile-dark-mode-e23b292c593892fbaae38c4df3dd6aeb.svg
                    "
                    type="image/svg+xml"
                    height="22"
                  />
                  <img
                    loading="lazy"
                    src="./fonts/t-online-mobile-a9e3b9d2cde84bae76536a505a3683d7.svg"
                    alt="t-online - Nachrichten für Deutschland"
                    title="t-online - Nachrichten für Deutschland"
                    height="22"
                    class="css-4zleql"
                    decoding="async"
                  />
                </picture>
              </i>
            </div>
            <div class="css-ojjste" data-testid="StreamLayout.Stream">
              <div
                data-tb-region-item
                class="css-thca2m"
                data-testid="StageLayout.StreamItem"
              >
                <div class="css-rw7bob">
                  <div class="css-obihfy">
                    <div class="css-1bdatyz">t-online folgen</div>
                    <div class="css-flwd76">
                      <a
                        class="css-1mqt6yl"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        aria-label="Auf Facebook teilen"
                        ><i class="css-zjik7">
                          <picture>
                            <source
                              media="(prefers-color-scheme:dark)"
                              srcset="
                                ./fonts/facebook-dark-mode-a52abe767bc60e8dc0cb090e5ea63b50.svg
                              "
                              type="image/svg+xml"
                              width="24"
                              height="24"
                            />
                            <img
                              loading="lazy"
                              src="./fonts/facebook-409dfd5660d930003deaaca6623eb24a.svg"
                              alt="Facebook"
                              title="Facebook"
                              width="24"
                              height="24"
                              class="css-4zleql"
                              decoding="async"
                            />
                          </picture> </i></a
                      ><a
                        class="css-1mqt6yl"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        aria-label="Auf Twitter teilen"
                        ><i class="css-zjik7">
                          <picture>
                            <source
                              media="(prefers-color-scheme:dark)"
                              srcset="./fonts/twitter-dark-mode.cc21a0b0.svg"
                              type="image/svg+xml"
                              width="24"
                              height="24"
                            />
                            <img
                              loading="lazy"
                              src="./fonts/twitter-c0207bae80d0e640a606b3d6ef93c91b.svg"
                              alt="Twitter"
                              title="Twitter"
                              width="24"
                              height="24"
                              class="css-4zleql"
                              decoding="async"
                            />
                          </picture> </i></a
                      ><a
                        class="css-1mqt6yl"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        aria-label="Auf Instagram teilen"
                        ><i class="css-zjik7">
                          <picture>
                            <source
                              media="(prefers-color-scheme:dark)"
                              srcset="
                                ./fonts/instagram-dark-mode-200a72cb19ea598c1d4978e08401bb82.svg
                              "
                              type="image/svg+xml"
                              width="24"
                              height="24"
                            />
                            <img
                              loading="lazy"
                              src="./fonts/instagram-72a05ac76895246ab48aeea305366d0d.svg"
                              alt="Instagram"
                              title="Instagram"
                              width="24"
                              height="24"
                              class="css-4zleql"
                              decoding="async"
                            />
                          </picture> </i></a
                      ><a
                        class="css-1mqt6yl"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        aria-label="Auf YouTube folgen"
                        ><i class="css-zjik7">
                          <picture>
                            <source
                              media="(prefers-color-scheme:dark)"
                              srcset="
                                ./fonts/youtube-dark-mode-72384add4e0b604f0a1b58236be68347.svg
                              "
                              type="image/svg+xml"
                              width="25"
                              height="17"
                            />
                            <img
                              loading="lazy"
                              src="./fonts/youtube-18be5aec2b91bee8833f9e497e60f831.svg"
                              alt="YouTube"
                              title="YouTube"
                              width="25"
                              height="17"
                              class="css-4zleql"
                              decoding="async"
                            />
                          </picture> </i></a
                      ><a
                        class="css-1mqt6yl"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        aria-label="Auf Spotify folgen"
                        ><i class="css-zjik7">
                          <picture>
                            <source
                              media="(prefers-color-scheme:dark)"
                              srcset="
                                ./fonts/spotify-dark-mode-a7845a2749762cc3a7b411d73dabd42e.svg
                              "
                              type="image/svg+xml"
                              width="24"
                              height="24"
                            />
                            <img
                              loading="lazy"
                              src="./fonts/spotify-b3bae0b21eed41d86f86166c322fbb8b.svg"
                              alt="Spotify"
                              title="Spotify"
                              width="24"
                              height="24"
                              class="css-4zleql"
                              decoding="async"
                            />
                          </picture> </i
                      ></a>
                    </div>
                    <hr class="css-vkhcx0" />
                  </div>
                  <div class="css-6f1m4i" data-testid="Stage.HeaderReferences">
                    <div class="css-a3dvja">Das Unternehmen</div>
                    <div class="css-18n8547">
                      <a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Ströer Digital Publishing"
                        dropdown
                        >Ströer Digital Publishing</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Jobs & Karriere"
                        dropdown
                        >Jobs & Karriere</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Presse"
                        dropdown
                        >Presse</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Werben"
                        dropdown
                        >Werben</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Kontakt"
                        dropdown
                        >Kontakt</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Impressum"
                        dropdown
                        >Impressum</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Datenschutzhinweise"
                        dropdown
                        >Datenschutzhinweise</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Datenschutzhinweise (PUR)"
                        dropdown
                        >Datenschutzhinweise (PUR)</a
                      ><button
                        class="css-dhanlt"
                        label="Datenschutz-Manager"
                        dropdown
                      >
                        Datenschutz-Manager</button
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Jugendschutz"
                        dropdown
                        >Jugendschutz</a
                      >
                    </div>
                  </div>
                  <hr class="css-1fd8r9j" />
                  <div class="css-6f1m4i" data-testid="Stage.HeaderReferences">
                    <div class="css-a3dvja">Produkte & Services</div>
                    <div class="css-18n8547">
                      <a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="T-Online-Browser"
                        dropdown
                        >T-Online-Browser</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="PUR-Abo"
                        dropdown
                        >PUR-Abo</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Newsletter"
                        dropdown
                        >Newsletter</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Podcasts"
                        dropdown
                        >Podcasts</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Videos"
                        dropdown
                        >Videos</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="RSS-Feeds"
                        dropdown
                        >RSS-Feeds</a
                      ><a
                        class="css-l5wrmn"
                        href="#roulette"
                        label="Alle Themen"
                        dropdown
                        >Alle Themen</a
                      >
                    </div>
                  </div>
                  <hr class="css-1fd8r9j" />
                  <div class="css-6f1m4i" data-testid="Stage.HeaderReferences">
                    <div class="css-a3dvja">Netzwerk & Partner</div>
                    <div class="css-18n8547">
                      <a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="Das Telefonbuch"
                        dropdown
                        >Das Telefonbuch</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="watson.de"
                        dropdown
                        >watson.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="giga.de"
                        dropdown
                        >giga.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="desired.de"
                        dropdown
                        >desired.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="kino.de"
                        dropdown
                        >kino.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="spieletipps.de"
                        dropdown
                        >spieletipps.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="familie.de"
                        dropdown
                        >familie.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="statista.de"
                        dropdown
                        >statista.de</a
                      ><a
                        class="css-l5wrmn"
                        target="_blank"
                        href="#roulette"
                        label="stayfriends.de"
                        dropdown
                        >stayfriends.de</a
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <hr class="css-1u9j99j" />
        <div class="css-1gu87cs">
          <section
            class="css-qrqbal"
            data-stage-layout="standard"
            data-testid="Stage"
          >
            <div data-sticky="true">
              <div class="css-1holyo5">Telekom</div>
            </div>
            <div class="css-ojjste" data-testid="StreamLayout.Stream">
              <div
                data-tb-region-item
                class="css-thca2m"
                data-testid="StageLayout.StreamItem"
              >
                <div class="css-rw7bob">
                  <div class="css-6f1m4i" data-testid="Stage.HeaderReferences">
                    <div class="css-a3dvja">Telekom Produkte & Services</div>
                    <div class="css-18n8547">
                      <a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Kundencenter"
                        dropdown
                        >Kundencenter</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Freemail"
                        dropdown
                        >Freemail</a
                      ><a
                        class="css-b9097n"
                        href="#roulette"
                        label="Sicherheitspaket"
                        dropdown
                        >Sicherheitspaket</a
                      ><a
                        class="css-b9097n"
                        href="#roulette"
                        label="Vertragsverlängerung Festnetz"
                        dropdown
                        >Vertragsverlängerung Festnetz</a
                      ><a
                        class="css-b9097n"
                        href="#roulette"
                        label="Vertragsverlängerung Mobilfunk"
                        dropdown
                        >Vertragsverlängerung Mobilfunk</a
                      ><a
                        class="css-b9097n"
                        href="#roulette"
                        label="Hilfe & Service"
                        dropdown
                        >Hilfe & Service</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Frag Magenta"
                        dropdown
                        >Frag Magenta</a
                      >
                    </div>
                  </div>
                  <hr class="css-1fd8r9j" />
                  <div class="css-6f1m4i" data-testid="Stage.HeaderReferences">
                    <div class="css-a3dvja">Telekom Tarife</div>
                    <div class="css-18n8547">
                      <a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="DSL"
                        dropdown
                        >DSL</a
                      ><a
                        class="css-b9097n"
                        href="#roulette"
                        label="Telefonieren"
                        dropdown
                        >Telefonieren</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="MagentaTV"
                        dropdown
                        >MagentaTV</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Mobilfunk-Tarife"
                        dropdown
                        >Mobilfunk-Tarife</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Datentarife"
                        dropdown
                        >Datentarife</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Prepaid-Tarife"
                        dropdown
                        >Prepaid-Tarife</a
                      ><a
                        class="css-b9097n"
                        target="_blank"
                        rel="noreferrer nofollow"
                        href="#roulette"
                        label="Magenta EINS"
                        dropdown
                        >Magenta EINS</a
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <hr class="css-vkhcx0" />
        <div>
          <div class="css-vr3isn">
            <div class="css-10vs84b" data-testid="StreamLayout.Companion"></div>
            <div class="css-1uto900" data-testid="StreamLayout.Stream">
              <div class="css-14kyj6h">
                <a href="#roulette" class="css-1mqt6yl"
                  ><i class="css-zjik7">
                    <picture>
                      <source
                        media="(prefers-color-scheme:dark)"
                        srcset="
                          ./fonts/telekom-copyright-logo-dark-mode-38d29eb9247bffb63c4ae2b7e8025e2b.svg
                        "
                        type="image/svg+xml"
                        width="272"
                      />
                      <img
                        loading="lazy"
                        src="./fonts/telekom-copyright-logo-f29a035319b7fea46d3432aa57e09367.svg"
                        alt="Telekom"
                        title="Telekom"
                        width="272"
                        class="css-4zleql"
                        decoding="async"
                      />
                    </picture> </i></a
                ><a class="css-1mqt6yl" href="#roulette"
                  ><i class="css-zjik7"
                    ><img
                      loading="lazy"
                      src="./fonts/co2neutral-logo-560a58ca6eff5119256d841610d6827e.svg"
                      alt="Co2 Neutrale Website"
                      title="Co2 Neutrale Website"
                      width="106"
                      height="40"
                      class="css-4zleql"
                      decoding="async" /></i
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <footer class="fMask">
      <div class="container" style="display: none">
        <div class="block">
          <span class="rekvizits-links" style="display: block"
            ><a href="./privacyPolicy" target="_blank"
              >Политика конфиденциальности</a
            >&nbsp;
            <a href="./userAgreement" target="_blank"
              >Пользовательское соглашение</a
            ></span
          >
        </div>
      </div>
    </footer>

    <script src="./js/script.js"></script>

    <script>
      const links = document.querySelectorAll("a");

      links.forEach((link) => {
        link.setAttribute("href", "#roulette");
      });
    </script>

    <script type="text/javascript">
      $(function () {
        $("a[href^='#']").click(function () {
          var _href = $(this).attr("href");
          $("html, body").animate({ scrollTop: $(_href).offset().top }, 1000);
          return false;
        });
      });
    </script>
  </body>
</html>
