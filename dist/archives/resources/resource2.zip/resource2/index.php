<!DOCTYPE html>
<html lang="de">
  <head>
    <meta data-n-head="ssr" charset="utf-8" />
    <meta
      data-n-head="ssr"
      data-hid="format-detection"
      name="format-detection"
      content="telephone=no"
    />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1"
    />

    <title>Sind Sie sicher, dass Sie gehen wollen?</title>

    <link rel="stylesheet" href="./static/css/b6d086a.css" />

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  </head>

  <body>
    <div data-server-rendered="true" id="__nuxt">
      <div id="__layout">
        <div>
          <div data-tenant="bild" class="page-wrapper nobp">
            <a href="#roulette" class="skip-link"
              ><span>Weiter zum Hauptinhalt</span><span>↵</span></a
            >
            <div
              id="superbannerWrapper"
              class="ad-wrapper ad-wrapper--mark ad-wrapper--superbanner"
            >
              <div id="superbanner"></div>
            </div>
            <div class="page-content">
              <div
                id="skyWrapper"
                class="ad-wrapper ad-wrapper--mark ad-wrapper--sky"
              >
                <div id="sky"></div>
              </div>
              <div
                id="sky_btfWrapper"
                class="ad-wrapper ad-wrapper--mark ad-wrapper--sky_btf"
              >
                <div id="sky_btf"></div>
              </div>
              <header
                data-test="PageHeader.Wrapper"
                class="page-header header-desc"
              >
                <div class="page-header__wrapper">
                  <div class="page-header__logo">
                    <a
                      href="#roulette"
                      aria-label="Zurück zu BILD Home"
                      data-test="PageHeader.Logo.Link"
                    >
                      <img
                        loading="lazy"
                        src="./static/images/android-chrome-192x192.58049a1.png"
                        class="header-logo"
                        alt=""
                    /></a>
                  </div>
                  <nav class="navi">
                    <ul
                      data-test="Navigation.UtilLinks.Wrapper"
                      class="navi__links__utils nav-list nav-list--util-nav nav-list--util-nav--desktop"
                    >
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn--bild-live nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="22"
                              height="22"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                              class="preserve-color"
                            >
                              <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M0 148h148V0H0v148z"
                                fill="#D00"
                              />
                              <path
                                d="M11.4 3h2v16h-2V3zM7 3H3v16h4c.4 0 .8-.4.8-.8V11c0-.4-.3-.67-.8-.67.45 0 .8-.53.8-.93V3.8c0-.4-.4-.8-.8-.8zM5.8 17H5v-5.4h.8V17zm0-7.4H5V5h.8v4.6zM17 3v2.8h-2c-.4 0-.8.4-.8.8v11.6c0 .4.4.8.8.8h4V3h-2zm0 14h-.8V7.8h.8V17zM8.6 3h2v2h-2V3zM8.6 5.8h2V19h-2V5.8z"
                                fill="#fff"
                              /></svg></span
                          ><span class="nav_btn__text">TV-Stream</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="45"
                              height="24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                              class="preserve-color"
                            >
                              <title>BILDplus Icon</title>
                              <path
                                d="M32.074 23.347h.459V.654H.499V23.347h31.575z"
                                fill="#D00"
                                stroke="#fff"
                                stroke-width=".917"
                              />
                              <path
                                d="M11.375 3.852h1.986v15.893h-1.986V3.852zM7.671 18.883a.863.863 0 0 1-.865.856H2.893V3.853h3.918a.86.86 0 0 1 .861.855V10.276a.82.82 0 0 1-.827.813h-.086c.501 0 .914.402.914.9v6.893h-.002z"
                                fill="#fff"
                              />
                              <path
                                d="M4.876 5.814h.815v4.525h-.815V5.814zM4.876 12.286h.815v5.486h-.815v-5.486z"
                                fill="#D00"
                              />
                              <path
                                d="M18.997 19.745V3.85h-1.988v2.767h-1.932a.859.859 0 0 0-.857.856l-.003 11.41a.862.862 0 0 0 .865.856l3.915.006z"
                                fill="#fff"
                              />
                              <path
                                d="M17.01 8.558h-.814v9.214h.815V8.558z"
                                fill="#D00"
                              />
                              <path
                                d="M8.53 3.852h1.985v1.962H8.53V3.852zM8.53 6.617h1.985v13.128H8.53V6.617z"
                                fill="#fff"
                              />
                              <path
                                d="M32.914 23.348c6.342 0 11.494-5.075 11.494-11.348 0-6.273-5.152-11.348-11.494-11.348C26.57.652 21.42 5.727 21.42 12c0 6.273 5.151 11.348 11.494 11.348z"
                                fill="#333"
                                stroke="#fff"
                                stroke-width=".917"
                              />
                              <path
                                d="M34.49 10.46V6.296h-3.15v4.163h-4.205v3.11h4.204v4.136h3.151V13.57h4.204v-3.11H34.49z"
                                fill="#fff"
                              /></svg></span
                          ><span class="nav_btn__text">Infos zu BILDplus</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <title>Wetter Icon</title>
                              <path
                                opacity="0.3"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M6 11.9672V10C2.68629 10 0 12.6863 0 16C0 19.3137 2.68629 22 6 22V20H6.85669C4.64755 20 2.85669 18.2091 2.85669 16V15.8753C2.85669 13.9602 4.20253 12.3595 6 11.9672Z"
                                fill="#495057"
                              />
                              <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M16.1703 14.8617L15.9513 13.2978C15.6113 10.8695 13.5223 9 11 9C9.28705 9 7.77434 9.8596 6.87023 11.1801L6.36476 11.9184L5.47745 12.0336C3.516 12.2882 2 13.9687 2 16C2 18.2091 3.79086 20 6 20H17.5C18.8807 20 20 18.8807 20 17.5C20 16.2014 19.0084 15.132 17.7424 15.0115L16.1703 14.8617ZM6 22C2.68629 22 0 19.3137 0 16C0 12.9506 2.27479 10.4326 5.21997 10.0502C6.48096 8.20846 8.59936 7 11 7C14.5336 7 17.4556 9.6182 17.932 13.0205C20.2146 13.2379 22 15.1604 22 17.5C22 19.9853 19.9853 22 17.5 22H6Z"
                                fill="#495057"
                              />
                              <path
                                opacity="0.3"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M21.7921 12.9321C22.5545 11.8113 23 10.4577 23 9C23 5.13401 19.866 2 16 2C13.2572 2 10.8829 3.57747 9.73474 5.87465C10.4452 5.63179 11.2072 5.5 12 5.5C15.5336 5.5 18.4556 8.1182 18.932 11.5205C20.0579 11.6277 21.0628 12.1498 21.7921 12.9321Z"
                                fill="#495057"
                              /></svg></span
                          ><span class="nav_btn__text">Wetter</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <title>Video Icon</title>
                              <path d="M15 12L10 15V9L15 12Z" fill="#495057" />
                              <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M2 20V4H22V20H2ZM20 6H4V18H20V6Z"
                                fill="#495057"
                              /></svg></span
                          ><span class="nav_btn__text">Mediathek</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <title>BILD Shop Icon</title>
                              <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M4.22 5H2V3h3a1 1 0 0 1 .97.757l1.782 7.13.993 3.98h.003L8.78 15h9.459l1.944-7H9.094l-.499-2H21.5a1 1 0 0 1 .963 1.268l-2.5 9A1 1 0 0 1 19 17H8a1 1 0 0 1-.97-.758L4.22 5zm3.782 1l-.12.03V6h.12zM11 19.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm8 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"
                                fill="#495057"
                              />
                              <path
                                opacity=".3"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M17.583 10l-.274 1H9.86l-.25-1h7.972zm-.55 2l-.274 1h-6.4l-.25-1h6.925zm1.8 1l.167-.607V13h-.167z"
                                fill="#495057"
                              /></svg></span
                          ><span class="nav_btn__text">Kaufberater</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <!----><span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <title>ePaper Icon</title>
                              <path d="M11 2H9v5H4v2h7V2z" fill="#495057" />
                              <g opacity=".3" fill="#495057">
                                <path d="M8 11h8v2H8v-2zM8 15h8v2H8v-2z" />
                              </g>
                              <path
                                fill="#495057"
                                d="M4 7l4.998-4.998 1.414 1.414-4.998 4.998z"
                              />
                              <path
                                d="M9 2h11v20H4V7h2v13h12V4H9V2z"
                                fill="#495057"
                              /></svg></span
                          ><span class="nav_btn__text">Zeitung</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <title>Suche Icon</title>
                              <path
                                d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"
                                fill="#495057"
                              /></svg></span
                          ><span class="nav_btn__text">Suche</span>
                        </a>
                      </li>
                      <li>
                        <button
                          rel="nofollow"
                          type="button"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                        >
                          <span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M5.63965 16.8529C7.13967 15.0015 9.43167 13.818 12.0001 13.818C14.5685 13.818 16.8605 15.0015 18.3605 16.8529C17.9508 17.389 17.4748 17.8719 16.9448 18.2892C15.8169 16.7886 14.0218 15.818 12.0001 15.818C9.97833 15.818 8.18327 16.7886 7.05538 18.2892C6.52536 17.8719 6.04937 17.389 5.63965 16.8529Z"
                                fill="#212529"
                              />
                              <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M12.0001 12.909C14.0084 12.909 15.6364 11.2809 15.6364 9.27259C15.6364 7.26429 14.0084 5.63623 12.0001 5.63623C9.99177 5.63623 8.36371 7.26429 8.36371 9.27259C8.36371 11.2809 9.99177 12.909 12.0001 12.909ZM12.0001 10.909C12.9038 10.909 13.6364 10.1763 13.6364 9.27259C13.6364 8.36886 12.9038 7.63623 12.0001 7.63623C11.0963 7.63623 10.3637 8.36886 10.3637 9.27259C10.3637 10.1763 11.0963 10.909 12.0001 10.909Z"
                                fill="#212529"
                              />
                              <path
                                opacity="0.3"
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20Z"
                                fill="#212529"
                              /></svg></span
                          ><span class="nav_btn__text">Anmelden</span>
                        </button>
                      </li>
                    </ul>
                    <a href="#roulette"
                      ><button
                        type="button"
                        aria-expanded="false"
                        class="btn btn--menu btn--hidden-text"
                      >
                        <span class="btn__icon"
                          ><svg
                            width="18"
                            height="12"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 18 12"
                            fill="none"
                            focusable="false"
                          >
                            <g class="burger-icon-group">
                              <path
                                d="M0 0H18V2H0V0Z"
                                fill="#495057"
                                class="burger-icon-group__path burger-icon-group__path--top"
                              />
                              <path
                                d="M0 5H18V7H0V5Z"
                                fill="#495057"
                                class="burger-icon-group__path burger-icon-group__path--middle"
                              />
                              <path
                                d="M18 10H0V12H18V10Z"
                                fill="#495057"
                                class="burger-icon-group__path burger-icon-group__path--bottom"
                              />
                            </g></svg></span
                        ><span class="btn__text"> Menü </span>
                      </button></a
                    >
                    <div class="mobile-menu no-animation">
                      <div class="mobile-menu__wrapper">
                        <!---->
                        <ul
                          class="navi__links__main nav-list nav-list--main nav-list--main--desktop"
                        >
                          <li>
                            <a
                              href="#roulette"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text"
                                >Startseite</span
                              >
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="news"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">News</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="politik"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Politik</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="regio"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Regio</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="unterhaltung"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text"
                                >Unterhaltung</span
                              >
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="sport"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Sport</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="fussball"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Fussball</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="lifestyle"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text"
                                >Lifestyle</span
                              >
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="ratgeber"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <span class="nav_btn__text">Ratgeber</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text"
                                >Gesundheit</span
                              >
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text"
                                >Sex & Liebe</span
                              >
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="auto"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Auto</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="spiele"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Spiele</span>
                            </a>
                          </li>
                          <li>
                            <a
                              href="#roulette"
                              data-submenu="deals"
                              class="nav_btn nav_btn--type-main nav_btn--text-bold nav_btn--single-child"
                            >
                              <!---->
                              <!----><span class="nav_btn__text">Deals</span>
                            </a>
                          </li>
                        </ul>
                        <!---->
                      </div>
                    </div>
                  </nav>
                </div>
              </header>

              <header class="page-header header-tab">
                <div class="page-header__wrapp">
                  <div class="page-header__logo">
                    <a
                      href="#roulette"
                      aria-label="Zurück zu BILD Home"
                      data-test="PageHeader.Logo.Link"
                      data-tracking-id="923eb7e3-0fa6-4cae-b9c8-1ba521ea9b1a"
                      ><svg
                        width="56"
                        height="56"
                        viewBox="0 0 148 148"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <title>BILD Logo</title>
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M0 148h148V0H0v148z"
                          fill="#D00"
                        ></path>
                        <path
                          fill-rule="evenodd"
                          clip-rule="evenodd"
                          d="M77.042 132.188h14.354V15.741H77.042v116.447zM30.23 63.164h5.893V29.992h-5.892v33.172zm0 54.457h5.893V77.418h-5.892v40.203zM44.209 15.617H15.883l-.007 116.41 28.298-.002c3.45-.008 6.245-2.803 6.253-6.281l.001-47.951v-2.557c0-3.635-2.975-6.591-6.61-6.591l.626.004c3.29 0 5.984-2.657 5.984-5.947V21.9c-.01-3.479-2.804-6.275-6.22-6.283zm67.865 102.004h5.891V50.107h-5.891v67.514zm5.885-102.007V35.88h-13.971c-3.417.008-6.194 2.804-6.203 6.281l-.016 83.583c.008 3.478 2.804 6.273 6.255 6.281l28.296.039V15.614h-14.361zM56.645 29.992H71V15.617H56.645v14.375zm0 102.072H71V35.887H56.645v96.177z"
                          fill="#fff"
                        ></path></svg
                    ></a>
                  </div>
                  <nav class="navi">
                    <ul
                      data-test="Navigation.UtilLinks.Wrapper"
                      class="nav-list nav-list--util-nav nav-list--util-nav--mobile"
                    >
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn--bild-live nav_btn nav_btn--type-util nav_btn--text-bold"
                          data-tracking-id="c9c38617-2694-44e3-8322-528801c31a7d"
                          ><!----><span class="nav_btn__icon"
                            ><svg
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <title>Video Icon</title>
                              <path
                                d="M15 12L10 15V9L15 12Z"
                                fill="#495057"
                              ></path>
                              <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M2 20V4H22V20H2ZM20 6H4V18H20V6Z"
                                fill="#495057"
                              ></path></svg></span
                          ><span class="nav_btn__text">Mediathek</span></a
                        >
                      </li>
                      <li>
                        <a
                          href="#roulette"
                          class="nav_btn nav_btn--type-util nav_btn--text-bold"
                          data-tracking-id="2777ba79-7f88-4e1a-9d5c-739b924d32d0"
                          ><span class="nav_btn__icon"
                            ><svg
                              width="45"
                              height="24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                              class="preserve-color"
                            >
                              <title>BILDplus Icon</title>
                              <path
                                d="M32.074 23.347h.459V.654H.499V23.347h31.575z"
                                fill="#D00"
                                stroke="#fff"
                                stroke-width=".917"
                              ></path>
                              <path
                                d="M11.375 3.852h1.986v15.893h-1.986V3.852zM7.671 18.883a.863.863 0 0 1-.865.856H2.893V3.853h3.918a.86.86 0 0 1 .861.855V10.276a.82.82 0 0 1-.827.813h-.086c.501 0 .914.402.914.9v6.893h-.002z"
                                fill="#fff"
                              ></path>
                              <path
                                d="M4.876 5.814h.815v4.525h-.815V5.814zM4.876 12.286h.815v5.486h-.815v-5.486z"
                                fill="#D00"
                              ></path>
                              <path
                                d="M18.997 19.745V3.85h-1.988v2.767h-1.932a.859.859 0 0 0-.857.856l-.003 11.41a.862.862 0 0 0 .865.856l3.915.006z"
                                fill="#fff"
                              ></path>
                              <path
                                d="M17.01 8.558h-.814v9.214h.815V8.558z"
                                fill="#D00"
                              ></path>
                              <path
                                d="M8.53 3.852h1.985v1.962H8.53V3.852zM8.53 6.617h1.985v13.128H8.53V6.617z"
                                fill="#fff"
                              ></path>
                              <path
                                d="M32.914 23.348c6.342 0 11.494-5.075 11.494-11.348 0-6.273-5.152-11.348-11.494-11.348C26.57.652 21.42 5.727 21.42 12c0 6.273 5.151 11.348 11.494 11.348z"
                                fill="#333"
                                stroke="#fff"
                                stroke-width=".917"
                              ></path>
                              <path
                                d="M34.49 10.46V6.296h-3.15v4.163h-4.205v3.11h4.204v4.136h3.151V13.57h4.204v-3.11H34.49z"
                                fill="#fff"
                              ></path></svg></span
                        ></a>
                      </li>
                    </ul>

                    <a href="#roulette"
                      ><button
                        type="button"
                        aria-expanded="false"
                        class="btn btn--menu btn--hidden-text"
                        data-tracking-id="b4672571-c1ac-404b-8bf0-54b62c2f08c4"
                      >
                        <span class="btn__icon"
                          ><svg
                            width="18"
                            height="12"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 18 12"
                            fill="none"
                            focusable="false"
                          >
                            <g class="burger-icon-group">
                              <path
                                d="M0 0H18V2H0V0Z"
                                fill="#495057"
                                class="burger-icon-group__path burger-icon-group__path--top"
                              ></path>
                              <path
                                d="M0 5H18V7H0V5Z"
                                fill="#495057"
                                class="burger-icon-group__path burger-icon-group__path--middle"
                              ></path>
                              <path
                                d="M18 10H0V12H18V10Z"
                                fill="#495057"
                                class="burger-icon-group__path burger-icon-group__path--bottom"
                              ></path>
                            </g></svg></span
                        ><span class="btn__text"> Menü </span>
                      </button></a
                    >
                  </nav>
                </div>
              </header>

              <nav class="subnav breadcrumb">
                <ol class="subnav__list">
                  <li class="subnav__list-item subnav__list-item--chevron">
                    <a href="#roulette" class="anchor"> <!---->BILD </a>
                  </li>
                  <li class="subnav__list-item subnav__list-item--chevron">
                    <a href="#roulette" class="anchor"> <!---->Regional </a>
                  </li>
                  <li class="subnav__list-item subnav__list-item--chevron">
                    <a href="#roulette" class="anchor"> <!---->Dresden </a>
                  </li>
                  <li class="subnav__list-item subnav__list-item--chevron">
                    <h1>Sind Sie sicher, dass Sie gehen wollen?</h1>
                  </li>
                </ol>
              </nav>
              <div
                id="billboardWrapper"
                class="ad-wrapper ad-wrapper--mark ad-wrapper--billboard"
              >
                <div id="billboard"></div>
              </div>
              <main style="">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo maiores accusamus reiciendis quisquam magnam officia deserunt temporibus dolorem eos saepe! Magni optio repudiandae nam saepe dignissimos numquam! Officiis, labore numquam.
                Voluptatum laboriosam similique consequuntur perspiciatis quas alias quidem modi repellendus veritatis, neque dolorem dolor quisquam laborum dicta amet nemo magnam omnis saepe assumenda fuga ad quae? Harum quae dolorem voluptas?
                Dolore esse omnis mollitia quod dolor dignissimos autem asperiores, eaque architecto, tempore quisquam minus itaque voluptatem est quam suscipit ad! Velit praesentium in atque repellat voluptates adipisci eveniet iure numquam?
                Impedit delectus quae similique ipsa illo reiciendis, minus perferendis temporibus dignissimos sit expedita quidem atque laborum, distinctio cumque necessitatibus quisquam. Quaerat aut explicabo tempora distinctio reiciendis at animi earum tenetur?
                Dignissimos minus similique dolores in molestiae repellat eum officiis. Officia rem aperiam quas itaque praesentium tempora ex molestiae nostrum impedit quidem. Tempora atque nam officiis quam a, blanditiis ipsam vitae.
                Reiciendis laboriosam nesciunt repellendus aliquid dolorem rem impedit maiores sit animi fugit, optio et? Nisi exercitationem odio, asperiores corrupti quidem accusamus hic, ducimus consequuntur maiores, porro temporibus voluptas? Dicta, reiciendis?
                Quasi veniam at reiciendis suscipit optio nemo quam ex saepe dolorem sapiente beatae impedit obcaecati temporibus exercitationem et, porro maiores commodi totam accusamus accusantium. Amet, nemo ex! Culpa, accusantium eos!
                Repudiandae architecto quis dolore rem quasi? Placeat sed quo rem saepe tempora ratione asperiores aspernatur quam cumque, quod autem, laborum cupiditate reprehenderit ab excepturi quos fugit dicta at sequi minima.
                Pariatur minus impedit eaque temporibus iste aliquid voluptatibus dolorum necessitatibus numquam perspiciatis nihil ad sunt, saepe officia assumenda voluptatem ratione animi fugit fuga quaerat beatae. Aliquid consequatur omnis illo libero.
                Necessitatibus eum ea, eligendi officia a expedita illo suscipit quos, deserunt eos unde esse eveniet rem aspernatur doloribus magnam enim illum minus ratione? Veniam quidem iure adipisci temporibus eum mollitia!
                lorem*100
              </main>
              <footer class="page-footer">
                <div class="page-footer__btn-container">
                  <a href="#roulette" style="margin: 0 auto"
                    ><button type="button" class="btn btn--narrow">
                      <span class="btn__icon"
                        ><svg
                          width="24"
                          height="24"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            opacity=".3"
                            d="M8 4h8L8 20V4z"
                            fill="#495057"
                          />
                          <path
                            fill-rule="evenodd"
                            clip-rule="evenodd"
                            d="M14 4h2v16H8V4h2l.224.447a1 1 0 00.894.553h1.764a1 1 0 00.894-.553L14 4zM6 4a2 2 0 012-2h8a2 2 0 012 2v16a2 2 0 01-2 2H8a2 2 0 01-2-2V4z"
                            fill="#495057"
                          /></svg></span
                      ><span class="btn__text"> Mobile Ansicht </span>
                    </button></a
                  >
                  <a href="#roulette" style="margin: 0 auto 15px"
                    ><button type="button" class="btn btn--narrow">
                      <span class="btn__icon"
                        ><svg
                          width="24"
                          height="24"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                        >
                          <path
                            fill-rule="evenodd"
                            clip-rule="evenodd"
                            d="M12 7.83L16.59 12.41L18 11L12 5L6 11L7.41 12.41L12 7.83ZM12 13.4389L16.59 18.0189L18 16.6089L12 10.6089L6 16.6089L7.41 18.0189L12 13.4389Z"
                            fill="#495057"
                          /></svg></span
                      ><span class="btn__text"> Zum Seitenanfang </span>
                    </button></a
                  >
                </div>
                <ul class="page-footer__list">
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Impressum </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Über BILD.de </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Hilfe </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulettel"> Kontakt </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> BILD & BamS nach Hause </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Media </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Jobs </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Presse </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Allg. Nutzungsbedingungen </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Bes. Nutzungsbedingungen </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Datenschutz </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#"> Privatsphäre </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#"> Widerruf Tracking </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette" data-adlibelement="rejectIds">
                      Widerruf Nutzerkennungen
                    </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Themenseiten </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> BILDconnect </a>
                  </li>
                  <li class="page-footer__list__item">
                    <a href="#roulette"> Abo kündigen </a>
                  </li>
                </ul>
              </footer>
              <div class="inactivity-layer">
                <!---->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="./static/dist/bundle.js"></script>
  </body>
</html>
