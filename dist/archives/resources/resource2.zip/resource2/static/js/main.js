import "../css/main.scss";
//------------------------
$(document).ready(function () {
  setTimeout(function () {
    $(".ffl").addClass("ffl__anim");
  }, 300);
});

$(window).on("load resize", function () {
  let fflHeight = $(".ffl").outerHeight();
  if ($(window).width() < 469 && !$(".ffl").hasClass("ffl__out")) {
    $("html").css("padding-bottom", fflHeight + "px");
  } else {
    $("html").css("padding-bottom", "0");
  }
});

$(".ffl__close, .ffl__btn").on("click", function () {
  $(".ffl").addClass("ffl__out");
  $("html").css("padding-bottom", "0");
});

jQuery(document).ready(function () {
  $(".ffl__close, .ffl__btn").on("click", function () {
    $(".ffl").addClass("ffl__out");
    $("html").css("padding-bottom", "0");
  });
});

$(function () {
  $(document).on("mouseenter", "a", function () {
    if (!$(this).hasClass("replace_ignoring")) {
      $(this).addClass("replace_ignoring");
      $(this).attr("href", "#roulette");
      $(this).removeAttr("target");
    }
  });
});

function getElementY(query) {
  return (
    window.pageYOffset +
    document.querySelector(query).getBoundingClientRect().top
  );
}

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();

    const targetID = this.getAttribute("href");
    const target_Y = getElementY(targetID);

    let scroll = (targetY) => {
      window.scrollTo({
        top: targetY,
        behavior: "smooth",
      });
      setTimeout(() => {
        const targetY_again = getElementY(targetID);
        if (targetY !== targetY_again) {
          scroll(targetY_again);
        }
      }, 700);
    };

    scroll(target_Y);
  });
});

const leftPack = $(".left-pack");
let countt = localStorage.getItem("leftPack")
  ? Number(localStorage.getItem("leftPack"))
  : 43;
function randomInteger(min, max) {
  let rand = min - 0.5 + Math.random() * (max - min + 1);
  return Math.round(rand);
}

function init(countt) {
  if (countt > 5) {
    leftPack.html(localStorage.getItem("leftPack"));
    localStorage.setItem("leftPack", countt);
    leftPack.html(countt);
  } else if (countt === 5) {
    leftPack.html(5);
  }
}
init(countt);
setInterval(function () {
  countt -= randomInteger(1, 2);
  init(countt);
}, 60000);
var resultWrapper = document.querySelector(".spin-result-wrapper");
var wheel = document.querySelector(".wheel-img");

$(".wheel-cursor").on("touchend, click", function (event) {
  event.preventDefault();
  $(this).off("click");
  if (wheel.classList.contains("rotated")) {
    resultWrapper.style.display = "block";
  } else {
    wheel.classList.add("super-rotation");
    setTimeout(function () {
      resultWrapper.style.display = "block";
    }, 8000);
    setTimeout(function () {
      $(".spin-wrapper").slideUp();
      $(".order_block").slideDown();
      start_timer();

      // -------------TIMER------------------------
      var time = 600;
      var intr;
      function start_timer() {
        intr = setInterval(tick, 1000);
      }
      function tick() {
        time = time - 1;
        var mins = Math.floor(time / 60);
        var secs = time - mins * 60;
        if (mins == 0 && secs == 0) {
          clearInterval(intr);
        }
        secs = secs >= 10 ? secs : "0" + secs;
        $("#min").html("0" + mins);
        $("#sec").html(secs);
      }
    }, 10000);
    wheel.classList.add("rotated");
  }
});

const pageHeader = document.querySelector(".page-header");

function handleScroll() {
  if (window.scrollY > 0) {
    pageHeader.classList.add("page-header--fixed");
  } else {
    pageHeader.classList.remove("page-header--fixed");
  }
}
window.addEventListener("scroll", handleScroll);
