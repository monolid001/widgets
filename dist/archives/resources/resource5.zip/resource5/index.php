<!DOCTYPE html>
<html lang="de">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="theme-color" content="#ffffff">
	<title>Hypertonie&nbsp;- Symptome, Diagnostik, Therapie | Gelbe Liste</title>
	<link rel="stylesheet" href="./static/dist/bundle.css">
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>

<body>
	<nav class="fixed-top">
		<div class="bg-logo-background">
			<div class="container">
				<div class="nav_main">
					<div class="row justify-content-between justify-content-md-start align-items-center"> <a href="#roulette">
                            <img class="logo" src="./static/images/glo-logo.png" title="Gelbe Liste"
                                alt="Gelbe Liste" loading="lazy">
                        </a>
						<div class="col-9 text-center d-none d-md-block">
							<div class="text-center form" action="" method="post">
								<div class="input-group m-auto"> <input class="ws-predictive linked form-control ui-autocomplete-input" type="search" name="term" placeholder="Auf Gelbe Liste suchen" autocomplete="off" /> <span class="input-group-btn">
                                        <input type="submit" class="hide" />
                                        <a href="#roulette"><button class="btn btn-brand search_btn" type="submit">
                                            <i class="fa fa-search fa-lg text-white m-1" aria-hidden="true"
                                                title="Suche"></i>
                                        </button></a>
                                    </span> </div>
								<div class="search"> <a href="#roulette" class="links-white links-underline">Identa-Suche</a> | <a href="#roulette" class="links-white links-underline">Profi-Suche</a> </div>
							</div>
						</div> <a href="#roulette" data-toggle="collapse" data-target="#search-menu" class="d-md-none h-mobile-icon">
                            <i class="fa fa-search fa-2x text-black mb-1" aria-hidden="true" title="Suche"></i>
                            <p>Suche</p>
                        </a> <a href="#roulette" class="d-md-none h-mobile-icon" data-toggle="collapse" data-target="#profil-menu">
                            <i class="fas fa-lock fa-2x text-black mb-1" title="Anmeldung"></i>
                            <p>Login</p>
                        </a> <a href="#roulette" data-toggle="collapse" data-target=".hamburger-menu" class="d-md-none h-mobile-icon">
                            <i class="fas fa-bars fa-2x text-black mb-1" title="Inhaltsverzeichnis"></i>
                            <p>Menu</p>
                        </a> </div>
				</div>
				<div class="nav_sky">
					<div id="profil">
						<div class="d-inline-block text-nowrap"> <a class="btn btn-brand text-white font-weight-normal" href="#roulette">Anmelden</a> <a class="btn btn-brand text-white font-weight-normal ml-2" href="#roulette">Registrieren</a>
							<div><a href="#roulette" class="links-brand links-underline float-right login-link">Sie
                                    sind nicht angemeldet</a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="bg-navi d-none d-md-block navi" id="navi">
			<div class="container">
				<ul id="navbar">
					<li> <a href="#roulette">
                            <span class="menuItemLarge show">Nachrichten</span> <span
                                class="menuItemSmall hide">Nachrichten</span> </a>
						<ul>
							<li> <a href="#roulette">Medizinische Leitlinien</a> </li>
							<li> <a href="#roulette">Medizinische Kongresse</a> </li>
							<li> <a href="#roulette">Neue Medikamente</a> </li>
							<li> <a href="#roulette">Rote&#8209;Hand&#8209;Briefe</a> </li>
							<li> <a href="#roulette">Informationsbriefe</a> </li>
							<li> <a href="#roulette">R&#252;ckrufe</a> </li>
							<li> <a href="#roulette">Lieferengp&#228;sse</a> </li>
							<li> <a href="#roulette">Arzneimittel&#228;nderungen</a> </li>
							<li> <a href="#roulette">EMA/PRAC</a> </li>
						</ul>
					</li>
					<li> <a href="#roulette">
                            <span class="menuItemLarge show">Fachgebiete</span> <span
                                class="menuItemSmall hide">Fachgebiete</span> </a>
						<ul>
							<li> <a href="#roulette">Allgemeinmedizin</a> </li>
							<li> <a href="#roulette">Dermatologie</a> </li>
							<li> <a href="#roulette">Diabetologie</a> </li>
							<li> <a href="#roulette">Gastroenterologie</a> </li>
							<li> <a href="#roulette">Gyn&#228;kologie</a> </li>
							<li> <a href="#roulette">HNO</a> </li>
							<li> <a href="#roulette">Kardiologie</a> </li>
							<li> <a href="#roulette">Neurologie</a> </li>
							<li> <a href="#roulette">Onkologie</a> </li>
							<li> <a href="#roulette">Ophthalmologie</a> </li>
							<li> <a href="#roulette">P&#228;diatrie</a> </li>
							<li> <a href="#roulette">Pneumologie</a> </li>
							<li> <a href="#roulette">Psychiatrie</a> </li>
							<li> <a href="#roulette">Rheumatologie</a> </li>
							<li> <a href="#roulette">Urologie</a> </li>
						</ul>
					</li>
					<li> <a href="#roulette">
                            <span class="menuItemLarge show">Schwerpunkte</span> <span
                                class="menuItemSmall hide">Schwerpunkte</span> </a>
						<ul>
							<li> <a href="#roulette">Apotheke</a> </li>
							<li> <a href="#roulette">Arzneimittelrichtlinien</a> </li>
							<li> <a href="#roulette">Arzneimitteltherapiesicherheit</a> </li>
							<li> <a href="#roulette">Bet&#228;ubungsmittel</a> </li>
							<li> <a href="#roulette">Biosimilars</a> </li>
							<li> <a href="#roulette">Coronavirus</a> </li>
							<li> <a href="#roulette">E-Rezept</a> </li>
							<li> <a href="#roulette">Impfung</a> </li>
							<li> <a href="#roulette">Reisemedizin</a> </li>
							<li> <a href="#roulette">Schmerztherapie</a> </li>
							<li> <a href="#roulette">Selbstmedikation</a> </li>
							<li> <a href="#roulette">Seltene Erkrankungen</a> </li>
							<li> <a href="#roulette">Wissen Kompakt</a> </li>
							<li> <a href="#roulette">Wundversorgung</a> </li>
							<li> <a href="#roulette">Zulassung</a> </li>
						</ul>
					</li>
					<li> <a href="#roulette">
                            <span class="menuItemLarge show">Datenbanken</span> <span
                                class="menuItemSmall hide">Datenbanken</span> </a>
						<ul>
							<li> <a href="#roulette">Pr&#228;parate</a> </li>
							<li> <a href="#roulette">Hersteller</a> </li>
							<li> <a href="#roulette">Wirkstoffe</a> </li>
							<li> <a href="#roulette">Wirkstoffgruppen</a> </li>
							<li> <a href="#roulette">ATC Codes</a> </li>
							<li> <a href="#roulette">ICD-10 Codes</a> </li>
							<li> <a href="#roulette">Krankheiten</a> </li>
							<li>
								<hr /> </li>
							<li> <a href="#roulette">Identa&#8209;Suche</a> </li>
							<li> <a href="#roulette">Profi&#8209;Suche</a> </li>
							<li> <a href="#roulette">Orphan Disease Finder</a> </li>
						</ul>
					</li>
					<li> <a href="#roulette">
                            <span class="menuItemLarge show">Gelbe Liste</span> <span class="menuItemSmall hide">Gelbe
                                Liste</span> </a>
						<ul>
							<li> <a href="#roulette">Gelbe Liste App</a> </li>
							<li> <a href="#roulette">Gelbe Liste Buch</a> </li>
							<li> <a href="#roulette">Gelbe Liste Musterservice</a> </li>
							<li> <a href="#roulette">Gelbe Liste Newsletter</a> </li>
							<li>
								<hr /> </li>
							<li> <a href="#roulette">Gesundheitsmarkt</a> </li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
		<div id="mainAccordion">
			<div class="collapse" id="search-menu">
				<div class="bg-brand d-md-none search-menu"></div>
			</div>
			<div class="collapse" id="profil-menu">
				<div class="bg-brand profil-menu d-md-none"></div>
			</div>
			<div class="bg-brand links-white d-md-none hamburger-menu collapse"></div>
		</div>
	</nav>
	<div class="container mt-3 img-fluid" id="leaderboard_2">
		<div class="main_content">
			<div class="d-sm-none text-center">
				<div id="beacon_a4de09303c" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"> <a href="#roulette">
                        <img loading="lazy" src="./static/images/lg.gif" width="0" height="0" alt="" title=""
                            style="width: 0px; height: 0px;"></a> </div>
			</div>
			<div class="leaderboard_1 d-none d-sm-block">
				<div class="text1"><a href="#roulette">
                        <img loading="lazy" src="./static/images/baner1.jpg" width="870" height="90" alt="" title=""
                            style="border:0'"></a> </div>
			</div>
		</div>
		<div class="sky_content"></div>
	</div>
	<div class="container">
		<div class="content_main">
			<div class="content">
				<ol class="breadcrumb">
					<li class="breadcrumb-item" itemprop="itemListElement"> <a href="#roulette" class="small" itemprop="item">
                            <span itemprop="name">Home</span>
                        </a> </li>
					<li class="breadcrumb-item" itemprop="itemListElement"> <a href="#roulette" class="small" itemprop="item">
                            <span itemprop="name">
                                Krankheiten
                            </span>
                        </a> </li>
				</ol>
				<div>
					<h3 style="color:red;">Eine neue Methode zur Reinigung der&nbsp;Blutgefäße</h3>
					<h1>ECKART VON HIRSCHHAUSEN: "KÜMMERN SIE SICH DRINGEND UM DIE REINIGUNG IHRER BLUTGEFÄßE, BEVOR IHR HERZ STEHEN&nbsp;BLEIBT".</h1>
					<div class="img-fluid"> <img loading="lazy" src="./static/images/doc12.jpg" alt="" class="articleimage lazy-load js-lazy-image--handled fade-in"> </div>
					<div class="article">
						<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas non nulla temporibus, eligendi ab cumque ipsum sint iure quo consequatur et. Expedita fugit aut dolorum dolore at sint natus laudantium. Nemo, maiores temporibus quas dolor delectus animi harum et, sint praesentium veniam eveniet ab! Sequi vel corporis similique delectus iste consectetur iure deleniti, ipsam, ipsum distinctio aliquid nisi aliquam excepturi? Error voluptatem quia ipsum, explicabo omnis sunt nobis dicta? Hic doloribus ipsam dolore amet officia facere eaque cupiditate necessitatibus blanditiis quisquam aliquid, quae veritatis eligendi repudiandae recusandae? Mollitia, perferendis nemo. Reprehenderit deserunt dolores officiis quis! Est asperiores expedita enim perspiciatis doloribus natus. Nam excepturi tenetur, fugit ab odit pariatur obcaecati, necessitatibus dignissimos, sunt velit sapiente recusandae inventore voluptas atque ipsa? Rerum tenetur ab ea nam eaque ratione, id ad qui minus, necessitatibus quis! Saepe fugiat ea tempore delectus quaerat voluptatum natus eligendi similique nesciunt enim. Iusto iure nam consectetur neque. Distinctio dignissimos in dolore labore et natus necessitatibus id modi inventore suscipit quo enim dolorem officia optio dolores commodi tenetur exercitationem rerum ipsum pariatur, voluptates similique delectus ab! Impedit, sint! Debitis error numquam a, similique autem, sit ea reprehenderit, quidem necessitatibus libero veritatis repellat corporis voluptates accusamus? Autem nisi magnam ut eligendi culpa, voluptas vel architecto, aspernatur, eaque praesentium non. Obcaecati sequi illo quia illum earum iure, magni deleniti, consequatur sit maiores dolor odio ipsam dolore. Aspernatur dolorem magnam recusandae blanditiis vel eos amet non error quaerat quos, maiores esse. Facere nam explicabo a nisi laborum vero vel minus nobis suscipit numquam id eius culpa tempore eaque ipsa, cupiditate inventore? Saepe sint eveniet quidem, asperiores autem quo odio laboriosam nam. Enim, vitae facilis in ullam architecto delectus repellat porro voluptate maiores atque, aut nam nulla eum perferendis consectetur quidem quos velit. Fugit, veritatis? Eos alias ullam ab qui quod iste! Architecto voluptate quod necessitatibus perspiciatis eveniet molestiae obcaecati soluta aut mollitia aspernatur dolorem quisquam ad nesciunt ipsa a autem amet laboriosam enim itaque doloribus impedit, tempora incidunt voluptatibus? Temporibus, saepe? Pariatur corrupti ea eveniet, repudiandae accusamus porro voluptatum facere tempora deserunt itaque. Fugit totam saepe est nisi facere adipisci, quis corporis officia quod dolores temporibus soluta fuga magni asperiores aut! Minus voluptate temporibus, cum hic voluptatem quo repudiandae, consequatur qui nesciunt illo tempora dolores ex? Quisquam, ad voluptas. Sit ab blanditiis necessitatibus animi voluptatum facere earum neque porro tempore voluptates! Harum, inventore incidunt dolorem vitae possimus maiores iste dignissimos, accusantium et quos sit? Aspernatur a, optio accusamus sunt aperiam tempore quidem! Enim, sit consectetur magnam excepturi autem officia obcaecati commodi? Alias aliquid obcaecati sit, soluta unde dolorum consectetur iste, eius dolores quaerat atque amet consequatur similique tenetur aut fugiat saepe praesentium suscipit repudiandae debitis? Natus asperiores dolores totam corrupti sequi. Accusamus voluptatem id nemo ullam est illo similique ipsam dolore magnam deleniti, fugiat ex dolorem maxime error, earum explicabo labore ipsa. Provident officia ab aspernatur nam ea, doloremque aperiam inventore! Suscipit, velit facilis illo ipsum dolorum aliquid nesciunt, reprehenderit, eum voluptates totam autem. Reiciendis doloribus nostrum nesciunt temporibus harum aspernatur, corporis, voluptatem fugiat quasi nulla odio consequuntur maxime distinctio! Eligendi! Temporibus praesentium sequi assumenda eveniet cupiditate dolor? Corrupti ipsam voluptatem aut rerum cumque voluptatibus. Pariatur, minus blanditiis voluptates amet, possimus velit officiis beatae quisquam unde nulla, id debitis perspiciatis repudiandae? Labore dolor dolore sed eos ut unde, sapiente hic quibusdam fugit, fugiat exercitationem. Odio vero cupiditate velit. Dolorem nesciunt, magni eum, est quae quia a autem aperiam sed laudantium eveniet! Quisquam, porro! Atque soluta optio fuga tenetur earum dignissimos. Omnis fugiat cupiditate labore at, totam sunt assumenda, ipsa, voluptate velit harum itaque! Labore facere autem impedit, molestiae neque quae voluptas. Aut aliquid non dolorem, quam et accusamus earum ex animi unde tenetur necessitatibus temporibus libero? Accusamus labore iusto eius assumenda distinctio aspernatur expedita odio tempore cum et, similique sequi cupiditate. Natus hic dicta, inventore quia veniam maiores delectus. Voluptate ipsam earum doloribus aut est consectetur nulla tempora quae deserunt possimus. Temporibus, inventore autem. Ad, dolor illum commodi optio hic laudantium? Dignissimos sapiente ducimus voluptatibus vitae suscipit perferendis deserunt voluptatum ex perspiciatis nulla sint voluptate accusamus excepturi eligendi laboriosam mollitia sunt nihil, consequuntur similique consectetur. Consequuntur omnis quaerat unde voluptas! Recusandae. Dolorem doloremque ab dolor enim a laudantium rerum quae, nesciunt, officiis possimus optio eos et, vel quas nam! Facere necessitatibus quidem, reiciendis qui totam sunt sint numquam unde voluptas deserunt! Exercitationem, consequatur temporibus, vel quidem reprehenderit consequuntur, eius eos totam quia debitis assumenda dolore rerum maiores culpa a soluta qui dolor dolores perferendis. Eum, officia sed? Repudiandae, omnis libero. Aut. In iste dolorem eos amet dignissimos commodi, optio laborum itaque officiis unde cum incidunt explicabo cupiditate quibusdam doloribus ratione nam, accusantium possimus eaque soluta veniam pariatur? Amet eveniet veritatis unde. Ut in sit omnis voluptatibus illum harum suscipit, tenetur, ratione vel, recusandae autem dolore et. Unde ipsam at soluta veritatis eligendi nemo odit quo, voluptatibus commodi error aliquam, minus dicta. Sint, natus soluta atque alias adipisci asperiores vitae sed. Quos ullam, expedita, quo exercitationem labore vitae assumenda laboriosam non magnam optio eveniet. Necessitatibus, quas nam? Ut labore odit quaerat nulla! Beatae tempore recusandae quisquam adipisci esse. Explicabo voluptatibus sint unde debitis est minus, dolorem iste dolores adipisci a tempora qui voluptatum dolorum neque sapiente esse ut animi velit quibusdam. Praesentium. Harum placeat, voluptatum porro magni illo possimus omnis nobis odio facere consectetur ad earum ex, et quibusdam quasi nemo similique illum ullam expedita? Quae nemo, repudiandae nam similique tempore nisi? </p>
					</div>
					
				</div>
			</div>
			<div class="right_bar">
				<div class='box row-1'>
					<div class='box-header font-weight-bold'>News zu Hypertonie</div>
					<div class='box-body'>
						<div class='column'><a href="#roulette"><img loading="lazy" class='card-img img-fluid lazy-load'
                                    src='./static/images/getimagewithnamedsize.webp'
                                    alt='Schwangere misst Blutdruck' title='Schwangere misst Blutdruck'>
                                <h3 class='small'><span class="startdate" format="dayF.monthF.year"
                                        daysago="1"></span>&nbsp;- Langzeiteffekte hypertensiver
                                    Schwangerschaftserkrankungen</h3>
                                <p>Erhöht eine In&#8209;Utero&#8209;Exposition gegenüber mütterlichem Bluthochdruck das zukünftige
                                    Hypertonie&#8209;Risiko bei den&nbsp;Nachkommen?</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img loading="lazy" class='card-img img-fluid lazy-load'
                                    src='./static/images/G2.webp' alt='Blutdruckmessung' title='Blutdruckmessung'>
                                <h3 class='small'><span class="startdate" format="dayF.monthF.year"
                                        daysago="3"></span>&nbsp;- Hochdruck&#8209;Risikofaktoren für Frauen </h3>
                                <p>Ältere Frauen leiden häufig unter einer Hypertonie. Die&nbsp;ESH hat in ihrer Leitlinie
                                    nun Risikofaktoren benannt, die bei Frauen zu Hypertonie führen&nbsp;können.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/G3.webp' alt='Telefonieren Handy'
                                    title='Telefonieren Handy'>
                                <h3 class='small'><span class="startdate" format="dayF.monthF.year"
                                        daysago="5"></span>&nbsp;- Häufiges Telefonieren mit dem Handy erhöht Risiko für
                                    Bluthochdruck</h3>
                                <p>Eine neue Studie deutet darauf hin, dass regelmäßige lange Gespräche auf dem
                                    Mobiltelefon das Risiko für Bluthochdruck erhöhen könnten.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/G4.webp' alt='Blutdruckmessung adipöses Kind'
                                    title='Blutdruckmessung adipöses Kind'>
                                <h3 class='small'><i class='fas fa-user-lock text-danger mr-1' alt='Anmeldung'
                                        title='Anmeldung erforderlich'></i><span class="startdate"
                                        format="dayF.monthF.year" daysago="6"></span>&nbsp;- Hypertonie bei Kindern&nbsp;–
                                    ein
                                    unterschätztes Risiko</h3>
                                <p>In einer Pressemitteilung informiert die Deutsche Herzstiftung über Diagnostik und
                                    Prävention der Hypertonie im Kindesalter.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/G5.webp' alt='Statement' title='Statement'>
                                <h3 class='small'><span class="startdate" format="dayF.monthF.year"
                                        daysago="8"></span>&nbsp;- AHA&#8209;Statement: Krebstherapie&#8209;induzierte Hypertonie
                                </h3>
                                <p>Moderne Tumortherapeutika besitzen häufig kardiovaskuläre Toxizität und sind mit
                                    erhöhter kardiovaskulärer Mortalität verbunden. Ein Statement der American Heart
                                    Association geht auf Mechanismen, Diagnose und Management der
                                    Krebstherapie&#8209;induzierten Hypertonie&nbsp;ein.</p>
                            </a></div>
					</div>
				</div>
				<div class='box row-1'>
					<div class='box-header font-weight-bold'>Pharma-News</div>
					<div class='box-body'>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/z4.webp' alt='Rote-Hand-Brief' title='Rote-Hand-Brief'>
                                <h3 class='small'>Rote&#8209;Hand&#8209;Briefe</h3>
                                <p>Aktuelle Rote&#8209;Hand&#8209;Briefe zu Medikamenten.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/z3.webp' alt='Rückrufe' title='Rückrufe'>
                                <h3 class='small'>Rückrufe und Prüfungen</h3>
                                <p>Chargenprüfungen und Rückrufe der Hersteller.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/z2.webp' alt='Lieferengpässe' title='Lieferengpässe'>
                                <h3 class='small'>Lieferengpässe</h3>
                                <p>Aktuelle Lieferengpässe und Wiederverfügbarkeiten.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/z1.webp' alt='Arzneimitteländerungen'
                                    title='Arzneimitteländerungen'>
                                <h3 class='small'>Arzneimitteländerungen</h3>
                                <p>Pharmazeutische Änderungen bei Medikamenten.</p>
                            </a></div><a href='/nachrichten' class='box-link'>Alle Meldungen</a> </div>
				</div>
				<div class='box row-1'>
					<div class='box-header font-weight-bold'>LeitMed Campus: CME für Ärzte</div>
					<div class='box-body'>
						<div class='column'><a href='#roulette' target='_blank'><img
                                    class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/P3.webp' alt='LeitMed Campus Eisenmangel'
                                    title='LeitMed Campus Eisenmangel'>
                                <h3 class='small'>2 CME-Punkte: Reizdarmsyndrom</h3>
                                <p>Leitliniengerechte Therapie und psychische Begleiterkrankungen</p>
                            </a></div>
						<div class='column'><a href='#roulette' target='_blank'><img
                                    class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/P2.webp' alt='LeitMed Campus Reizdarm'
                                    title='LeitMed Campus Reizdarm'>
                                <h3 class='small'>2 CME-Punkte: Haut als Spiegel des Diabetes mellitus</h3>
                                <p>Blickdiagnostik, Labor und Therapie typischer Hauterkrankungen</p>
                            </a></div>
						<div class='column'><a href='#roulette' target='_blank'><img
                                    class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/P1.webp' alt='LeitMed Campus Clusterkopfschmerz'
                                    title='LeitMed Campus Clusterkopfschmerz'>
                                <h3 class='small'>2 CME-Punkte: Angststörungen im Kindesalter</h3>
                                <p>Praxisrelevante Strategien für&nbsp;Ärzte</p>
                            </a></div>
					</div>
				</div>
				<div class='box row-1'>
					<div class='box-header font-weight-bold'>Newsletter</div>
					<div class='box-body'>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/W1.webp' alt='Gastroenterologie Newsletter'
                                    title='Gastroenterologie Newsletter'>
                                <h3 class='small'>Gynäkologie Newsletter</h3>
                                <p>14-tägliche Updates zu News in der Frauenheilkunde.</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/W2.webp' alt='Rheumatologie Newsletter'
                                    title='Rheumatologie Newsletter'>
                                <h3 class='small'>Rheumatologie Newsletter</h3>
                                <p>Monatliche Updates zu News aus der Rheumatologie</p>
                            </a></div>
						<div class='column'><a href='#roulette'><img class='card-img img-fluid lazy-load' loading="lazy"
                                    src='./static/images/W3.webp' alt='Pneumologie Newsletter'
                                    title='Pneumologie Newsletter'>
                                <h3 class='small'>Kardiologie Newsletter</h3>
                                <p>14-tägliche Updates zu News in Kardiologie und&nbsp;ngiologie.</p>
                            </a></div>
					</div>
				</div>
				<div class='box row-1 sidebar__product'>
					<div class='box-body' style="border-top:1px solid #fd0;">
						<div class="column" style=" display: flex; justify-content: center; flex-direction: column; align-items: center;"> <img alt="Orphan Disease Finder" loading="lazy" class="img_ban" src='./static/order_tube2.png' style="max-width:200px; width:100%; margin: 15px auto;" /> <a href="#roulette" style="padding:0;margin:0;width:100%; max-width:340px;"><button
                                    type="submit" class="btn_baner">BESTELLEN</button></a> </div>
					</div>
				</div>
			</div>
		</div>
		<div class="content_sky">
			<div class="sticky-sky">
				<div class="hockeysky"> <a href="#roulette">
                        <img loading="lazy" src="./static/images/baner2.jpg" border="0"
                            alt="">
                    </a> </div>
			</div>
		</div>
	</div>
	<footer class="bg-footer-gray text-white links-white links-underline">
		<div class="container">
			<div class="footer_main">
				<div class="row">
					<div class="col-12 col-sm-6 col-md-6 col-lg-6 pt-4"> <a href="#roulette">
                            <img src="./static/images/app-ios.png" loading="lazy" alt="Gelbe Liste App für iOS"
                                title="Gelbe Liste App für iOS" class="img-fluid img-icon">
                        </a> </div>
					<div class="col-12 col-sm-6 col-md-6 col-lg-6 pt-4"> <a href="#roulette">
                            <img src="./static/images/app-android.png" loading="lazy"
                                alt="Gelbe Liste App für Android" title="Gelbe Liste App für Android"
                                class="img-fluid img-icon">
                        </a> </div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="footer_main">
				<div class="row">
					<div class="col-12 col-sm-6 col-md-6 col-lg-6 mt-1 mb-3">
						<ul>
							<li><a href="#roulette">Wir über uns</a></li>
							<li><a href="#roulette">Redaktion</a></li>
							<li><a href="#roulette">Kontakt </a></li>
							<li><a href="#roulette">Sitemap </a></li>
						</ul>
					</div>
					<div class="col-12 col-sm-6 col-md-6 col-lg-6 mt-1 mb-3">
						<ul>
							<li><a href="#roulette">Impressum</a></li>
							<li><a href="#roulette">Datenschutzerklärung</a></li>
							<li><a href="#roulette">Nutzungsbedingungen</a> </li>
							<li><a href="#roulette">Mediadaten &amp; AGB</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="footer_sky pt-0 mb-2">
				<p> Gelbe Liste Online ist ein Online&#8209;Dienst der Vidal MMI Germany GmbH (Vidal&nbsp;MMI) und bietet News, Infos und Datenbanken für Ärzte, Apotheker und andere medizinische Fachkreise. Die GELBE LISTE PHARMINDEX ist ein führendes Verzeichnis von Wirkstoffen, Medikamenten, Medizinprodukten, Diätetika, Nahrungsergänzungsmitteln, Verbandmitteln und Kosmetika. </p>
			</div>
		</div>
	</footer>
	<script src="./static/dist/bundle.js"></script>
</body>

</html>