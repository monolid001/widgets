<!DOCTYPE html>
<html class="no-js" lang="it">
  <head>
    <meta charset="utf-8" />
    <title>
      Reumatologia, nuove sfide e progetti per coinvolgere anche il "grande
      pubblico" - la Repubblica
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="format-detection" content="telephone=no" />
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" href="css/css.css" />
    <link rel="stylesheet" href="css/css2.css" />
  </head>

  <body id="detail">
    <svg
      style="position: absolute; width: 0; height: 0; overflow: hidden"
      xmlns="http://www.w3.org/2000/svg"
    >
      <symbol id="r-icon-info" viewBox="0 0 24 24">
        <path
          d="M11.016 9v-2.016h1.969v2.016h-1.969zM12 20.016q3.281 0 5.648-2.367t2.367-5.648-2.367-5.648-5.648-2.367-5.648 2.367-2.367 5.648 2.367 5.648 5.648 2.367zM12 2.016q4.125 0 7.055 2.93t2.93 7.055-2.93 7.055-7.055 2.93-7.055-2.93-2.93-7.055 2.93-7.055 7.055-2.93zM11.016 17.016v-6h1.969v6h-1.969z"
        ></path>
      </symbol>
      <symbol id="r-icon-trust" viewBox="0 0 24 24">
        <path
          d="M17.813 3.328h-11.738c-1.522 0-2.763 1.238-2.763 2.763v11.738c0 1.522 1.237 2.763 2.763 2.763h11.738c1.522 0 2.763-1.237 2.763-2.763v-11.738c-0.003-1.525-1.241-2.763-2.763-2.763zM19.538 17.828c0 0.953-0.772 1.725-1.725 1.725h-11.738c-0.953 0-1.725-0.772-1.725-1.725v-11.738c0-0.953 0.772-1.725 1.725-1.725h11.738c0.953 0 1.725 0.772 1.725 1.725v11.738z"
        ></path>
        <path
          d="M13.65 16.619h-3.406c-0.069 0-0.125-0.056-0.125-0.125v-5.794c0-0.084-0.069-0.156-0.156-0.156h-3.025c-0.069 0-0.125-0.056-0.125-0.125v-3c0-0.069 0.056-0.125 0.125-0.125h10.003c0.069 0 0.125 0.056 0.125 0.125v3c0 0.069-0.056 0.125-0.125 0.125h-3.047c-0.069 0-0.125 0.056-0.125 0.125v5.825c0.006 0.069-0.050 0.125-0.119 0.125z"
        ></path>
      </symbol>
      <symbol id="r-icon-time" viewBox="0 0 24 24">
        <path
          d="M12.516 6.984v5.25l4.5 2.672-0.75 1.266-5.25-3.188v-6h1.5zM12 20.016q3.281 0 5.648-2.367t2.367-5.648-2.367-5.648-5.648-2.367-5.648 2.367-2.367 5.648 2.367 5.648 5.648 2.367zM12 2.016q4.125 0 7.055 2.93t2.93 7.055-2.93 7.055-7.055 2.93-7.055-2.93-2.93-7.055 2.93-7.055 7.055-2.93z"
        ></path>
      </symbol>
      <symbol id="r-icon-close" viewBox="0 0 24 24">
        <path
          d="M18.984 6.422l-5.578 5.578 5.578 5.578-1.406 1.406-5.578-5.578-5.578 5.578-1.406-1.406 5.578-5.578-5.578-5.578 1.406-1.406 5.578 5.578 5.578-5.578z"
        ></path>
      </symbol>
      <symbol id="r-icon-down-arrow" viewBox="0 0 24 24">
        <path
          d="M7.406 8.578l4.594 4.594 4.594-4.594 1.406 1.406-6 6-6-6z"
        ></path>
      </symbol>
      <symbol id="r-icon-comment" viewBox="0 0 24 24">
        <path
          d="M18 8.016v-2.016h-12v2.016h12zM18 11.016v-2.016h-12v2.016h12zM18 14.016v-2.016h-12v2.016h12zM21.984 3.984v18l-3.984-3.984h-14.016q-0.797 0-1.383-0.609t-0.586-1.406v-12q0-0.797 0.586-1.383t1.383-0.586h16.031q0.797 0 1.383 0.586t0.586 1.383z"
        ></path>
      </symbol>
    </svg>
    <svg
      style="position: absolute; width: 0; height: 0; overflow: hidden"
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
    >
      <symbol id="repubblica-logo">
        <g fill="#000" fill-rule="evenodd">
          <path
            d="M5.145 20.11V0h-.95L0 2.017v.6l1.06 1.05V20.11c0 .947-.061 1.345-1.042 1.405v1.01h6.168v-1.01c-.98-.06-1.041-.458-1.041-1.405M12.893 19.034c0 .917-.515 1.65-1.302 1.65-.817 0-1.21-.684-1.21-2.157 0-1.724.484-2.482 1.428-3.166l1.084-.752v4.425zm4.116.611v-7.328c0-3.155-1.847-4.738-5.412-4.738-2.79 0-4.667 1.437-4.667 3.405 0 1.07.727 2.12 2.028 2.12 1.18 0 1.786-.763 1.786-1.71 0-1.205-1.065-1.51-1.065-1.908 0-.427.526-.629 1.204-.629 1.435 0 2.01.69 2.01 2.42v2.079l-2.458 1.13C7.7 15.74 6.537 16.937 6.537 19.23c0 2.348 1.574 3.6 3.571 3.6 1.21 0 2.391-.733 3.057-1.894.272 1.192 1.18 1.895 2.452 1.895 1.12 0 2.118-.49 2.602-1.131v-1.014a1.063 1.063 0 0 1-.575.183c-.424 0-.635-.367-.635-1.223zM30.052 10.648h-.272V1.962h.375c2.488 0 3.105 1.326 3.105 4.548 0 3.22-.635 4.138-3.208 4.138m7.609 6.601c-.571-3.822-1.852-5.232-4.612-5.807 3.414-.69 4.957-2.506 4.957-5.104 0-3.532-2.391-5.696-7.221-5.696h-7.294v1.002c1.483.122 1.634.612 1.634 2.048v15.776c0 1.406-.362 1.925-1.634 2.048v1.008h7.923v-1.008c-1.301-.123-1.634-.642-1.634-2.048v-7.536h.454c1.029 0 1.852.403 2.119 1.35.417 1.504.434 4.81 1.029 6.907.567 1.998 1.967 2.488 3.783 2.488 1.392 0 2.39-.428 2.784-.703l-.06-1.008c-1.21.305-1.705-.215-2.228-3.717"
          ></path>
          <path
            d="M44.955 8.832c.737 0 1.295.95 1.295 3.4v.451h-2.87c.059-3.002.73-3.85 1.575-3.85m1.725 11.301c-1.858 0-3.14-1.972-3.29-6.173h6.595v-.459c0-3.783-2.052-5.953-4.824-5.953-3.257 0-5.8 2.995-5.8 7.885 0 4.615 2.422 7.408 5.709 7.408 2.451 0 4.025-1.271 5.018-3.79l-.878-.648c-.702 1.144-1.368 1.73-2.53 1.73M57.073 21.564c-1.011 0-1.453-.825-1.453-2.261v-7.42c0-1.193.635-2.048 1.531-2.048 1.199 0 1.616 1.87 1.616 6.357 0 3.594-.218 5.372-1.694 5.372m1.87-13.985c-1.453 0-2.536.727-3.323 1.901v-1.9h-.95l-4.195 1.723v.6l1.06 1.05v14.138c0 .948-.061 1.345-1.09 1.406v1.009h6.295v-1.009c-1.06-.06-1.12-.458-1.12-1.406v-2.567a5.28 5.28 0 0 0 1.882.337c3.456 0 5.623-3.167 5.623-8.393 0-4.646-1.719-6.889-4.182-6.889M75.286 19.132V7.579h-.938l-4.056.972v.856c.824.336.908 1.021.908 2.2v7.036c0 1.045-.623 1.888-1.55 1.888-.847 0-1.18-.574-1.18-1.57V7.579h-.932l-4.225.972v.856c.908.152 1.077.855 1.077 2.2v6.412c0 3.368 1.447 4.872 3.56 4.872 1.398 0 2.505-.776 3.25-1.999v1.773h.842l4.2-.63v-1.008c-.872-.19-.956-.453-.956-1.895M82.755 21.564c-1.017 0-1.459-.702-1.459-1.894v-7.787c0-1.193.636-2.048 1.532-2.048 1.198 0 1.616 1.87 1.616 6.357 0 3.594-.218 5.372-1.69 5.372m1.84-13.985c-1.428 0-2.511.752-3.298 1.901V0h-.956l-4.183 2.017v.6l1.054 1.05v17.127c1.113 1.156 3.105 2.067 5.72 2.067 3.698 0 5.87-3.167 5.87-8.393 0-4.646-1.718-6.889-4.206-6.889M95.333 21.564c-1.017 0-1.46-.702-1.46-1.894v-7.787c0-1.193.636-2.048 1.532-2.048 1.199 0 1.617 1.87 1.617 6.357 0 3.594-.218 5.372-1.69 5.372m1.84-13.985c-1.427 0-2.511.752-3.298 1.901V0h-.957l-4.182 2.017v.6l1.053 1.05v17.127c1.114 1.156 3.105 2.067 5.72 2.067 3.698 0 5.872-3.167 5.872-8.393 0-4.646-1.72-6.889-4.207-6.889M106.948 20.11V0h-.95l-4.194 2.017v.6l1.058 1.05V20.11c0 .947-.06 1.345-1.04 1.405v1.01h6.167v-1.01c-.98-.06-1.04-.458-1.04-1.405M111.64 5.538a2.254 2.254 0 0 0 2.257-2.25 2.261 2.261 0 0 0-2.258-2.28c-1.253 0-2.288 1.046-2.288 2.28 0 1.235 1.035 2.25 2.288 2.25M113.637 20.11V7.58h-.95l-4.195 1.723v.6l1.06 1.05v9.157c0 .947-.062 1.345-1.042 1.405v1.01h6.168v-1.01c-.98-.06-1.041-.458-1.041-1.405M121.263 11.363c0 .947.545 1.742 1.726 1.742 1.301 0 1.997-1.076 1.997-2.219 0-1.992-1.646-3.307-3.983-3.307-3.39 0-6.186 2.653-6.186 8.13 0 4.278 2.288 7.182 5.617 7.182 2.421 0 3.577-1.65 4.364-3.698l-1.368-.71c-.617 1.468-1.15 2.275-2.246 2.275-1.707 0-2.396-2.262-2.396-7.005 0-3.973.932-4.896 2.306-4.896.672 0 1.156.25 1.156.63 0 .397-.987.647-.987 1.876M131.735 19.034c0 .917-.515 1.65-1.302 1.65-.817 0-1.21-.684-1.21-2.157 0-1.724.484-2.482 1.428-3.166l1.084-.752v4.425zm4.751 1.834c-.423 0-.635-.367-.635-1.223v-7.328c0-3.155-1.846-4.738-5.412-4.738-2.79 0-4.666 1.437-4.666 3.405 0 1.07.726 2.12 2.027 2.12 1.18 0 1.786-.763 1.786-1.71 0-1.205-1.066-1.51-1.066-1.908 0-.427.527-.629 1.205-.629 1.434 0 2.01.69 2.01 2.42v2.079l-2.457 1.13c-2.736 1.254-3.899 2.451-3.899 4.743 0 2.348 1.574 3.6 3.571 3.6 1.211 0 2.391-.733 3.057-1.894.272 1.192 1.18 1.895 2.451 1.895 1.12 0 2.12-.49 2.603-1.131v-1.014a1.064 1.064 0 0 1-.575.183z"
          ></path>
        </g>
      </symbol>
      <symbol id="rplus-logo">
        <path
          d="M3.9 2.7h.2c1.4 0 1.8.8 1.8 2.6 0 1.9-.4 2.4-1.9 2.4h-.2v-5h.1zm1.9 5.5c2-.4 2.9-1.4 2.9-3 0-2.1-1.4-3.3-4.2-3.3H.2v.6c.9.1 1 .4 1 1.2v9.1c0 .8-.2 1.1-1 1.2v.6h4.6V14c-.8-.1-1-.4-1-1.2V8.5h.3c.6 0 1.1.2 1.2.8.2.9.3 2.8.6 4 .3 1.1 1.1 1.4 2.2 1.4.8 0 1.4-.2 1.6-.4v-.6c-.7.2-1-.1-1.3-2.1-.3-2.3-1-3.1-2.6-3.4z"
        ></path>
        <path
          d="M16.2 8.8s0-.1-.3-.1h-1.8s-.4.1-.5 0c-.2 0-.5-.1-.6 0-.1 0-.2.1-.4.1h-.3s-.3.1-.4 0c-.2-.1-.4 0-.4 0s-.1.1-.3 0c-.2 0-.3-.1-.4 0 0 0-.1.1-.3.1h-.7l-.3-.1-.2-.1s0-.1.1-.1h.2s.1-.1.2-.1.3-.1.4-.2c.2-.1.3-.2.4-.3.1-.1 0-.2.1-.2s.1-.3.1-.3 0-.2.2-.2.2-.1.3-.1c.1 0 .2-.1.2-.2s.1-.3.2-.3c.2 0 .3-.2.4-.3.1-.1.1-.2.2-.2.2 0 .6.1.8.1.2-.1.2 0 .4 0s.3-.1.4-.1c.2 0 .4-.2.5-.2s.3-.1.4-.1h.3s.1-.1.3-.1h.2s.1-.1.2-.1h.2s.1-.1.2-.1h.2s.1-.1.2-.1.4 0 .4-.1.1-.2.1-.2l.1-.2s0-.1.1-.1c.1-.1.1-.2.1-.2s0-.1.1-.2l.2-.2s.1-.1.1-.3.2-.3.2-.3.2-.1.1-.3v-.3s.1-.1.1-.2.1-.2.2-.2c.1-.1.1-.2.1-.2l.1-.1c.1-.1 0-.2.1-.2.1-.1.1-.2.1-.2s.2-.1.2-.2v-.1l.2-.2c.1-.1.1-.2.1-.3 0-.1.1-.1.1-.1s.1-.1.1-.2l.1-.1s.3-.2.5-.3c.2-.1.2-.1.4-.1h.1c-.1.1-.1.2 0 .3.1 0 .1.2.1.2s-.1.2 0 .2.1.1.1.1v.4l.2.1.2.1c.1-.1.2 0 .4 0 .1 0 .2.1.2.2 0 .2 0 .2-.1.3-.1.1-.1.2-.1.2s0 .1.1 0 .1.1.1.1V3s0 .2-.1.4c0 .2-.1.3-.2.4s-.1.2-.1.2-.1.1-.1.2 0 .2-.1.2l-.1.1s.1.1 0 .2l-.1.1s0 .1-.1.2-.2.3 0 .4c.2 0 .3.1.4.1 0 0 .2.1.2 0 .1-.1.3 0 .3 0h.2c.1.1.2.1.2 0 .1-.1.2-.1.3-.1.1 0 .8.1 1.4.1.6.1 1.1.1 1.1.1h.2s0 .1.2.1.3 0 .3.1c0 0 .1.1.1 0l.1.1c.1 0 .2.1.3.2.1.1.2.3 0 .2-.1 0-.3 0-.3.1s0 .2-.1.2-.3.1-.3.2c.1.1.1.2 0 .2h-.3s-.1.1-.1.4c.1.2.3.5.3.5s.1.3 0 .3-.2.1-.2.1-.2.1-.2 0c-.1-.1-.3 0-.3 0s-.1.1 0 .1.1 0 0 .1-.2.1-.2.1-.2-.1-.2 0 0 .1-.1.1H24s-.1.1-.2.1h-.4s-.1.1-.2 0-1 0-1.3-.1c-.3 0-1.4-.1-1.6-.1h-.6s-.5-.1-.6 0-.1.2-.1.2-.1.1-.1.2v.2c-.1.1-.1.2-.1.3 0 .1 0 .1-.1.2s0 .3-.1.4-.2.3-.2.4 0 .3-.1.4-.1.4-.1.4-.2 0-.2.2c0 .1 0 .3-.1.3-.1.1-.1.2-.1.2s0 .3-.1.3c-.1.1-.1.2-.1.2s-.1.2-.1.3c0 .1 0 .2-.1.3-.1.1-.2.3-.2.4s-.1.1-.1.2-.1.4-.1.4l-.1.2c0 .1-.1.3-.1.3s-.1.2-.1.3c0 .1 0 .4-.1.4-.1.1-.1.3-.1.3s-.1.3-.3.5c-.2.2-.3.2-.2 0 .1-.2.3-.7.2-1-.1-.2-.2-.3-.2-.4s0-.2-.1-.2-.1-.1-.2-.1c0 0-.1-.1-.1-.3.1-.2.1-.5 0-.5s-.2 0-.2-.1-.1-.2-.1-.2v-.2s0-.1-.1-.3c-.1-.1-.2-.2-.1-.3.1-.1.1-.2.1-.3 0-.1.2-.2.2-.2s0-.2.1-.3c.1-.1.2-.8.2-1.2 0-.4.2-.9.2-.9s.1-.5.1-.6c.2-.1.2-.2.2-.2z"
          fill="#1b74b6"
        ></path>
      </symbol>
      <symbol id="rep-logo" viewBox="0 0 160 94.3">
        <style>
          .st0 {
            fill: #ff5900;
          }
        </style>
        <path
          class="st0"
          d="M143.9 65.3c0 4.2 3.3 7.7 7.5 7.7s7.5-3.5 7.5-7.7-3.3-7.7-7.5-7.7-7.5 3.5-7.5 7.7zM143.9 40.2c0 4.2 3.3 7.7 7.5 7.7s7.5-3.5 7.5-7.7-3.3-7.7-7.5-7.7-7.5 3.5-7.5 7.7z"
        ></path>
        <path
          d="M50.4 58.1C48.4 44.9 43.9 40 34.3 38c11.9-2.4 17.3-8.7 17.3-17.6C51.6 8.2 43.3.7 26.4.7H1v3.5c5.2.4 5.7 2.1 5.7 7.1v54.5c0 4.9-1.3 6.7-5.7 7.1v3.5h27.6v-3.5c-4.5-.4-5.7-2.2-5.7-7.1v-26h1.6c3.6 0 6.5 1.4 7.4 4.7 1.5 5.2 1.5 16.6 3.6 23.9 2 6.9 6.9 8.6 13.2 8.6 4.9 0 8.3-1.5 9.7-2.4l-.2-3.5c-4.3.9-6-.9-7.8-13zM23.9 35.3H23v-30h1.3C32.9 5.3 35 9.9 35 21s-2.2 14.3-11.1 14.3z"
        ></path>
        <path
          d="M81.8 68c-6.5 0-11-6.8-11.5-21.3h23v-1.6c0-13.1-7.2-20.6-16.8-20.6-11.4 0-20.2 10.3-20.2 27.2 0 15.9 8.4 25.6 19.9 25.6 8.5 0 14-4.4 17.5-13.1L90.6 62c-2.4 4-4.7 6-8.8 6zm-6-39c2.6 0 4.5 3.3 4.5 11.7v1.6h-10c.2-10.4 2.6-13.3 5.5-13.3zM124.6 24.7c-5.1 0-8.8 2.5-11.6 6.6v-6.6h-3.3l-14.6 6v2.1l3.7 3.6v48.8c0 3.3-.2 4.6-3.8 4.9v3.5h22V90c-3.7-.2-3.9-1.6-3.9-4.9v-8.9c1.9.7 4.2 1.2 6.6 1.2 12.1 0 19.6-10.9 19.6-29-.1-16-6.1-23.7-14.7-23.7zM118.1 73c-3.5 0-5.1-2.8-5.1-7.8V39.5c0-4.1 2.2-7.1 5.3-7.1 4.2 0 5.6 6.5 5.6 22 .1 12.4-.7 18.6-5.8 18.6z"
        ></path>
      </symbol>
      <symbol id="R-logo">
        <path
          fill="#000"
          fill-rule="nonzero"
          d="M14.772 3.192h.903c5.827 0 7.221 3.03 7.221 10.48 0 7.53-1.477 9.659-7.55 9.659h-.574V3.192zm7.632 21.858c8.043-1.637 11.654-5.812 11.654-11.788C34.058 5.075 28.478 0 17.152 0H0v2.374c3.447.245 3.857 1.391 3.857 4.748v36.511c0 3.274-.82 4.42-3.857 4.748v2.374h18.547v-2.374c-3.036-.245-3.857-1.473-3.857-4.748V26.196h1.067c2.38 0 4.35.9 4.924 3.11.985 3.439 1.067 11.134 2.38 15.964 1.313 4.583 4.596 5.73 8.863 5.73 3.283 0 5.58-.982 6.483-1.637l-.163-2.374c-2.873.737-3.94-.49-5.17-8.595-1.15-8.678-4.187-11.953-10.67-13.344z"
        ></path>
      </symbol>
      <symbol id="r-premium" viewBox="0 0 20 20">
        <defs></defs>
        <path
          fill-rule="evenodd"
          d="M8.833 4h.234c1.7 0 2.133.86 2.133 2.927C11.2 8.995 10.767 9.6 9 9.6h-.2V4h.033zm2.294 6.09c2.236-.438 3.259-1.597 3.259-3.257 0-2.255-1.566-3.633-4.761-3.633H4.8v.658c.99.062 1.086.376 1.086 1.315v9.991c0 .908-.223 1.222-1.086 1.316v.657h5.208v-.657c-.862-.063-1.086-.408-1.086-1.316v-4.76h.287c.671 0 1.215.25 1.406.845.288.971.288 3.038.671 4.385.384 1.253 1.31 1.566 2.493 1.566.926 0 1.565-.282 1.821-.438l-.032-.658c-.799.188-1.118-.125-1.47-2.35-.351-2.41-1.182-3.288-2.971-3.664zM2 0h16a2 2 0 012 2v16a2 2 0 01-2 2H2a2 2 0 01-2-2V2a2 2 0 012-2zm-.2.8h16.4a1 1 0 011 1v16.4a1 1 0 01-1 1H1.8a1 1 0 01-1-1V1.8a1 1 0 011-1z"
        ></path>
      </symbol>
      <symbol id="r-icon-search">
        <path
          d="M5.792 9.792c2.208 0 4-1.792 4-4s-1.792-4-4-4-4 1.792-4 4 1.792 4 4 4zm5.333 0l4.417 4.417-1.333 1.333-4.417-4.417v-.708l-.25-.25c-1 .875-2.333 1.375-3.75 1.375C2.584 11.542 0 9.001 0 5.792A5.78 5.78 0 0 1 5.792 0c3.209 0 5.75 2.583 5.75 5.792 0 1.417-.5 2.75-1.375 3.75l.25.25h.708z"
        ></path>
      </symbol>
      <symbol id="r-icon-menu">
        <path d="M0 0h16v2H0zM0 5h12v2H0zM0 10h16v2H0z"></path>
      </symbol>
      <symbol id="r-icon-close">
        <g>
          <path d="M13.645 1.707L2.332 13.02.917 11.606 12.231.292z"></path>
          <path d="M13.645 11.606L2.332.292.917 1.707 12.231 13.02z"></path>
        </g>
      </symbol>
      <symbol id="social-icon-facebook" viewBox="0 0 32 32">
        <path
          d="M19 6h5v-6h-5c-3.86 0-7 3.14-7 7v3h-4v6h4v16h6v-16h5l1-6h-6v-3c0-0.542 0.458-1 1-1z"
        ></path>
      </symbol>
      <symbol id="social-icon-twitter" viewBox="0 0 32 32">
        <path
          d="M24.325 3h4.411l-9.636 11.013 11.336 14.987h-8.876l-6.952-9.089-7.955 9.089h-4.413l10.307-11.78-10.875-14.22h9.101l6.284 8.308zM22.777 26.36h2.444l-15.776-20.859h-2.623z"
        ></path>
      </symbol>
      <symbol id="social-icon-whatsapp" viewBox="0 0 32 32">
        <path
          d="M27.281 4.65c-2.994-3-6.975-4.65-11.219-4.65-8.738 0-15.85 7.112-15.85 15.856 0 2.794 0.731 5.525 2.119 7.925l-2.25 8.219 8.406-2.206c2.319 1.262 4.925 1.931 7.575 1.931h0.006c0 0 0 0 0 0 8.738 0 15.856-7.113 15.856-15.856 0-4.238-1.65-8.219-4.644-11.219zM16.069 29.050v0c-2.369 0-4.688-0.637-6.713-1.837l-0.481-0.288-4.987 1.306 1.331-4.863-0.313-0.5c-1.325-2.094-2.019-4.519-2.019-7.012 0-7.269 5.912-13.181 13.188-13.181 3.519 0 6.831 1.375 9.319 3.862 2.488 2.494 3.856 5.8 3.856 9.325-0.006 7.275-5.919 13.188-13.181 13.188zM23.294 19.175c-0.394-0.2-2.344-1.156-2.706-1.288s-0.625-0.2-0.894 0.2c-0.262 0.394-1.025 1.288-1.256 1.556-0.231 0.262-0.462 0.3-0.856 0.1s-1.675-0.619-3.188-1.969c-1.175-1.050-1.975-2.35-2.206-2.744s-0.025-0.613 0.175-0.806c0.181-0.175 0.394-0.463 0.594-0.694s0.262-0.394 0.394-0.662c0.131-0.262 0.069-0.494-0.031-0.694s-0.894-2.15-1.219-2.944c-0.319-0.775-0.65-0.669-0.894-0.681-0.231-0.012-0.494-0.012-0.756-0.012s-0.694 0.1-1.056 0.494c-0.363 0.394-1.387 1.356-1.387 3.306s1.419 3.831 1.619 4.1c0.2 0.262 2.794 4.269 6.769 5.981 0.944 0.406 1.681 0.65 2.256 0.837 0.95 0.3 1.813 0.256 2.494 0.156 0.762-0.113 2.344-0.956 2.675-1.881s0.331-1.719 0.231-1.881c-0.094-0.175-0.356-0.275-0.756-0.475z"
        ></path>
      </symbol>
      <symbol id="social-icon-linkedin" viewBox="0 0 32 32">
        <path
          d="M12 12h5.535v2.837h0.079c0.77-1.381 2.655-2.837 5.464-2.837 5.842 0 6.922 3.637 6.922 8.367v9.633h-5.769v-8.54c0-2.037-0.042-4.657-3.001-4.657-3.005 0-3.463 2.218-3.463 4.509v8.688h-5.767v-18z"
        ></path>
        <path d="M2 12h6v18h-6v-18z"></path>
        <path
          d="M8 7c0 1.657-1.343 3-3 3s-3-1.343-3-3c0-1.657 1.343-3 3-3s3 1.343 3 3z"
        ></path>
      </symbol>
      <symbol id="social-icon-pinterest" viewBox="0 0 32 32">
        <path
          d="M16 2.138c-7.656 0-13.863 6.206-13.863 13.863 0 5.875 3.656 10.887 8.813 12.906-0.119-1.094-0.231-2.781 0.050-3.975 0.25-1.081 1.625-6.887 1.625-6.887s-0.412-0.831-0.412-2.056c0-1.925 1.119-3.369 2.506-3.369 1.181 0 1.756 0.887 1.756 1.95 0 1.188-0.756 2.969-1.15 4.613-0.331 1.381 0.688 2.506 2.050 2.506 2.462 0 4.356-2.6 4.356-6.35 0-3.319-2.387-5.638-5.787-5.638-3.944 0-6.256 2.956-6.256 6.019 0 1.194 0.456 2.469 1.031 3.163 0.113 0.137 0.131 0.256 0.094 0.4-0.106 0.438-0.338 1.381-0.387 1.575-0.063 0.256-0.2 0.306-0.463 0.188-1.731-0.806-2.813-3.337-2.813-5.369 0-4.375 3.175-8.387 9.156-8.387 4.806 0 8.544 3.425 8.544 8.006 0 4.775-3.012 8.625-7.194 8.625-1.406 0-2.725-0.731-3.175-1.594 0 0-0.694 2.644-0.863 3.294-0.313 1.206-1.156 2.712-1.725 3.631 1.3 0.4 2.675 0.619 4.106 0.619 7.656 0 13.863-6.206 13.863-13.863 0-7.662-6.206-13.869-13.863-13.869z"
        ></path>
      </symbol>
      <symbol id="social-icon-email" viewBox="0 0 32 32">
        <path
          d="M16 14.688l10.688-6.688h-21.375zM26.688 24v-13.313l-10.688 6.625-10.688-6.625v13.313h21.375zM26.688 5.313c1.438 0 2.625 1.25 2.625 2.688v16c0 1.438-1.188 2.688-2.625 2.688h-21.375c-1.438 0-2.625-1.25-2.625-2.688v-16c0-1.438 1.188-2.688 2.625-2.688h21.375z"
        ></path>
      </symbol>
      <symbol id="social-icon-user" viewBox="0 0 45 45">
        <path
          d="M22.5 3.75c-10.313 0-18.75 8.437-18.75 18.75s8.438 18.75 18.75 18.75c10.313 0 18.75-8.438 18.75-18.75s-8.438-18.75-18.75-18.75zM6 22.5c0-9 7.313-16.5 16.5-16.5s16.5 7.313 16.5 16.5c0 3.938-1.313 7.5-3.563 10.313-2.813-1.5-5.813-2.25-9.188-2.25-5.062 0-9.75 2.062-13.312 5.25-4.125-3-6.938-7.875-6.938-13.312z"
        ></path>
        <path
          d="M31.875 22.5c0 3.107-2.518 5.625-5.625 5.625s-5.625-2.518-5.625-5.625c0-3.107 2.518-5.625 5.625-5.625s5.625 2.518 5.625 5.625z"
        ></path>
      </symbol>
      <symbol id="social-icon-youtube" viewBox="0 0 32 32">
        <path
          d="M31.681 9.6c0 0-0.313-2.206-1.275-3.175-1.219-1.275-2.581-1.281-3.206-1.356-4.475-0.325-11.194-0.325-11.194-0.325h-0.012c0 0-6.719 0-11.194 0.325-0.625 0.075-1.987 0.081-3.206 1.356-0.963 0.969-1.269 3.175-1.269 3.175s-0.319 2.588-0.319 5.181v2.425c0 2.587 0.319 5.181 0.319 5.181s0.313 2.206 1.269 3.175c1.219 1.275 2.819 1.231 3.531 1.369 2.563 0.244 10.881 0.319 10.881 0.319s6.725-0.012 11.2-0.331c0.625-0.075 1.988-0.081 3.206-1.356 0.962-0.969 1.275-3.175 1.275-3.175s0.319-2.587 0.319-5.181v-2.425c-0.006-2.588-0.325-5.181-0.325-5.181zM12.694 20.15v-8.994l8.644 4.513-8.644 4.481z"
        ></path>
      </symbol>
      <symbol id="social-icon-instagram" viewBox="0 0 32 32">
        <path
          d="M16 2.881c4.275 0 4.781 0.019 6.462 0.094 1.563 0.069 2.406 0.331 2.969 0.55 0.744 0.288 1.281 0.638 1.837 1.194 0.563 0.563 0.906 1.094 1.2 1.838 0.219 0.563 0.481 1.412 0.55 2.969 0.075 1.688 0.094 2.194 0.094 6.463s-0.019 4.781-0.094 6.463c-0.069 1.563-0.331 2.406-0.55 2.969-0.288 0.744-0.637 1.281-1.194 1.837-0.563 0.563-1.094 0.906-1.837 1.2-0.563 0.219-1.413 0.481-2.969 0.55-1.688 0.075-2.194 0.094-6.463 0.094s-4.781-0.019-6.463-0.094c-1.563-0.069-2.406-0.331-2.969-0.55-0.744-0.288-1.281-0.637-1.838-1.194-0.563-0.563-0.906-1.094-1.2-1.837-0.219-0.563-0.481-1.413-0.55-2.969-0.075-1.688-0.094-2.194-0.094-6.463s0.019-4.781 0.094-6.463c0.069-1.563 0.331-2.406 0.55-2.969 0.288-0.744 0.638-1.281 1.194-1.838 0.563-0.563 1.094-0.906 1.838-1.2 0.563-0.219 1.412-0.481 2.969-0.55 1.681-0.075 2.188-0.094 6.463-0.094zM16 0c-4.344 0-4.887 0.019-6.594 0.094-1.7 0.075-2.869 0.35-3.881 0.744-1.056 0.412-1.95 0.956-2.837 1.85-0.894 0.888-1.438 1.781-1.85 2.831-0.394 1.019-0.669 2.181-0.744 3.881-0.075 1.713-0.094 2.256-0.094 6.6s0.019 4.887 0.094 6.594c0.075 1.7 0.35 2.869 0.744 3.881 0.413 1.056 0.956 1.95 1.85 2.837 0.887 0.887 1.781 1.438 2.831 1.844 1.019 0.394 2.181 0.669 3.881 0.744 1.706 0.075 2.25 0.094 6.594 0.094s4.888-0.019 6.594-0.094c1.7-0.075 2.869-0.35 3.881-0.744 1.050-0.406 1.944-0.956 2.831-1.844s1.438-1.781 1.844-2.831c0.394-1.019 0.669-2.181 0.744-3.881 0.075-1.706 0.094-2.25 0.094-6.594s-0.019-4.887-0.094-6.594c-0.075-1.7-0.35-2.869-0.744-3.881-0.394-1.063-0.938-1.956-1.831-2.844-0.887-0.887-1.781-1.438-2.831-1.844-1.019-0.394-2.181-0.669-3.881-0.744-1.712-0.081-2.256-0.1-6.6-0.1v0z"
        ></path>
        <path
          d="M16 7.781c-4.537 0-8.219 3.681-8.219 8.219s3.681 8.219 8.219 8.219 8.219-3.681 8.219-8.219c0-4.537-3.681-8.219-8.219-8.219zM16 21.331c-2.944 0-5.331-2.387-5.331-5.331s2.387-5.331 5.331-5.331c2.944 0 5.331 2.387 5.331 5.331s-2.387 5.331-5.331 5.331z"
        ></path>
        <path
          d="M26.462 7.456c0 1.060-0.859 1.919-1.919 1.919s-1.919-0.859-1.919-1.919c0-1.060 0.859-1.919 1.919-1.919s1.919 0.859 1.919 1.919z"
        ></path>
      </symbol>
      <symbol id="r-icon-bell" viewBox="0 0 24 24">
        <path
          d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"
        ></path>
      </symbol>
    </svg>
    <div id="rep-slim-header" class="rep-slim-header" role="banner">
      <div class="rep-slim-header__top rep-slim-header__mobile hide-on-desktop">
        <button
          class="rep-slim-header__notification-button"
          data-notify="true"
          hidden=""
        >
          <svg><use href="#r-icon-bell"></use></svg>
        </button>
        <a href="#roulette" class="rep-slim-header__top__subscribe">Abbonati</a>
        <a href="#roulette" class="rep-slim-header__top__premium">
          <svg class="r-premium-logo"><use href="#r-premium"></use></svg>
        </a>
      </div>
      <div class="rep-slim-header__content">
        <div class="rep-slim-header__left">
          <button
            id="repHamOpenButton"
            class="rep-slim-header__item rep-slim-header__menu-button rep-toggle-menu"
          >
            <svg><use href="#r-icon-menu"></use></svg>
            <span class="hide-on-mobile">Menu</span>
          </button>
          <button
            id="repSearchToggleButton"
            class="rep-slim-header__item rep-slim-header__search-button hide-on-mobile"
          >
            <svg><use href="#r-icon-search"></use></svg> Cerca
          </button>
          <button
            class="rep-slim-header__item rep-slim-header__notification-button hide-on-mobile"
            data-notify="true"
            hidden=""
          >
            <svg><use href="#r-icon-bell"></use></svg> Notifiche
          </button>
        </div>
        <div class="rep-slim-header__center">
          <a
            href="#roulette"
            title="la Repubblica"
            class="rep-slim-header__logo"
          >
            <svg class="repubblica-logo">
              <use href="#repubblica-logo"></use>
            </svg>
          </a>
          <a
            href="#roulette"
            class="hide-on-mobile rep-slim-header__item--claim"
            >Abbonati</a
          >
        </div>
        <div class="rep-slim-header__right">
          <a
            href="#roulette"
            class="rep-slim-header__item hide-on-mobile rep-slim-header__item--subscribe"
            >Abbonati</a
          >
          <a
            href="#roulette"
            class="rep-slim-header__item hide-on-mobile rep-slim-header__item--smile"
            >Gedi Smile</a
          >
          <a
            href="#roulette"
            class="rep-slim-header__item hide-on-mobile rep-slim-header__item--premium"
          >
            <!-- <span>Quotidiano</span> -->
            <svg class="r-premium-logo">
              <use href="#r-premium"></use></svg
          ></a>
          <div
            id="rep-user"
            class="rep-slim-header__item rep-slim-header__user"
          >
            <span id="account-data-container"></span>
          </div>
        </div>
      </div>
      <div id="repSearchForm">
        <div class="rep-slim-header__content">
          <form action="#roulette" method="get" class="rep-slim-header__search">
            <input
              type="search"
              required=""
              name="query"
              placeholder="Cerca articoli o argomenti"
              value=""
            />
            <button type="submit">
              <svg><use href="#r-icon-search"></use></svg>
            </button>
          </form>
          <button
            id="repSearchFormCloseButton"
            class="rep-slim-header__search__close-button"
          >
            <svg><use href="#r-icon-close"></use></svg>
          </button>
        </div>
      </div>
    </div>
    <header id="dossier-header" class="dossier-header">
      <div class="dossier-header__content">
        <a href="#roulette">
          <picture class="dossier-header__graphic">
            <source
              srcset="
                images/164749964-0d69b605-9700-4755-a711-8e679c378fc6_1.jpg
              "
              type="image/webp"
            />
            <img
              src="images/164749964-0d69b605-9700-4755-a711-8e679c378fc6.jpg"
              alt=""
            />
          </picture>
        </a>
      </div>
      <div class="main-nav has-search">
        <nav>
          <ul>
            <li>
              <a fck_savedurl="" href="#roulette"
                >VAI ALLA HOMEPAGE DI FRONTIERE</a
              >
            </li>

            <li>
              <a fck_savedurl="" href="#roulette">VIDEO</a>
            </li>

            <li>
              <a href="#roulette">VAI ALLA HOMEPAGE DI SALUTE</a>
            </li>
          </ul>
        </nav>

        <button class="main-nav__search__button" id="mainNavSearchButton">
          <svg viewBox="0 0 24 24">
            <path
              d="M9.516 14.016c2.484 0 4.5-2.016 4.5-4.5s-2.016-4.5-4.5-4.5-4.5 2.016-4.5 4.5 2.016 4.5 4.5 4.5zM15.516 14.016l4.969 4.969-1.5 1.5-4.969-4.969v-0.797l-0.281-0.281c-1.125 0.984-2.625 1.547-4.219 1.547-3.609 0-6.516-2.859-6.516-6.469s2.906-6.516 6.516-6.516 6.469 2.906 6.469 6.516c0 1.594-0.563 3.094-1.547 4.219l0.281 0.281h0.797z"
            ></path>
          </svg>
        </button>

        <div class="main-nav__search__form" id="mainNavSearchForm">
          <form action="#roulette" method="get">
            <input
              type="text"
              class="main-nav__search__input"
              name="query"
              placeholder="CERCA"
              value=""
              maxlength="100"
            />
            <button
              class="main-nav__search__submit"
              value="Submit"
              type="submit"
            >
              <svg viewBox="0 0 24 24">
                <path
                  d="M9.516 14.016c2.484 0 4.5-2.016 4.5-4.5s-2.016-4.5-4.5-4.5-4.5 2.016-4.5 4.5 2.016 4.5 4.5 4.5zM15.516 14.016l4.969 4.969-1.5 1.5-4.969-4.969v-0.797l-0.281-0.281c-1.125 0.984-2.625 1.547-4.219 1.547-3.609 0-6.516-2.859-6.516-6.469s2.906-6.516 6.516-6.516 6.469 2.906 6.469 6.516c0 1.594-0.563 3.094-1.547 4.219l0.281 0.281h0.797z"
                ></path>
              </svg>
            </button>
          </form>
        </div>
      </div>
    </header>

    <main>
      <article class="story" data-blocks="1">
        <header class="story__hero">
          <div class="story__overtitle">
            <div id="social-share-top">
              <button class="comments-trigger">
                <svg class="r-icon-comment">
                  <use href="#r-icon-comment"></use>
                </svg>
              </button>
              <ul class="gd-social-share">
                <li>
                  <a href="#" data-share="facebook"
                    ><svg><use href="#social-icon-facebook"></use></svg
                  ></a>
                </li>
                <li>
                  <a href="#" data-share="twitter"
                    ><svg><use href="#social-icon-twitter"></use></svg
                  ></a>
                </li>
                <li>
                  <a href="#" data-share="email"
                    ><svg><use href="#social-icon-email"></use></svg
                  ></a>
                </li>
                <li>
                  <a href="#" data-share="linkedin"
                    ><svg><use href="#social-icon-linkedin"></use></svg
                  ></a>
                </li>
                <li>
                  <a href="#" data-share="pinterest"
                    ><svg><use href="#social-icon-pinterest"></use></svg
                  ></a>
                </li>
                <li class="gd-social-share__whatsapp">
                  <a href="#" data-share="whatsapp"
                    ><svg><use href="#social-icon-whatsapp"></use></svg
                  ></a>
                </li>
              </ul>
            </div>
            <!-- #end include/detail/top-sharebar  -->
          </div>
          <div class="story__header has-medium-media">
            <div class="story__header__content">
              <h1 class="story__title">
                Reumatologia, nuove sfide e progetti per coinvolgere anche il
                "grande pubblico"
              </h1>
              <em class="story__author"> diaDario Rubino </em>
            </div>
            <figure class="story__media">
              <picture style="padding-bottom: calc((416 / 735) * 100%)">
                <source
                  media="(max-width: 767px)"
                  srcset="
                    images/164533144-96d4d18d-a327-48ff-a714-500bb7fc9701_1.jpg
                  "
                  type="image/webp"
                />
                <source
                  srcset="
                    images/164531616-9a7214e1-cb9a-432f-af92-a9ab43b79560_1.jpg
                  "
                  type="image/webp"
                />
                <source
                  media="(max-width: 767px)"
                  srcset="
                    images/164533144-96d4d18d-a327-48ff-a714-500bb7fc9701.jpg
                  "
                />
                <img
                  src="images/164531616-9a7214e1-cb9a-432f-af92-a9ab43b79560.jpg"
                  alt="Reumatologia, nuove sfide e progetti per coinvolgere anche
                il"
                />
              </picture>
            </figure>
            <div class="story__summary">
              Più diagnosi precoci e meno attese, ma anche più reumatologi e più
              sensibilizzazione di pubblico e istituzioni. Ecco come il nuovo
              presidente SIR Gian Domenico Sebastiani intende affrontare le
              sfide della reumatologia italiana nei prossimi anni. L’intervista
            </div>
          </div>
        </header>
        <div class="story__toolbar">
          <time datetime="2022-11-28T16:28:00Z" class="story__date"
            >28 Novembre 2022</time
          >
          <span class="story__date__update"
            >Aggiornato
            <time datetime="2022-11-29T10:17:04Z"
              >29 Novembre 2022 alle 11:17</time
            ></span
          >

          <span class="story__toolbar__reading-time"
            ><svg class="r-icon-time"><use href="#r-icon-time"></use></svg> 2
            minuti di lettura</span
          >
        </div>

        <div class="bottom-wrapper">
          <div class="main-content">
            <div class="story__wrapper">
              <div id="gs-social-sharebutton-float">
                <div class="social-share-sticky">
                  <button id="commentsTriggerTop" class="comments-trigger">
                    <svg class="r-icon-comment">
                      <use href="#r-icon-comment"></use>
                    </svg>
                  </button>
                  <ul class="gd-social-share">
                    <li>
                      <a href="#" data-share="facebook"
                        ><svg><use href="#social-icon-facebook"></use></svg
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-share="twitter"
                        ><svg><use href="#social-icon-twitter"></use></svg
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-share="email"
                        ><svg><use href="#social-icon-email"></use></svg
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-share="linkedin"
                        ><svg><use href="#social-icon-linkedin"></use></svg
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-share="pinterest"
                        ><svg><use href="#social-icon-pinterest"></use></svg
                      ></a>
                    </li>
                    <li class="gd-social-share__whatsapp">
                      <a href="#" data-share="whatsapp"
                        ><svg><use href="#social-icon-whatsapp"></use></svg
                      ></a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="viafoura">
                <vf-tray class="vf-tray--modal-override"></vf-tray>
              </div>

              <div class="story__content" id="article-body">
                <aside class="story__tags">
                  <h5 class="story__tags__label">Argomenti</h5>
                  <ul class="story__tags__list">
                    <li>
                      <a class="type-topic" href="#roulette"
                        >malattie reumatiche</a
                      >
                    </li>
                  </ul>
                </aside>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae maxime quasi nesciunt tempore est rem voluptatum nihil placeat! Ea optio voluptate adipisci architecto magni, et accusamus unde corrupti voluptatibus assumenda.
                Eligendi recusandae beatae repudiandae placeat tempore consectetur omnis rem laudantium animi. Temporibus, nostrum sed nobis quis, dicta ipsa tenetur eius a, blanditiis quos ea iure at! Ipsam optio laudantium cum.
                Architecto aspernatur animi ullam, quam quos fuga quisquam ratione et sequi repellat, at nam. Veritatis, beatae rerum aut dolores aperiam ipsam, possimus amet provident culpa, labore inventore iusto itaque laborum?
                Quia quibusdam reiciendis ipsam, obcaecati corporis id, possimus officiis temporibus harum est consequatur aliquam, itaque a cum et ad placeat aperiam? Nulla similique doloribus tempora delectus itaque esse provident laudantium!
                Nemo temporibus consequatur ratione dolor ut cum, quia recusandae? Velit recusandae nulla quam nesciunt quisquam nemo quia vitae facilis id provident, dolores placeat necessitatibus sed molestiae ipsa non ab cupiditate.
                Voluptate quibusdam repellendus commodi aliquam nobis, sapiente rerum iusto laboriosam, a sunt ut ipsum dolor. Aspernatur reiciendis nesciunt cumque atque animi officia eum repellendus, corrupti nulla, voluptates nisi consectetur voluptatibus!
                Beatae tempora ratione dolores, esse maxime adipisci aut, pariatur fuga voluptatibus dolorum facilis distinctio architecto similique praesentium, aperiam magnam ipsa assumenda! Repellat, accusamus magnam iure neque reprehenderit vitae cum commodi!
                Iusto eaque possimus at rem non tempora quas blanditiis, esse maiores quia aut alias minima ducimus amet asperiores dolor suscipit eligendi odio, corrupti magni recusandae. Aspernatur eligendi natus fugiat repellendus.
                Nam repellendus ut suscipit. Eveniet quam molestias esse consectetur nam minima eum illo facilis nemo perferendis! Quos hic porro assumenda ea laudantium accusamus perspiciatis quo mollitia, nulla quas minima a?
                Vitae quam impedit soluta libero dolorum modi dolores fugit porro deleniti aliquid reiciendis quas, qui dignissimos perspiciatis exercitationem vero consequuntur quia quidem nemo? Exercitationem debitis quod vero quasi quibusdam rerum!
              </div>
            </div>
          </div>

          <div class="sidebar">
            <div class="sidebar__sticky">
              <link rel="stylesheet" href="css/slider.css" />

              <aside id="widgetSlider-ch">
                <div class="swiper-container swiper-ch-container">
                  <div class="swiper-wrapper">
                    <div class="swiper-slide">
                      <article class="entry from-green_and_blue">
                        <h4 class="entry_header">
                          <a href="#roulette">Green and Blue</a>
                        </h4>

                        <figure class="entry_media">
                          <a href="#roulette">
                            <picture
                              style="padding-bottom: calc((431 / 767) * 100%)"
                            >
                              <img
                                src="images/111417511-29589601-e229-419c-addf-474b587af649.png"
                                alt=""
                                class="lazyload"
                              />
                            </picture>
                          </a>
                        </figure>

                        <div class="entry_content">
                          <h2 class="entry_title">
                            <a href="#roulette"
                              >Bonus per l'isolamento termico della casa:
                              efficienza energetica per tutte le stagioni</a
                            >
                          </h2>

                          <span class="entry_author">di Antonella Donati</span>
                        </div>
                      </article>
                    </div>

                    <div class="swiper-slide">
                      <!-- from-ilgusto -->
                      <article class="entry from-ilgusto">
                        <h4 class="entry_header">
                          <a href="#roulette">Il Gusto</a>
                        </h4>

                        <figure class="entry_media">
                          <a href="#roulette">
                            <picture
                              style="padding-bottom: calc((431 / 767) * 100%)"
                            >
                              <img
                                src="images/172724669-02d0f113-8c12-4b13-8bb3-ce270d815163.jpg"
                                alt=""
                                class="lazyload"
                              />
                            </picture>
                          </a>
                        </figure>

                        <div class="entry_content">
                          <h2 class="entry_title">
                            <a href="#roulette"
                              >Report attacca la chimica nel vino. Le cantine:
                              “Non facciamo prodotti omologati”</a
                            >
                          </h2>
                        </div>
                      </article>
                    </div>

                    <div class="swiper-slide">
                      <!-- from-la_zampa -->
                      <article class="entry from-la_zampa">
                        <h4 class="entry_header">
                          <a href="#roulette">La Zampa</a>
                        </h4>

                        <figure class="entry_media">
                          <a href="#roulette">
                            <picture
                              style="padding-bottom: calc((431 / 767) * 100%)"
                            >
                              <img
                                src="images/165512736-6f1b6d5e-e033-4f65-a590-cf345caa2026.jpg"
                                class="lazyload"
                              />
                            </picture>
                          </a>
                        </figure>

                        <div class="entry_content">
                          <h2 class="entry_title">
                            <a href="#roulette"
                              >Alto Adige, è morto il 73 enne trovato con
                              profonde morsicature sul corpo. Ora il test del
                              dna per capire l'animale aggressore</a
                            >
                          </h2>
                        </div>
                      </article>
                    </div>

                    <div class="swiper-slide">
                      <!-- from-tech -->
                      <article class="entry from-tech">
                        <h4 class="entry_header">
                          <a href="#roulette">Italian.Tech</a>
                        </h4>

                        <figure class="entry_media">
                          <a href="#roulette">
                            <picture
                              style="padding-bottom: calc((431 / 767) * 100%)"
                            >
                              <img
                                src="images/132707955-95e4bbd6-7468-4d77-8363-98936f34a6f8.jpg"
                                alt=""
                                class="lazyload"
                              />
                            </picture>
                          </a>
                        </figure>

                        <div class="entry_content">
                          <h2 class="entry_title">
                            <a href="#roulette"
                              >OpenAI, i video di Sora non sono perfetti. Perché
                              non ce ne siamo accorti subito?</a
                            >
                          </h2>
                        </div>
                      </article>
                    </div>
                  </div>
                  <div class="widget-slider__pagination"></div>
                </div>
              </aside>

              <script
                src="./js/slider.js"
                async=""
                onload="widgetSlider('#widgetSlider-ch')"
              ></script>

              <section class="aside-stories">
                <h3 class="aside-stories__label">Leggi anche</h3>

                <article class="aside-story">
                  <figure class="aside-story__media">
                    <a href="#roulette">
                      <picture>
                        <img
                          src="images/124952905-e4b21973-8e34-47f8-ba12-d5ebc4fdd366.jpg"
                          alt="Pronto soccorso nel caos: colpa del calo di vaccinazioni contro Covid e influenza"
                          class="lazyload"
                          width="70"
                          height="70"
                        />
                      </picture>
                    </a>
                  </figure>

                  <div class="aside-story__content">
                    <h4 class="aside-story__title">
                      <a href="#roulette"
                        >Pronto soccorso nel caos: colpa del calo di
                        vaccinazioni contro Covid e influenza</a
                      >
                    </h4>
                  </div>
                </article>

                <article class="aside-story">
                  <figure class="aside-story__media">
                    <a href="#roulette">
                      <picture>
                        <img
                        src="images/134922368-a23486dd-16c0-46a3-9df8-884c6be8beb9.jpg"
                          alt="Psoriasi cutanea e artrite psoriasica: cosa c’è da sapere"
                          class="lazyload"
                          width="70"
                          height="70"
                        />
                      </picture>
                    </a>
                  </figure>

                  <div class="aside-story__content">
                    <h4 class="aside-story__title">
                      <a href="#roulette"
                        >Psoriasi cutanea e artrite psoriasica: cosa c’è da
                        sapere</a
                      >
                    </h4>
                  </div>
                </article>

                <article class="aside-story">
                  <figure class="aside-story__media">
                    <a href="#roulette">
                      <picture>
                        <img
                          src="images/145827124-89ba55a4-472f-4243-ae33-c686bcf57b7c.jpg"
                          alt="Il guerriero della necropoli con il “gomito del tennista”"
                          class="lazyload"
                          width="70"
                          height="70"
                        />
                      </picture>
                    </a>
                  </figure>

                  <div class="aside-story__content">
                    <h4 class="aside-story__title">
                      <a href="#roulette"
                        >Il guerriero della necropoli con il “gomito del
                        tennista”</a
                      >
                    </h4>
                  </div>
                </article>
              </section>

              <link rel="stylesheet" href="css/style.css" />
              <section class="aside-related from-salute">
                <h2 class="aside-related__header">
                  <a href="#roulette">Salute</a>
                </h2>

                <article class="aside-related__story">
                  <figure class="entry__media aside-related__media">
                    <a href="#roulette">
                      <picture>
                        <img
                          src="images/092228877-ac334572-4e1d-44a4-bc41-afc4034a8735.jpg"
                          alt=""
                          class="lazyload"
                        />
                      </picture>
                    </a>
                  </figure>

                  <div class="aside-related__content">
                    <h2 class="aside-related__title">
                      <a href="#roulette"
                        >Procreazione assistita, a 20 anni dalla legge 40 quali
                        criticita restano</a
                      >
                    </h2>
                    <span class="aside-related__author">di Noemi Penna</span>
                  </div>
                </article>

                <article class="aside-related__story">
                  <figure class="entry__media aside-related__media">
                    <a href="#roulette">
                      <picture>
                        <img
                          src="images/092456663-883972ef-c760-4258-a644-bf55fd4f075e.jpg"
                          alt=""
                          class="lazyload"
                        />
                      </picture>
                    </a>
                  </figure>

                  <div class="aside-related__content">
                    <h2 class="aside-related__title">
                      <a href="#roulette"
                        >Dolore cronico, l'attivita fisica regolare lo può
                        contrastare</a
                      >
                    </h2>
                    <span class="aside-related__author"
                      >di Aureliano Stingi</span
                    >
                  </div>
                </article>

                <a href="#roulette" class="aside-related__footer"
                  >leggi tutte le notizie di Salute &gt;
                </a>
              </section>
            </div>
          </div>
          <footer class="story__footer">
            <span class="story__footer__copyright"
              >© Riproduzione riservata</span
            >
          </footer>
        </div>
      </article>
    </main>

    <footer
      id="rep-page-footer"
      class="rep-page-footer"
      role="contentinfo"
    >
      <div class="rep-page-footer__top">
        <div class="rep-page-footer-content">
          <div class="rep-page-footer__top__intro">
            <h1 class="rep-page-footer__top__intro__title">Il Network</h1>
            <a class="rep-page-footer__toggler"><span></span></a>
          </div>
          <div class="rep-page-footer__top__content">
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">
                Supplementi Repubblica
              </h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="Affari &amp; Finanza"
                    >Affari e Finanza</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="D">D</a>
                </li>
                <li>
                  <a href="#roulette" title="Il Venerdì">Il Venerdì</a>
                </li>
                <li>
                  <a href="#roulette" title="Robinson">Robinson</a>
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">
                Gedi News Network
              </h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="La Stampa">La Stampa</a>
                </li>
                <li>
                  <a href="#roulette" title="Il Secolo XIX"
                    >Il Secolo XIX</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Huffington Post Italia"
                    >Huffington Post Italia</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="FEM">Fem</a>
                </li>
                <li>
                  <a href="#roulette" title="Formula Passion"
                    >Formula Passion</a
                  >
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">
                Quotidiani locali
              </h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="Gazzetta di Mantova"
                    >Gazzetta di Mantova</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Corriere delle Alpi"
                    >Corriere delle Alpi</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Il mattino di Padova"
                    >Il mattino di Padova</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Il Piccolo">Il Piccolo</a>
                </li>
                <li>
                  <a href="#roulette" title="La Nuova Venezia"
                    >La Nuova Venezia</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="La Provincia Pavese"
                    >La Provincia Pavese</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="La Sentinella del Canavese"
                    >La Sentinella del Canavese</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="La Tribuna di Treviso"
                    >La Tribuna di Treviso</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Messaggero Veneto"
                    >Messaggero Veneto</a
                  >
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">Periodici</h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="Le Scienze">Le Scienze</a>
                </li>
                <li>
                  <a href="#roulette" title="Limes">Limes</a>
                </li>
                <li>
                  <a href="#roulette" title="National Geographic"
                    >National Geographic</a
                  >
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">Radio</h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="DeeJay">DeeJay</a>
                </li>
                <li>
                  <a href="#roulette" title="Capital">Capital</a>
                </li>
                <li>
                  <a href="#roulette" title="m2o">m2o</a>
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">
                Iniziative Editoriali
              </h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="Tutte le iniziative"
                    >In edicola</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Biblioteca Digitale"
                    >Biblioteca Digitale</a
                  >
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">
                Servizi, tv e consumi
              </h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="Annunci">Annunci</a>
                </li>
                <li>
                  <a href="#roulette" title="Ilmiolibro">Ilmiolibro</a>
                </li>
                <li>
                  <a href="#roulette" title="Necrologie">Necrologie</a>
                </li>
                <li>
                  <a href="#roulette" title="Miojob">Miojob</a>
                </li>
                <li>
                  <a href="#roulette" title="Enti e Tribunali"
                    >Enti e Tribunali</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Meteo">Meteo</a>
                </li>
                <li>
                  <a href="#roulette" title="Shop">Joy</a>
                </li>
                <li>
                  <a href="#roulette" title="tvzap">Tvzap</a>
                </li>
                <li>
                  <a href="" title="Dizionario italiano"
                    >Dizionario italiano</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Dizionario inglese/italiano"
                    >Dizionario inglese/italiano</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Consigli.it">Consigli.it</a>
                </li>
              </ul>
            </section>
            <section class="rep-page-footer__section">
              <h2 class="rep-page-footer__section__title">Partnership</h2>
              <ul class="rep-page-footer__section__list">
                <li>
                  <a href="#roulette" title="Visual Lab">LAB</a>
                </li>
                <li>
                  <a href="#roulette" title="MyMovies">MyMovies</a>
                </li>
                <li>
                  <a href="#roulette" title="Offerte Auto Nuove"
                    >AutoXY</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Formula Passion"
                    >Formula Passion</a
                  >
                </li>
                <li>
                  <a href="#roulette" title="Sport.it">Sport.it</a>
                </li>
              </ul>
            </section>
          </div>
        </div>
      </div>
      <div class="rep-page-footer__middle">
        <div class="rep-page-footer-content">
          <ul>
            <li class="hide-on-mobile">
              <a href="#roulette" title="Mappa del sito"
                >Mappa del sito</a
              >
            </li>
            <li class="hide-on-mobile">
              <a href="#roulette" title="Redazione">Redazione</a>
            </li>
            <li class="hide-on-mobile">
              <a href="#roulette" title="Scriveteci">Scriveteci</a>
            </li>
            <li>
              <a href="#roulette" title="Per inviare foto e video"
                >Per inviare foto e video</a
              >
            </li>
            <li>
              <a href="#roulette" title="Servizio Clienti"
                >Servizio Clienti</a
              >
            </li>
            <li>
              <a href="#roulette" title="Pubblicita">Pubblicita</a>
            </li>
            <li>
              <a href="#roulette" id="kw-cookie-link">Cookie Policy</a>
            </li>
            <li>
              <a href="#roulette" id="kw-privacy-link">Privacy</a>
            </li>
            <li>
              <a
                href="#roulette"
                id="ethics"
                title="Codice Etico e Best Practices"
                >Codice Etico e Best Practices</a
              >
            </li>
          </ul>
        </div>
      </div>
      <div class="rep-page-footer__bottom">
        <div class="rep-page-footer-content">
          <a href="#roulette">GEDI News Network S.p.A.</a>
          - P.Iva 01578251009 - ISSN 2499-0817
        </div>
      </div>
    </footer>
  </body>
</html>
