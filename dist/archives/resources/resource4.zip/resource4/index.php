<!DOCTYPE html>
<html lang="ru" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1">
    <meta name="geo.region" content="KZ">
    <meta name="application-name" content="Новости Диапазон.kz">
    <meta name="msapplication-TileColor" content="#cfd8dc">
    <meta name="theme-color" content="#cfd8dc">
    <title>Kardisen</title>
    <meta property="og:image:width" content="710">
    <meta property="og:image:height" content="444">
    <link rel="stylesheet" href="./dist/bundle.css">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>

<body>

    <div class="main-wrapper">
        <header class="header">
            <div class="header__top">
                <div class="header__top-container">
                    <div class="header__logo-tag-wrap">
                        <a href="#roulette" class="header__link-main">
                            <img loading="lazy" src="./img/logo.svg" alt="Диапазон"
                                class="header__logo">
                        </a>
                        <h1 class="header__tagline">Главные новости {{country_name_genitive}} ,<br>Европы и мира</h1>
                    </div>
                    <div class="header__socials">
                        <div class="header__socials-wrap socials">
                            <p class="header__socials-title">Мы в соцсетях</p>
                            <ul class="socials__list socials__list--header">
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--vk" title="Мы в ВКонтакте"></a></li>
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--ok" title="Мы в Одноклассниках"></a></li>
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--fb" title="Мы в Facebook"></a></li>
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--tt" title="Мы в TikTok"></a></li>
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--inst" title="Мы в Instagram"></a></li>
                            </ul>
                        </div>
                        <div class="header__socials-wrap socials">
                            <p class="header__socials-title">Напишите нам</p>
                            <ul class="socials__list socials__list--header">
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--tg" title="Мы в Telegram"></a></li>
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--wa" title="Мы в WhatsApp"></a></li>
                                <li class="socials__item"><a href="#roulette" target="_blank" rel="noreferrer nofollow"
                                        class="socials__link socials__link--mail" title="Наша электронная почта"></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="header__actions-wrap">
                        <a href="#roulette" class="header__action header__action--add-advert link-parent"><span
                                class="header__action-text link">Прайс-<span class="nowyear"></span></span></a>
                        <a href="#roulette" class="header__action header__action--lk link-parent"><span
                                class="header__action-text link">Личный кабинет</span></a>
                    </div>
                </div>
            </div>
            <div class="header__nav-wrap">
                <nav class="header__nav-container">
                    <ul class="header__navigation-list">
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Новости</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Газета</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Экономика</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Криминал</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Спорт</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Жизнь</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  is-active  ">Здоровье</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Народный репортер</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Политика</a>
                        </li>
                        <li class="header__navigation-item">
                            <a href="#roulette" class="header__nav-link  ">Вопрос-ответ</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
        <div class="content">
            <aside class="content__main-topics main-topics">
                <div class="main-topics__container">
                    <h2 class="main-topics__title">Главные темы</h2>
                    <div class="main-topics__list js_podkat_source">
                        <a href="#roulette" class="main-topics__item link-parent "><span
                                class="main-topics__link link">Мнения</span></a>
                        <a href="#roulette" class="main-topics__item link-parent "><span
                                class="main-topics__link link">Что? Где? Почем?</span></a>
                        <a href="#roulette" class="main-topics__item link-parent "><span
                                class="main-topics__link link">Украина</span></a>
                        <a href="#roulette" class="main-topics__item link-parent "><span
                                class="main-topics__link link">Лица</span></a>
                        <a href="#roulette" class="main-topics__item link-parent "><span
                                class="main-topics__link link">Возраста.net</span></a>
                        <a href="#roulette" class="main-topics__item link-parent "><span
                                class="main-topics__link link">Выборы <span class="nowyear"></span></span></a>
                    </div>
                    <div class="main-topics__other-items js_podkat_roll">
                        <div class="main-topics__link-wrap">
                            <span class="main-topics__link">Еще</span>
                        </div>
                        <div class="main-topics__podkat-roll">
                            <div class="main-topics__podkat-roll-list js_podkat_roll_list">
                                <a href="#roulette"
                                    class="main-topics__item main-topics__item--overflow link-parent "><span
                                        class="main-topics__link link">Мнения</span></a>
                                <a href="#roulette"
                                    class="main-topics__item main-topics__item--overflow link-parent "><span
                                        class="main-topics__link link">Что? Где? Почем?</span></a>
                                <a href="#roulette"
                                    class="main-topics__item main-topics__item--overflow link-parent "><span
                                        class="main-topics__link link">Украина</span></a>
                                <a href="#roulette"
                                    class="main-topics__item main-topics__item--overflow link-parent "><span
                                        class="main-topics__link link">Лица</span></a>
                                <a href="#roulette"
                                    class="main-topics__item main-topics__item--overflow link-parent "><span
                                        class="main-topics__link link">Возраста.net</span></a>
                                <a href="#roulette"
                                    class="main-topics__item main-topics__item--overflow link-parent "><span
                                        class="main-topics__link link">Выборы <span class="nowyear"></span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>
            <main class="content__container container">
                <aside class="container__col-average col-average">
                    <div class="col-average__last-news last-news">
                        <h2 class="last-news__title">Последние новости</h2>
                        <div class="last-news__scroll-wrap" data-simplebar>
                            <ul class="last-news__list  last-news__list--fresh ">
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Двое юнцов разбивали уличные фонари
                                            для «эффектного» видео</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time">11:03</time>
                                        <span class="last-news__views  last-news__views--ml "
                                            title="Просмотры">28</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Детям городской школы показали, что такое
                                            сельский труд и природа</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time">10:53</time>
                                        <span class="last-news__views  last-news__views--ml "
                                            title="Просмотры">40</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Народный репортер. Дорогу невозможно перейти
                                            из-за высоких бордюров</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time">10:39</time>
                                        <span class="last-news__views  last-news__views--ml "
                                            title="Просмотры">61</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Школьник нашел телефон и потратил
                                            чужие деньги</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time">10:19</time>
                                        <span class="last-news__views  last-news__views--ml "
                                            title="Просмотры">104</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">В Израиль вылетел самолет за
                                            гражданами {{country_name_genitive}}</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time">09:48</time>
                                        <span class="last-news__views  last-news__views--ml "
                                            title="Просмотры">92</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">
                                            <font pl-country="at">В Австрии</font>
                                            <font pl-country="bg">В Болгарии</font>
                                            <font pl-country="hu">В Венгрии</font>
                                            <font pl-country="de">В Германии</font>
                                            <font pl-country="gr">В Греции</font>
                                            <font pl-country="es">В Испании</font>
                                            <font pl-country="it">В Италии</font>
                                            <font pl-country="cy">На Кипре</font>
                                            <font pl-country="lv">В Латвии</font>
                                            <font pl-country="lt">В Литве</font>
                                            <font pl-country="pl">В Польше</font>
                                            <font pl-country="pt">В Португалии</font>
                                            <font pl-country="ro">В Румынии</font>
                                            <font pl-country="sk">В Словакии</font>
                                            <font pl-country="fr">Во Франции</font>
                                            <font pl-country="hr">В Хорватии</font>
                                            <font pl-country="cz">В Чехии</font>
                                            <font pl-country="ee">В Эстонии</font> произошла аварийная
                                            ситуация на
                                            газопроводе
                                        </span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                        <a href="#roulette" class="last-news__comments" title="Комментарии">1</a>
                                        <span class="last-news__views " title="Просмотры">747</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Три мешка карасей незаконно выловил
                                            житель города <font class="pl_city_stock7"></font></span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                        <a href="#roulette" class="last-news__comments" title="Комментарии">1</a>
                                        <span class="last-news__views " title="Просмотры">841</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Народный репортер. Новые фонари не&nbsp;горели
                                            ни&nbsp;дня</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                        <a href="#roulette" class="last-news__comments" title="Комментарии">1</a>
                                        <span class="last-news__views " title="Просмотры">439</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Стихи поэта и музыканта из {{country_name_genitive}} издали
                                            в&nbsp;Грузии</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                        <span class="last-news__views  last-news__views--ml "
                                            title="Просмотры">386</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Незастрахованным европейцам могут запретить
                                            водить авто</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                        <a href="#roulette" class="last-news__comments" title="Комментарии">1</a>
                                        <span class="last-news__views " title="Просмотры">474</span>
                                    </div>
                                </li>
                                <li class="last-news__item">
                                    <a href="#roulette" class="last-news__name link-parent">
                                        <span class="last-news__link link">Народный репортер. Зверски погнули скамейку в
                                            районе Филармонии</span>
                                    </a>
                                    <div class="last-news__meta-row">
                                        <time class="last-news__pub-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                        <a href="#roulette" class="last-news__comments" title="Комментарии">1</a>
                                        <span class="last-news__views " title="Просмотры">367</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-average__popular-news popular-news">
                        <div class="popular-news__radio-wrap">
                            <button type="button"
                                class="popular-news__radio-btn js_popular_news_lb is-active">Популярные <br>
                                новости</button>
                            <button type="button" class="popular-news__radio-btn js_popular_news_rb">Последние <br>
                                комментарии</button>
                        </div>
                        <div class="popular-news__scroll-wrap" data-simplebar>
                            <ul class="popular-news__list js_popular_news_list_l">
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Мигранты захватили рынки в ряде регионов, считает муниципальный депутат
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="6" daysint></span></time>
                                        <span class="popular-news__item-views">13971</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            <font pl-country="at">В Австрии</font>
                                            <font pl-country="bg">В Болгарии</font>
                                            <font pl-country="hu">В Венгрии</font>
                                            <font pl-country="de">В Германии</font>
                                            <font pl-country="gr">В Греции</font>
                                            <font pl-country="es">В Испании</font>
                                            <font pl-country="it">В Италии</font>
                                            <font pl-country="cy">На Кипре</font>
                                            <font pl-country="lv">В Латвии</font>
                                            <font pl-country="lt">В Литве</font>
                                            <font pl-country="pl">В Польше</font>
                                            <font pl-country="pt">В Португалии</font>
                                            <font pl-country="ro">В Румынии</font>
                                            <font pl-country="sk">В Словакии</font>
                                            <font pl-country="fr">Во Франции</font>
                                            <font pl-country="hr">В Хорватии</font>
                                            <font pl-country="cz">В Чехии</font>
                                            <font pl-country="ee">В Эстонии</font> заканчиваются тёплые деньки
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="5" daysint></span></time>
                                        <span class="popular-news__item-views">5014</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Фото океанского кита заняло призовое место на международном конкурсе
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="6" daysint></span></time>
                                        <span class="popular-news__item-views">4102</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Какие продукты подорожали {{country_name_locational}}
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="6" daysint></span></time>
                                        <span class="popular-news__item-views">2556</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Куда сходить {{country_name_locational}}
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="5" daysint></span></time>
                                        <span class="popular-news__item-views">2440</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Счета 20 бизнесменов незаконно арестовали {{country_name_locational}}
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="5" daysint></span></time>
                                        <span class="popular-news__item-views">2318</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Тарифы на комуслуги снизили&nbsp;– читайте в свежем выпуске «Диапазона»
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="5" daysint></span></time>
                                        <span class="popular-news__item-views">2254</span>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link link">
                                            Как Элла Витальевна выучила язык, чтобы стать учителем в школе {{country_name_locational}}
                                        </span>
                                    </a>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="4" daysint></span></time>
                                        <span class="popular-news__item-views">1995</span>
                                    </div>
                                </li>
                            </ul>
                            <ul class="popular-news__list hide js_popular_news_list_r">
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link popular-news__item-link--c-gray link">От
                                            10&nbsp;тысяч до 20&nbsp;тысяч евро заплатили мошеннику желающие
                                            получить работу</span>
                                    </a>
                                    <span class="popular-news__item-text">Почему уголовное дело в отношении этого
                                        афериста возбудили по части первой, а не на более тяжкое? Чтобы этот подлец
                                        избежал наказания, не&nbsp;связанное с&nbsp;лишением...</span>
                                    <p class="popular-news__author">Шындыкбай<span
                                            class="popular-news__author--like"></span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time">10:35</time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link popular-news__item-link--c-gray link">Что
                                            тревожит жителей {{country_name_genitive}}</span>
                                    </a>
                                    <span class="popular-news__item-text">Солидарен с Вами, Мамбет-аға... Пинатель снега
                                        у нас, щаз наверное корячится у чёрта на сковородке за свои гнусные
                                        проделки)))</span>
                                    <p class="popular-news__author">Шындыкбай<span
                                            class="popular-news__author--like"></span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time">10:25</time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link popular-news__item-link--c-gray link">в
                                            Австрии произошла аварийная ситуация на газопроводе</span>
                                    </a>
                                    <span class="popular-news__item-text">Как приятно когда у нас есть экстренные
                                        службы, своевременно реагирующие на разного вида происшествий...
                                        МОЛОДЦЫ...</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +1</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time">07:49</time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link popular-news__item-link--c-gray link">Что
                                            тревожит жителей Темирского района</span>
                                    </a>
                                    <span class="popular-news__item-text">Кажется, первый областной, который поехал по
                                        районам. Раньше все чморились по городским рынкам, пинали там снег, ловили
                                        проституток возле вокзала, рейдерновали больницы и свинофермы и пиксили
                                        телевышку. Жаль, что...</span>
                                    <p class="popular-news__author">MambetAga<span class="popular-news__author--like">
                                            +-19</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span
                                            class="popular-news__item-link popular-news__item-link--c-gray link">Письмо
                                            читателя. В Бадамше на народные деньги строят мечеть</span>
                                    </a>
                                    <span class="popular-news__item-text">И заметил одну особенность: Практически все
                                        правоверные священнослужители живут в свеже-построенных двух-этажных хоромах и
                                        ни один из них не бежит в мечеть после проведённого с...</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +-20</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span
                                            class="popular-news__item-link popular-news__item-link--c-gray link">Отцепившийся
                                            прицеп унес жизнь человека на трассе в Австрии</span>
                                    </a>
                                    <span class="popular-news__item-text">Ажал....</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +-21</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="1" daysint></span></time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span
                                            class="popular-news__item-link popular-news__item-link--c-gray link">Народный
                                            репортер. Новые фонари не горели ни дня</span>
                                    </a>
                                    <span class="popular-news__item-text">Это как ярко-горящие мощные прожекторы на
                                        центральном стадионе в солнечный день... Наши непосаженные покуда в тюрягу
                                        олигархи знают 101 способов хищения денег из бюджета и...</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +-19</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="2" daysint></span></time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span class="popular-news__item-link popular-news__item-link--c-gray link">Три
                                            мешка карасей незаконно выловил житель Хромтау</span>
                                    </a>
                                    <span class="popular-news__item-text">Язык мой – враг мой... Чистосердечное
                                        признание облегчает кошелёк наивного и семейный бюджет без
                                        свежей ухи</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +-21</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="2" daysint></span></time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span
                                            class="popular-news__item-link popular-news__item-link--c-gray link">Отцепившийся
                                            прицеп унес жизнь человека на трассе в Австрии</span>
                                    </a>
                                    <span class="popular-news__item-text">ИМАНЫ ДОС БОЛСЫН</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +-21</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="2" daysint></span></time>
                                    </div>
                                </li>
                                <li class="popular-news__item">
                                    <a href="#roulette" class="popular-news__item-link-wrap link-parent">
                                        <span
                                            class="popular-news__item-link popular-news__item-link--c-gray link">Незастрахованным
                                            казахстанцам могут запретить водить авто</span>
                                    </a>
                                    <span class="popular-news__item-text">Эта мадамиха (явно не дружащая с математикой и
                                        дробями) откровенно лоббирует кошелёк Фонда... Её бы воля: Даже дышать запретила
                                        бы незастрахованным</span>
                                    <p class="popular-news__author">Шындыкбай<span class="popular-news__author--like">
                                            +-16</span></p>
                                    <div class="popular-news__meta-row">
                                        <time class="popular-news__item-time"><span class="startdate"
                                                format="dayI monthS year" daysago="2" daysint></span></time>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-average__banner banner">
                    </div>
                    <div class="col-average__banner banner">
                    </div>
                </aside>
                <section class="container__col-big col-big">
                    <div class="col-big__publication publication">
                        <header class="publication__header">
                            <p class="publication__breadcrumbs breadcrumbs">
                                <span class="breadcrumbs__level"><a href="#roulette"
                                        class="breadcrumbs__link link">Главная</a></span>
                                <span class="breadcrumbs__delimiter"> – </span>
                                <span class="breadcrumbs__level"><a href="#roulette"
                                        class="breadcrumbs__link link">Здоровье</a></span>
                                <span class="breadcrumbs__delimiter"> – </span>
                                <span class="breadcrumbs__level"><a href="#roulette"
                                        class="breadcrumbs__link link">{{country_name_nominative}}</a></span>
                            </p>
                            <p class="publication__info">
                                <time><span class="startdate" format="dayI monthS year" daysago="5"
                                        daysint></span></time>
                                <span class="publication__info-delimiter"> • </span>4922 просмотра
                            </p>
                        </header>
                        <div class="publication__content content-block">    

                             Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni deserunt sed vel saepe recusandae harum quaerat? Soluta dolore consequuntur suscipit! Sapiente pariatur obcaecati illum voluptas ad assumenda, porro nemo dicta?
                             Nobis officia porro saepe, expedita itaque veritatis ex placeat sequi facilis ullam quisquam quod quam et nesciunt, omnis fugiat perferendis nemo enim aliquam mollitia labore cumque recusandae ut laboriosam! Vero?
                             Delectus inventore facilis maiores amet a suscipit laborum non possimus expedita corporis facere alias assumenda dicta voluptatibus dolores hic nihil nobis, distinctio repudiandae? Harum odit sapiente odio reprehenderit perspiciatis at!
                             Amet consectetur nihil distinctio provident odio. Quis animi eaque maiores voluptatem asperiores at doloremque ratione, beatae quisquam totam mollitia numquam dolore nulla, nostrum id magni voluptatibus quasi esse! Quo, deleniti!
                             Unde molestiae perferendis voluptas perspiciatis ab aspernatur odit reiciendis tenetur accusantium placeat, dolorum laboriosam animi aperiam, libero beatae, error rerum quidem itaque eaque suscipit explicabo harum soluta minima aut. Dolores?
                             Omnis quibusdam cumque odio corrupti in molestias optio molestiae id explicabo labore unde, quas sequi hic repudiandae. Amet debitis, dolorum quis quidem necessitatibus aspernatur eius itaque, enim laudantium iste quos.
                             Nam, nobis deleniti numquam nihil animi possimus doloribus optio tempora! Error delectus rerum veritatis nostrum. Vero consequatur commodi a neque optio ut ab. Eum illo enim magni hic iure natus.
                             Quod perferendis ipsum quibusdam quaerat sapiente sint iste culpa. Obcaecati, similique consequatur laboriosam ex saepe repudiandae vitae placeat sunt, debitis dolor reprehenderit laudantium explicabo totam, cumque blanditiis dolorum distinctio velit?
                             Recusandae aspernatur autem sint similique in! Voluptas unde molestias maxime necessitatibus ipsa amet enim incidunt! Enim alias facere adipisci nihil tenetur! A fugiat error dolorem sit reiciendis enim repellat? Itaque.
                             Sapiente voluptate ducimus distinctio minima et maxime. Accusantium commodi quaerat voluptatibus eaque, eum nam explicabo voluptatum labore cumque, quo repellendus expedita sit a quos tempore reiciendis, facere iure tempora quibusdam.
                             Ipsa maiores vel qui magni mollitia laudantium numquam nobis ipsam reprehenderit sunt nemo, totam optio ratione modi cumque sint eaque a soluta esse nulla unde ad molestias perferendis? Sunt, rem.
                             Molestias non commodi ad doloremque, placeat eius id accusantium unde assumenda nisi pariatur sint provident hic, blanditiis deserunt consectetur illum dicta quasi expedita, dolorem nemo. Ipsum exercitationem aut molestiae provident!
                             Cumque cupiditate accusantium aliquam id quis excepturi amet numquam nihil, corrupti porro eaque dolore unde neque nisi quaerat fuga rem recusandae a aperiam explicabo et. Ipsum fugit ex porro perspiciatis.
                             Maiores aspernatur voluptatem impedit vel maxime quibusdam praesentium in iure hic ab ducimus odio cumque inventore facere ipsam, eveniet nobis doloremque velit repellendus, repellat ex distinctio? Perspiciatis blanditiis voluptas incidunt?
                             Architecto eos, cumque debitis quas repellat provident vero dignissimos laboriosam fugiat, ullam minus at tenetur pariatur enim explicabo itaque facere tempora culpa saepe? Dolores cupiditate a dolorum accusantium architecto nemo.
                             Quam eveniet reprehenderit nulla repellat doloribus? Veritatis unde obcaecati, porro cum similique tenetur at cumque facilis, esse omnis voluptatum ut iste numquam? Obcaecati dolore repellat, molestias dolorem unde tempora dicta!
                             Repudiandae veritatis, nesciunt facere ex dolorem quae rerum delectus. Aperiam quaerat sapiente earum iste eum, sint ad laborum unde asperiores quibusdam repudiandae officiis amet laudantium praesentium porro rerum voluptatum impedit.
                             Animi rerum voluptatum at laboriosam eum perferendis consequuntur nisi numquam nesciunt maiores mollitia laborum ipsa, quae corporis error optio incidunt nulla, tempora natus ratione quaerat? Autem at dolore doloremque animi.
                             Aperiam alias corrupti soluta asperiores reprehenderit sapiente eveniet sint ducimus? Aliquam ullam dignissimos laborum quibusdam provident optio repudiandae sed, nisi accusantium minus eligendi vero officia! Ea neque odio voluptates expedita.
                             Odio laudantium impedit debitis assumenda excepturi earum nostrum, consequuntur mollitia quod non qui voluptas illum odit similique neque quam delectus laborum. Vitae dolorem sequi quae praesentium vel recusandae corporis dignissimos!
                             Beatae aut perferendis natus, debitis fuga dolore aperiam illo repellat rem nulla quia accusamus modi animi distinctio veniam vero cum accusantium corrupti ipsam a! Aliquam saepe nostrum sunt similique quos.
                             Cumque itaque minima blanditiis enim neque similique adipisci impedit aperiam laboriosam sequi facilis dolores totam vel molestias voluptatum dolorem modi doloremque possimus repellat, non a. At excepturi dignissimos voluptas quod.
                             Iste corrupti suscipit reiciendis! Corporis quis est quo quos iste reiciendis laborum, illo porro atque voluptas vero. Possimus expedita quia ad nostrum odio, velit, incidunt architecto facilis aperiam nesciunt non!
                             Quaerat minima assumenda facere neque animi voluptates a soluta saepe? Iure sequi voluptatem quis quibusdam. Itaque dolorum ipsam magni inventore cumque ea natus quidem consequuntur! Illo nemo rem accusamus harum.
                             Repellat cumque sint consectetur distinctio odit veritatis officiis omnis, maiores, ad autem eius cupiditate. Ipsum dolores dicta, quo, cumque quidem, repellat optio eaque ut veritatis asperiores velit eveniet? Porro, doloremque.
                             Nulla, ea cumque. Velit culpa saepe maxime consequatur facilis alias nulla voluptas ea! Aliquam nulla molestias debitis, reprehenderit labore aut facere, fugit ullam delectus temporibus dolorem, perspiciatis tenetur commodi voluptatibus!
                             Porro, odit. Veritatis deleniti labore quos vero ab vel ipsa cupiditate nam. Nulla dolore, ratione et officia sapiente soluta accusamus blanditiis quidem, perferendis nobis doloribus quae ex corporis perspiciatis? Cumque!
                             Cum, illo quam mollitia nemo sed obcaecati autem, maxime eos porro, optio voluptatem consectetur magnam eius adipisci harum! Nobis corporis iusto odio, ratione dolore numquam. Ratione molestias est vel odit?
                             Placeat excepturi quasi error similique, repellendus possimus dicta quam suscipit, repellat explicabo illum consectetur cupiditate minima commodi blanditiis perspiciatis eveniet nesciunt labore voluptas, tempore dolorum iure eos? Placeat, dolores rerum!
                             Voluptate a maxime eos adipisci vero aliquam veniam, tempore magni, explicabo eum rem, sit incidunt laudantium non dolore ullam excepturi! Inventore, dolores deserunt molestiae quam magnam omnis nostrum doloribus rem.

                          </div>
                        <div class="publication__tags-wrap">
                            <ul class="publication__tags">
                                <li class="publication__tag"><a rel="tag" href="#roulette"
                                        class="publication__tag-text">Гипертония</a>
                                </li>
                                <li class="publication__tag"><a rel="tag" href="#roulette"
                                        class="publication__tag-text">{{country_name_nominative}}</a>
                                </li>
                            </ul>
                        </div>
                        <footer class="publication__footer">
                            <div class="publication__share-row">
                                <span class="publication__share-row-title">Обсудить в социальных сетях:</span>
                                <div class="publication__social-likes share-links">
                                    <ul class="share-links__list">
                                        <li class="share-links__item">
                                            <a href="#roulette" class="share-links__link share-links__link--fb"
                                                target="_blank"></a>
                                        </li>
                                        <li class="share-links__item">
                                            <a href="#roulette" class="share-links__link share-links__link--tt"
                                                target="_blank"></a>
                                        </li>
                                        <li class="share-links__item">
                                            <a href="#roulette" class="share-links__link share-links__link--vk"
                                                target="_blank"></a>
                                        </li>
                                        <li class="share-links__item">
                                            <a href="#roulette" class="share-links__link share-links__link--ok"
                                                target="_blank"></a>
                                        </li>
                                        <li class="share-links__item">
                                            <a href="#roulette" class="share-links__link share-links__link--inst"
                                                target="_blank"></a>
                                        </li>
                                        <li class="share-links__item">
                                            <a href="#roulette" class="share-links__link share-links__link--tg"
                                                target="_blank"></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="publication__footer-banner"></div>
                        </footer>
                    </div>
                    
                    <div class="banner-publication-full-with" data-position="publication-full-with">
                        <div id="adfox_167480934101433486"></div>
                    </div>
                </section>
                <aside class="container__col-small col-small">
                    <div class="col-small__situation-info situation-info">
                        <a href="#roulette">
                            <form class="situation-info__search-wrap js_parent" action method="GET" novalidate
                                autocomplete="off">
                                <input type="text" class="situation-info__search js_situation_info_search" name="q"
                                    placeholder="Поиск по сайту" title="Поиск по сайту" value>
                                <button class="situation-info__search-btn js_situation_info_btn" title="Найти"></button>
                            </form>
                        </a>
                        <div class="situation-info__rows">
                            <p class="situation-info__row"><b>Вторник</b>, <span class="nowdate"
                                    format="dayI monthS year" daysint></span></p>
                        </div>
                        <div class="situation-info__rows">
                            <p class="situation-info__row"><span class="situation-info__bold">
                                    <font pl-country="at">В Австрии</font>
                                    <font pl-country="bg">В Болгарии</font>
                                    <font pl-country="hu">В Венгрии</font>
                                    <font pl-country="de">В Германии</font>
                                    <font pl-country="gr">В Греции</font>
                                    <font pl-country="es">В Испании</font>
                                    <font pl-country="it">В Италии</font>
                                    <font pl-country="cy">На Кипре</font>
                                    <font pl-country="lv">В Латвии</font>
                                    <font pl-country="lt">В Литве</font>
                                    <font pl-country="pl">В Польше</font>
                                    <font pl-country="pt">В Португалии</font>
                                    <font pl-country="ro">В Румынии</font>
                                    <font pl-country="sk">В Словакии</font>
                                    <font pl-country="fr">Во Франции</font>
                                    <font pl-country="hr">В Хорватии</font>
                                    <font pl-country="cz">В Чехии</font>
                                    <font pl-country="ee">В Эстонии</font>
                                </span> +4°,
                                переменная облачность
                            </p>
                        </div>
                        <div class="situation-info__rows">
                            <p class="situation-info__row"><span class="situation-info__bold">Курсы валют</span></p>
                            <p class="situation-info__row">$ 477.02 <span class="situation-info__delimiter">•</span> €
                                502.45 <span class="situation-info__delimiter">•</span> ₽ 4.73</p>
                        </div>
                    </div>
                    <div class="col-small__banner banner js_banner" data-position="right_column_1">
                        <a href="#roulette" class="__link" target="_blank" rel="nofollow noreferrer">
                            <img loading="lazy" src="./img/banner_76.jpeg"
                                alt="diapazon" width="197" height="270" class="__img">
                        </a>
                    </div>
                    <div class="col-small__banner banner js_banner" data-position="right_column_2">
                        <a href="#roulette" class="__link" target="_blank" rel="nofollow noreferrer">
                            <img loading="lazy" src="./img/banner_60.jpeg"
                                alt="Диапазон новости" width="197" height="270" class="__img">
                        </a>
                    </div>
                    <div class="col-small__banner banner"></div>
                    <aside class="col-small__photoreport photoreport">
                        <h2 class="photoreport__title">Фоторепортажи</h2>
                        <ul class="photoreport__list">
                            <li class="photoreport__item">
                                <a href="#roulette" class="photoreport__link link-parent">
                                    <span class="photoreport__preview-wrap">
                                        <img loading="lazy"
                                            src="./img/YaT5HEmiHU_a4_336x210.jpeg" alt
                                            class="photoreport__preview">
                                    </span>
                                    <p class="photoreport__name-wrap"
                                        title="Километры здоровья. Больше тысячи актюбинцев устроили забег">
                                        <span class="photoreport__name pink-link">Километры здоровья. Больше тысячи
                                            активистов устроили забег</span>
                                    </p>
                                </a>
                            </li>
                            <li class="photoreport__item">
                                <a href="#roulette" class="photoreport__link link-parent">
                                    <span class="photoreport__preview-wrap">
                                        <img loading="lazy"
                                            src="./img/xHoVeVJOFN_a4_336x210.jpeg" alt
                                            class="photoreport__preview">
                                    </span>
                                    <p class="photoreport__name-wrap" title>
                                        <span class="photoreport__name pink-link">Офицерский вальс станцевали {{country_name_locational}}</span>
                                    </p>
                                </a>
                            </li>
                            <li class="photoreport__item">
                                <a href="#roulette" class="photoreport__link link-parent">
                                    <span class="photoreport__preview-wrap">
                                        <img loading="lazy"
                                            src="./img/u3oqOtYrWU_a4_336x210.jpeg" alt
                                            class="photoreport__preview">
                                    </span>
                                    <p class="photoreport__name-wrap" title>
                                        <span class="photoreport__name pink-link">
                                            <font pl-country="at">В Австрии</font>
                                            <font pl-country="bg">В Болгарии</font>
                                            <font pl-country="hu">В Венгрии</font>
                                            <font pl-country="de">В Германии</font>
                                            <font pl-country="gr">В Греции</font>
                                            <font pl-country="es">В Испании</font>
                                            <font pl-country="it">В Италии</font>
                                            <font pl-country="cy">На Кипре</font>
                                            <font pl-country="lv">В Латвии</font>
                                            <font pl-country="lt">В Литве</font>
                                            <font pl-country="pl">В Польше</font>
                                            <font pl-country="pt">В Португалии</font>
                                            <font pl-country="ro">В Румынии</font>
                                            <font pl-country="sk">В Словакии</font>
                                            <font pl-country="fr">Во Франции</font>
                                            <font pl-country="hr">В Хорватии</font>
                                            <font pl-country="cz">В Чехии</font>
                                            <font pl-country="ee">В Эстонии</font> прошел
                                            фестиваль цветов
                                        </span>
                                    </p>
                                </a>
                            </li>
                        </ul>
                    </aside>
                    <div class="col-small__banner banner">
                    </div>
                </aside>
            </main>
        </div>
        <div class="notification js_notification">
            <div class="notification__text"></div>
        </div>
        <footer class="footer">
            <div class="footer__container">
                <div class="footer__top">
                    <small class="footer__copy">«Диапазон»</small>
                    <div class="footer__nav-wrap">
                        <ul class="footer__nav-list">
                            <li class="footer__nav-item"><a href="#roulette"
                                    class="footer__nav-link pink-link">Реклама</a></li>
                            <li class="footer__nav-item"><a href="#roulette"
                                    class="footer__nav-link pink-link">Редакция</a></li>
                            <li class="footer__nav-item"><a href="#roulette"
                                    class="footer__nav-link pink-link">Контакты</a></li>
                            <li class="footer__nav-item"><a href="#roulette"
                                    class="footer__nav-link pink-link">Вакансии</a></li>
                            <li class="footer__nav-item"><a href="#roulette" class="footer__nav-link pink-link">Карта
                                    сайта</a></li>
                            <li class="footer__nav-item"><a href="#roulette"
                                    class="footer__nav-link pink-link">Подписка</a></li>
                        </ul>
                    </div>
                    <p>
                        <span class="footer__support-banner">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 14 22"
                                fill="none">
                                <path
                                    d="M12.8253 9.85791L7.3802 7.12319C7.28239 7.07407 7.18457 7.13957 7.18457 7.2542V18.1276C7.18457 18.1931 7.24978 18.2423 7.31499 18.2095L9.62999 17.0468C9.7441 16.9977 9.80932 16.8831 9.80932 16.752V13.8208H9.17351C9.09199 13.8208 9.02678 13.7553 9.02678 13.6734V11.7247C9.02678 11.6429 9.09199 11.5774 9.17351 11.5774H11.1135C11.1951 11.5774 11.2603 11.6429 11.2603 11.7247V13.6734C11.2603 13.7553 11.1951 13.8208 11.1135 13.8208H10.4777V17.0632C10.4777 17.2434 10.3799 17.4071 10.2169 17.4726L7.3313 18.93C7.24978 18.9628 7.20087 19.0447 7.20087 19.1429V21.1407C7.20087 21.239 7.31499 21.3045 7.39651 21.2717L12.8416 18.537C13.0047 18.4551 13.1025 18.2914 13.1025 18.1276V10.2673C13.0699 10.1036 12.9721 9.93979 12.8253 9.85791Z"
                                    fill="white"></path>
                                <path
                                    d="M6.18967 0.40946L0.760844 3.14418C0.597816 3.22606 0.5 3.38981 0.5 3.55357V18.1115C0.5 18.2916 0.597816 18.4553 0.760844 18.5208L6.20597 21.2556C6.30379 21.3047 6.4016 21.2392 6.4016 21.1246V17.6529C6.4016 17.5711 6.35269 17.4892 6.27118 17.4401L3.36929 16.0153C3.20626 15.9335 3.10844 15.7697 3.10844 15.6059V9.07213H2.47263C2.39112 9.07213 2.32591 9.00662 2.32591 8.92475V6.97606C2.32591 6.89418 2.39112 6.82868 2.47263 6.82868H4.41266C4.49418 6.82868 4.55939 6.89418 4.55939 6.97606V8.92475C4.55939 9.00662 4.49418 9.07213 4.41266 9.07213H3.77686V15.2784C3.77686 15.4094 3.84207 15.5077 3.95619 15.5732L6.27118 16.7359C6.33639 16.7686 6.4016 16.7195 6.4016 16.654V0.540464C6.4016 0.442211 6.28748 0.360333 6.18967 0.40946Z"
                                    fill="white"></path>
                            </svg>
                            <span>Поддержка сайта Белтехсофт</span>
                        </span>
                    </p>
                </div>
                <div class="footer__counters-row">
                    <div class="footer__counter">
                        <img loading="lazy" src="./img/p.png" alt>
                    </div>
                    <div class="footer__counter">
                        <img loading="lazy" src="./img/cycounter.png" alt>
                    </div>
                    <div class="footer__counter">
                        <img loading="lazy" src="./img/z.png" alt>
                    </div>
                </div>
            </div>
            <div class="container" style="display: none;">
              <div class="block">
                <span class="rekvizits">{{landing_footer_requisites}} </span>
                <span class="rekvizits-links" style="display:block">{{landing_footer_links}}</span>   
              </div>
      </div>
        </footer>
    </div>

    <script src="./js/script.js"></script>
    <script src="./dist/bundle.js"></script>

</body>

</html>

