<!DOCTYPE html>
<html lang="ru">

<head>
    <meta name="google" content="nopagereadaloud">
    <meta http-equiv="Cache-control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-cache">

    <meta charset="utf-8">
    <title>Kardisen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="./static/dist/bundle.css">
</head>

<body>
    
    <div class="wrapper">
        <script>
            const widgetDoorsSale = '100%';
            const widgetDoorsGood = 'Kardisen';
        </script>
        <span id="roulette"></span>
        <div class="door__wrapper">
            <h2 class="door__title">Угадай за какой дверью скидка
                <script>document.write(widgetDoorsSale);</script>
            </h2>
            <div class="door__container">
                <div class="box__door" id="door1"
                    style="background-image: url('./static/images/doorway_green.png');">
                    <div class="hi">
                        <p id="door__sales1" class="door__sales "></p>
                    </div>
                    <div class="door full green__door"
                        style="background-image: url('./static/images/green_door.png');">
                    </div>
                </div>
                <div class="box__door" id="door2"
                    style="background-image: url('./static/images/yellow_doorway.png');">
                    <div class="hi">
                        <p id="door__sales2" class="door__sales "></p>
                    </div>
                    <div class="door half door__part--left yellow_ld"
                        style="background-image: url('./static/images/left_door_yellow.png');">
                    </div>
                    <div class="door half door__part--right yellow_rd"
                        style="background-image: url('./static/images/right_door_yellow.png');">
                    </div>
                </div>
                <div class="box__door" id="door3"
                    style="background-image: url('./static/images/pink_doorway.png');">
                    <div class="hi">
                        <p id="door__sales3" class="door__sales "></p>
                    </div>
                    <div class="door half door__part--left red_ld"
                        style="background-image: url('./static/images/red_door_left.png');">
                    </div>
                    <div class="door half door__part--right red_rd"
                        style="background-image: url('./static/images/red_door_right.png');">
                    </div>
                </div>
            </div>
        </div>

        <div id="promo-main-wrapper-door" class="order_block default_order-block">
            <div class="promo-doors-wrapper hidden">
                <div class="doors">
                    <div class="doors__header">УГАДАЙТЕ, ЗА КАКОЙ ДВЕРЬЮ СКИДКА&nbsp;100%</div>
                    <div class="doors__inner">
                        <div class="doors__door-wrapper">
                            <div class="doors__result">25%</div>
                            <img class="doors__door doors__door--first doors__door--open"
                                src="./static/images/doorway_green.png" alt="">
                        </div>
                        <div class="doors__door-wrapper">
                            <div class="doors__result">100%</div>
                            <img class="doors__door doors__door--second doors__door--open"
                                src="./static/images/yellow_doorway.png" alt="">
                        </div>
                        <div class="doors__door-wrapper">
                            <div class="doors__result">50%</div>
                            <img class="doors__door doors__door--third doors__door--open"
                                src="./static/images/pink_doorway.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="promo-doors-form-wrapper" style="display: block;">
                <div class="promo-doors-title">
                    Форма заявки на бесплатный «<product-name>Kardisen</product-name>»:
                </div>
                <div class="promo-doors-text">
                    Чтобы получить «<product-name>Kardisen</product-name>» бесплатно, напишите своё
                    Имя и Контактный телефон
                    в поля ниже и нажмите на кнопку «ПОЛУЧИТЬ&nbsp;БЕСПЛАТНО»
                </div>
                <form class="promo-doors" action="" method="POST" autocomplete="off">
                    <div class="promo-doors__field-wrapper">
                        <div class="promo-doors__field-label">Ф.И.О.:</div>
                        <input class="promo-doors__field" type="text" name="order[fio]"
                            placeholder="Укажите Ваше имя" autocomplete="false">
                    </div>
                    <div class="promo-doors__field-wrapper">
                        <div class="promo-doors__field-label">Ваш контактный телефон:</div>
                        <input class="promo-doors__field" type="tel" name="order[phone]"
                            placeholder="Укажите ваш телефон" autocomplete="false">
                    </div>
                    <button class="promo-doors__btn" type="submit"
                        onclick="$(this).closest('form').submit();return false;">
                        ПОЛУЧИТЬ БЕСПЛАТНО
                    </button>
                    <div class="promo-doors-disclaimer">
                        ОФОРМЛЯЯ ЗАКАЗ, ВЫ АВТОМАТИЧЕСКИ СОГЛАШАЕТЕСЬ С
                        ПОЛИТИКОЙ КОНФИДЕНЦИАЛЬНОСТИ И ПОЛЬЗОВАТЕЛЬСКИМ СОГЛАШЕНИЕМ
                    </div>
                </form>
            </div>

            <div class="promo-confirm-popup-doors">
                <div class="promo-confirm-popup-doors__window">
                    <div class="promo-confirm-popup-doors__close-popup"></div>
                    <div class="promo-confirm-popup-doors__text">Вы можете забрать средство <div
                            class="promo-confirm-popup-doors__free-word">абсолютно бесплатно!</div>
                    </div>
                    <a class="promo-confirm-popup-doors__button replace_ignoring"
                        href="#roulette">OK</a>
                </div>
            </div>
        </div>

        <div class="spin-result-wrapper default_spin-result-wrapper" style="display: none;">
            <div class="pop-up-window">
                <div class="close-popup"></div>
                <p class="ruletka-p pop-up-text">Вы можете забрать
                    <script>document.write(widgetDoorsGood);</script>
                    <br>
                    <span class="danger-text"> со скидкой
                        <script>document.write(widgetDoorsSale);</script>.
                    </span>
                </p>
                <a class="pop-up-button" href="#roulette">OK</a>
            </div>
        </div>
    </div>

    <script src="./static/js/door_new.min.js"></script>
</body>

</html>