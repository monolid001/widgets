
<!DOCTYPE html>
<html lang="de" dir="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>New boxes</title>

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>

<body>

<!-- START_BOXES -->
<link rel="stylesheet" href="./static/css/style.css">
<div id="roulette"></div>
<div id="promo-main-wrapper-boxes">
    <div class="promo-boxes">
        <div class="promo-boxes__header">
            <div>↓</div>
            <div class="promo-boxes__header-text">Откройте коробку со скидкой до&nbsp;100%!</div>
            <div>↓</div>
        </div>
        <div class="promo-boxes__inner">
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/green_red_box/green_red_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/green_red_box/green_red_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/green_red_box/green_red_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/sand_box/sand_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/sand_box/sand_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/sand_box/sand_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/blue_oval_box/blue_oval_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/blue_oval_box/blue_oval_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/blue_oval_box/blue_oval_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/red_yellow_box/red_yellow_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/red_yellow_box/red_yellow_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/red_yellow_box/red_yellow_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/navy_blue_box/navy_blue_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/navy_blue_box/navy_blue_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/navy_blue_box/navy_blue_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/yellow_box/yellow_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/yellow_box/yellow_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/yellow_box/yellow_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/blue_box/blue_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/blue_box/blue_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/blue_box/blue_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/green_yellow_box/green_yellow_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/green_yellow_box/green_yellow_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/green_yellow_box/green_yellow_box_100.png" alt="">
            </div>
            <div class="promo-boxes__item">
                <img class="promo-boxes__box-image promo-boxes__box-image--closed" src="./static/image/red_box/red_box_closed.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--opened promo-box-image-hidden" src="./static/image/red_box/red_box_none.png" alt="">
                <img class="promo-boxes__box-image promo-boxes__box-image--free promo-box-image-hidden" src="./static/image/red_box/red_box_100.png" alt="">
            </div>
        </div>
    </div>
    <div class="promo-boxes-wrapper" style="display: none;">
        <div class="promo-boxes-title">
            Форма заявки на бесплатный «<product-name></product-name>»:
        </div>
        <div class="promo-boxes-text">
            Чтобы получить «<product-name></product-name>» бесплатно, напишите своё Имя и Контактный телефон
            в поля ниже и нажмите на кнопку «ПОЛУЧИТЬ БЕСПЛАТНО»
        </div>

        <form class="promo-boxes" action="" method="POST">
            <div class="promo-boxes__field-wrapper">
                <div class="promo-boxes__field-label">Ф.И.О.:</div>
                <input
                        class="promo-boxes__field"
                        type="text"
                        name="order[fio]"
                        placeholder="Укажите Ваше имя"
                >
            </div>
            <div class="promo-boxes__field-wrapper">
                <div class="promo-boxes__field-label">Ваш контактный телефон:</div>
                <input
                        class="promo-boxes__field"
                        type="tel"
                        name="order[phone]"
                        placeholder="Укажите ваш телефон"
                >
            </div>
            <button
                    class="promo-boxes__btn"
                    type="submit"
                    onclick="$(this).closest('form').submit();return false;"
            >
                ПОЛУЧИТЬ БЕСПЛАТНО
            </button>
            <div class="promo-boxes-disclaimer">
                ОФОРМЛЯЯ ЗАКАЗ, ВЫ АВТОМАТИЧЕСКИ СОГЛАШАЕТЕСЬ С
                ПОЛИТИКОЙ КОНФИДЕНЦИАЛЬНОСТИ И ПОЛЬЗОВАТЕЛЬСКИМ СОГЛАШЕНИЕМ
            </div>
            <input type="hidden" name="order[specifications]" value="">
            <input type="hidden" name="order[discount]" value="">
        </form>
    </div>
    <div class="promo-boxes-wrapper" style="display: none;">
    </div>
    <div class="promo-confirm-popup-boxes">
        <div class="promo-confirm-popup-boxes__window">
            <div class="promo-confirm-popup-boxes__close-popup"></div>
            <div class="promo-confirm-popup-boxes__text">Вы можете забрать средство <div class="promo-confirm-popup-boxes__free-word">абсолютно бесплатно!</div></div>
            <a class="promo-confirm-popup-boxes__button" href="#roulette">OK</a>
        </div>
    </div>
</div>
<script src="./static/js/script.js"></script>
<!-- END_BOXES -->
    
</body>
</html>