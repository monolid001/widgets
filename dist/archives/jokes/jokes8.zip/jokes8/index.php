<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimal-ui">
      <title>Roulette form</title>
      <link rel="stylesheet" href="./static/dist/bundle.css">
      <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
   </head>
   <body>
      <div class="wrapper">
         <!--{{start_form}}-->
         <div class="middle" id="roulette">
            <div class="spin-wrapper order-block-container" id="spin-wrapper">
               <p class="roul-text" style="margin-top:0; text-align: center;">
                  Как только вы нажмете кнопку "НАЖАТЬ", <b>Cardirin</b> будет
                  зарезервирован для вас.
               </p>
               <div class="wheel-wrapper">
                  <div class="wheel">
                     <img loading="lazy" alt="img" class="wheel-img"
                        src="./static/images/prizewheel-NY.png">
                     <div class="wheel-cursor">
                        <img loading="lazy" alt="img"
                           src="./static/images/wheel-cursor.png"
                           style="margin: 0 0 !important;">
                        <span class="cursor-text lt48 spining">ВРАЩАТЬ</span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="order_block">
               <form action="" id="order_form" class="order_form" method="post"
                  name="order_form">
                  <div id="order_form_place" style="display:block;">
                     <div style="text-align: center;">
                     </div>
                     <div style="text-align: center;margin:20px 0;">
                        <span style="font-size:16px;">
                        Приобретение Cardirin по специальной цене <b
                           style="color:green;font-size:larger;"><span><span
                           class="pl_special_price"
                           separated>39</span> EUR</span></b>
                        </span>
                     </div>
                     <div
                        style="font-size: 16px !important;
                           font-weight: bold !important;
                           color: #333 !important;
                           text-align: center !important;
                           margin: 0px auto 16px !important;
                           line-height: 1.3;">
                        <span>
                        <b>Чтобы получить ваш Cardirin со скидкой, пожалуйста, введите
                        ваше имя и номер телефона в поля ниже и нажмите кнопку&nbsp;"ЗАКАЗАТЬ".
                        </b>
                        </span>
                     </div>
                     <div class="order_form_pole">
                        <label>Телефон:</label>
                        <input name="order[fio]" type="text" value
                           placeholder="Ваше имя">
                     </div>
                     <div class="order_form_pole">
                        <label>Ваше имя:</label>
                        <input name="order[phone]" type="tel" value required
                           placeholder="Ваш телефон">
                     </div>
                     <div class="but" style="margin-bottom:20px;">
                        <button name="send_order" type="submit"
                           onclick="$(this).closest('form').submit();return false;">ЗАКАЗАТЬ</button>
                     </div>
                     <span class="center"><b>*Конфиденциально.</b> Ваши данные отправляются напрямую производителю. Никто, кроме него, не имеет к ним доступ.</span>
                  </div>

               </form>
            </div>
            <div class="spin-result-wrapper">
               <div class="pop-up-window">
                  <div class="close-popup"></div>
                  <span class="pop-up-heading">Поздравляем!</span>
                  <p class="ruletka-p pop-up-text" style="font-size:22px;font-weight:500;margin-top:5px;">Вы выиграли
                     <span style="color:red;">75%</span> скидку и можете получить
                     <b>Cardirin</b> по цене <span style="color:red;"><span
                        class="pl_special_price"
                        separated>39</span>&nbsp;EUR</span>!
                  </p>
                  <button class="pop-up-button" data-toggle=scroll
                     href="#roulette">OK</button>
               </div>
            </div>
         </div>
         
      </div>
      <script src="./static/dist/bundle.js"></script>
   </body>
</html>