<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./static/dist/bundle.css">
    <title>Slot machine</title>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script>
        var filePath = './static/'
    </script>
  </head>
  <body>
  
    <div id="roulette"></div>
    <div class="slot-wrapper">
      <div class="slot-top">
      <img src="./static/assets/text.png" alt="" />
      </div>
      <div class="slot-main">
        <div class="slot-spin">
          <div class="slot-row">
            <div class="slot-column" id="column1">
              <img class="slot" id="slot1" />
            </div>
            <div class="slot-column" id="column2">
              <img class="slot" id="slot2" />
            </div>
            <div class="slot-column" id="column3">
              <img class="slot" id="slot3" />
            </div>
          </div>
        </div>
      </div>
      <div class="slot-bottom">
        <div class="slot-btn" id="spinButton">
          <img src="./static/assets/button.png" alt="" />
          <span class="slot-btn-glitter"></span>
        </div>
      </div>
    </div>
    <div class="order_block">
        <div><img src="./static/assets/star.png" style="width: 100% !important; max-width: 220px !important;"></div>
        <h3>Все что Вам нужно — это ввести имя и номер телефона.<br>Поторопитесь! У Вас осталось времени:<br><span
                    class="time_remains" id="min">10</span> : <span class="time_remains" id="sec">00</span></h3>
        <form id="order_form" action="" method="POST">
            <input type="text" class="input-roulette" name="order[fio]" id="input-name" placeholder="Введите ваше имя"
                   autocomplete="name">
            <input type="tel" class="input-roulette" name="order[phone]" data-mask-phone="de" id="input-phone" placeholder="Введите номер"
                   autocomplete="tel">
            <button type="submit" style=" background: #e62e2e; font-size: 20px;" class="submit-roulette">Получить 999!
            </button>
            <input type="hidden" name="order[specifications]" value="" />
            <input type="hidden" name="order[discount]" value="">
        </form>
    </div>
    <div class="spin-result-wrapper">
        <div class="pop-up-window">
            <div class="close-popup"></div>
            <p class="ruletka-p pop-up-text">Вы можете получить TEST<span class="danger-text">999!</span></p>
            <a class="pop-up-button" href="#roulette">OK</a>
        </div>
    </div>
    

    <script src="./static/dist/bundle.js"></script>

  </body>
</html>
