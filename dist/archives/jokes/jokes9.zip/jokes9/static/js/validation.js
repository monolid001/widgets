const paramsURL = new URLSearchParams(document.location.search);
const $forms = document.querySelectorAll("form");

if ($forms) {
  $forms.forEach(($form) => {
    const $inputPhone = $form.querySelector('[name="order[phone]"]');
    if ($inputPhone) {
      const country = $inputPhone.getAttribute("data-mask-phone")
        ? $inputPhone.getAttribute("data-mask-phone")
        : paramsURL.get("country");
      if (country) {
        let maskPhone;
        let phonePattern;
        switch (country) {
          case "de":
            maskPhone = [
              { mask: "+{49}000-000" },
              { mask: "+{49}(000)00-00" },
              { mask: "+{49}(000)00-000" },
              { mask: "+{49}(000)000-0000" },
              { mask: "+{49}(0000)000-0000" },
            ];
            phonePattern = /^(?:\+49|0049)\(\d{1,}\)\d{1,}-\d{1,}$/;
            break;
          case "mx":
            maskPhone = [
              { mask: "+{52}00-000-0000" },
              { mask: "+{52}(000)000-0000" },
            ];
            phonePattern = /^\+52\(\d{1,}\)\d{1,}-\d{1,}$/;
            break;
          default:
            maskPhone = "+{38\\0}00-00-00-000";
            phonePattern = /^\+\d{3}\d{1,}-\d{1,}-\d{1,}-\d{1,}$/;
            break;
        }
        const maskOptions = { mask: maskPhone, lazy: false,  placeholderChar: '#' };

        IMask($inputPhone, maskOptions);

        $inputPhone.addEventListener("input", function (event) {
            if (!$inputPhone.value.match(phonePattern)) {
              $inputPhone.setCustomValidity(`Pattern: ${phonePattern}`);
            } else {
              $inputPhone.setCustomValidity('');
            }
          });

        $form.addEventListener("submit", function (event) {
          if (!$inputPhone.value.match(phonePattern)) {
            event.preventDefault();
            $inputPhone.setCustomValidity(`Pattern: ${phonePattern}`);
          } else {
            $inputPhone.setCustomValidity('');
          }
        });
      } else {
        alert("You forgot to enter the country!");
      }
    }
  });
}
