import "../css/main.scss";
//------------------------

$(document).ready(function () {
  var spinning = false;
  var finalResult = [
    `${filePath}assets/seven.png`,
    `${filePath}assets/seven.png`,
    `${filePath}assets/seven.png`,
  ];
  const images = [
    `${filePath}assets/seven.png`,
    `${filePath}assets/diamond.png`,
    `${filePath}assets/cherry.png`,
    `${filePath}assets/coin.png`,
  ];
  var globalTop = $("#column1").offset().top;

  var resultWrapper = document.querySelector(".spin-result-wrapper");
  var preresultWrapper = document.querySelector(".spin-preresult-wrapper");
  var time = 600;
  var intr;
  var spinCount = 0;

  function getRandomChar() {
    return images[Math.floor(Math.random() * images.length)];
  }

  function initValues() {
    var items = $(".slot");

    items.each((index, item) => {
      $(item).attr("src", getRandomChar());
    });
  }

  async function spinColumn() {
    spinCount++;
    var spinTime = 5000;
    var startTime = new Date().getTime();
    var timeoutTime = 1;
    var slotSpins = [false, false, false];
    var i = 0;

    var items = $(".slot");

    while (new Date().getTime() - startTime < spinTime) {
      await new Promise((r) => setTimeout(r, timeoutTime));
      items.each((index, item) => {
        i++;
        if (i > index * 50) {
          slotSpins[index] = true;
        }
        if (!slotSpins[index]) {
          return;
        }
        var itemTop = Math.round($(item).offset().top - globalTop) + 4;
        if (itemTop > 60) {
          itemTop = -60;
          $(item).attr("src", getRandomChar());
        }
        $(item).css("top", itemTop);
      });
      if (timeoutTime < 10) {
        timeoutTime += 0.01;
      }
    }

    while (slotSpins[0] || slotSpins[1] || slotSpins[2]) {
      await new Promise((r) => setTimeout(r, timeoutTime));
      items.each((index, item) => {
        if (!slotSpins[index]) {
          return;
        }
        var itemTop = Math.round($(item).offset().top - globalTop) + 3;
        if (itemTop > 60) {
          itemTop = -60;
          if (spinCount > 2) {
            $(item).attr("src", finalResult[index]);
          } else {
            $(item).attr("src", getRandomChar());
          }
        }
        $(item).css("top", itemTop);
        if (
          ($(item).attr("src") == finalResult[index] || spinCount < 3) &&
          Math.abs(itemTop) < 2
        ) {
          slotSpins[index] = false;
        }
      });

      if (timeoutTime < 10) {
        timeoutTime += 0.01;
      }
    }

    spinning = false;

    if (spinCount > 2) {
      resultWrapper.style.display = "block";
    } else {
      preresultWrapper.style.display = "block";
      $('#count').html(3 - spinCount)
    }
  }

  $("#spinButton").on("click", function () {
    if (!spinning) {
      $(this).addClass("active");
      setTimeout(() => {
        $(this).removeClass("active");
      }, 300);
      spinning = true;
      spinAllColumns();
    }
  });

  function spinAllColumns() {
    spinColumn();
  }

  initValues();

  $("#preresult-close").click(function (e) {
    e.preventDefault();
    $(".spin-preresult-wrapper").fadeOut();

    let el = $("#roulette");
    if (!el) {
      el = $("#order_form");
    }

    let top = el.offset().top;
    $("body,html").animate({ scrollTop: top }, 800);
  });

  $(".close-popup, #result-close").click(function (e) {
    e.preventDefault();
    $(".spin-result-wrapper").fadeOut();

    setTimeout(async function () {
      $(".slot-wrapper").slideUp();
      await new Promise((r) => setTimeout(r, 500));
      $(".order_block").slideDown();
      start_timer();
    }, 1000);

    let el = $("#roulette");
    if (!el) {
      el = $("#order_form");
    }
    let top = el.offset().top;
    $("body,html").animate({ scrollTop: top }, 800);
  });

  function start_timer() {
    intr = setInterval(tick, 1000);
  }

  function tick() {
    time = time - 1;
    var mins = Math.floor(time / 60);
    var secs = time - mins * 60;
    if (mins == 0 && secs == 0) {
      clearInterval(intr);
    }
    secs = secs >= 10 ? secs : "0" + secs;
    $("#min").html("0" + mins);
    $("#sec").html(secs);
  }
});
