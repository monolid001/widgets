import '../css/main.scss';
//------------------------

$(document).ready(function() {
    setTimeout(function() {
        $('.ffl').addClass('ffl__anim')
    }, 300)
  })
  
  $(window).on('load resize', function() {
    let fflHeight = $('.ffl').outerHeight();
    if ($(window).width() < 469 && !$('.ffl').hasClass('ffl__out')) {
        $('html').css('padding-bottom', fflHeight + 'px')
    } else {
        $('html').css('padding-bottom', '0')
    }
  })
  
  $('.ffl__close, .ffl__btn').on('click', function(){
    $('.ffl').addClass('ffl__out')
    $('html').css('padding-bottom', '0')
  })
  
  jQuery( document ).ready(function() {
  $('.ffl__close, .ffl__btn').on('click', function(){
      $('.ffl').addClass('ffl__out')
      $('html').css('padding-bottom', '0')
  })
  }); 
  
  $(function () {
    $(document).on('mouseenter', 'a', function(){
      if(!$(this).hasClass('replace_ignoring')) {
        $(this).addClass('replace_ignoring');
        $(this).attr('href', '#roulette');
        $(this).removeAttr('target');
      }
    });
  });

        function getElementY(query) {
            return window.pageYOffset + document.querySelector(query).getBoundingClientRect().top;
        }

        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();

                const targetID = this.getAttribute('href');
                const target_Y = getElementY(targetID);

                let scroll = (targetY) => {
                    window.scrollTo({
                        top: targetY,
                        behavior: 'smooth'
                    })
                    setTimeout(()=> {
                        const targetY_again = getElementY(targetID);
                        if(targetY !== targetY_again) {
                            scroll(targetY_again)
                        }
                    },700)
                }

                scroll(target_Y)
            });
        });