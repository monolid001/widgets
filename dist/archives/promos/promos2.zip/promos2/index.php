<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <title>Mizoxin бесплатно! Отзывы! Получите прямо сейчас!</title>
  <meta content="Il dottore parla di pulire il sangue dal colesterolo" name="description">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link rel="stylesheet" href="./static/dist/bundle.css">

<link rel="shortcut icon" type="image/png" href="./static/img/favicon16.png" />
<link rel="shortcut icon" type="image/png" href="./static/img/favicon32.png" />
<link rel="shortcut icon" type="image/png" href="./static/img/favicon96.png" />

<script src="https://code.jquery.com/jquery-3.7.1.js" ></script>
</head>
<body class="body">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 header">
                <div class="row header-title">
                    <img src="./static/img/1/logo1.png" class="logo-hair" style="width:20px" />
                    <h1><strong><span style="color:#f81212">MIZOXIN –</span> средство против <br>облысения и для роста волос</strong></h1>
                </div>
                <div class="row header-block">
                    <!-- <div class=""> -->
                    <div class="col-md-3 offset-md-2 order-form-main">
                        <span class="free-label">БЕСПЛАТНО <span class="star">*</span></span>
                        <span class="last-day-label">Последний день</span>
                        <span class="nowdate-label"><span class="nowdate" format="dayI monthS year" daysint></span></span>
                        <form action="" method="post" class="">
                            <input type="text" required="" name="order[fio]" placeholder="Ричард Артурович">
                            <input type="tel" required="" name="order[phone]" placeholder="+49 100 00 00 00">
                            <button type="submit" class="btn" onclick="$(this).closest('form').submit();return false;">Получить</button>
                            <p class="after_order">*при оформлении заказа</p>
                        </form>
                    </div>
                    <div class="col-md-2 header-list">
                        <ul class="list-unstyled">
                            <li>Останавливает выпадение волос</li>
                            <li>Предотвращает облысение</li>
                            <li>Ускоряет рост<br> волос</li>
                        </ul>
                    </div>
                    <!-- </div> -->
                </div>
                <img src="./static/img/1/man_1.png" class="header-man" />
                <img src="./static/img/1/order1.png" class="header-order" />
            </div>
        </div>

        <div class="row mobile-row">
                <div class="row header-block">
                    <!-- <div class=""> -->
                    <div class="col-md-3 offset-md-2 order-form-main">
                        <span class="free-label">БЕСПЛАТНО <span class="star">*</span></span>
                        <span class="last-day-label">Последний день</span>
                        <span class="nowdate-label"><span class="nowdate" format="dayI monthS year" daysint></span></span>
                        <form action="" method="post" class="">
                            <input type="text" required="" name="order[fio]" placeholder="Ричард Артурович">
                            <input type="tel" required="" name="order[phone]" placeholder="+49 100 00 00 00">
                            <button type="submit" class="btn" onclick="$(this).closest('form').submit();return false;">Получить</button>
                            <p class="after_order">*при оформлении заказа</p>
                        </form>
                    </div>
                    <div class="col-md-2 header-list">
                        <ul class="list-unstyled">
                            <li>Останавливает выпадение волос</li>
                            <li>Предотвращает облысение</li>
                            <li>Ускоряет рост<br> волос</li>
                        </ul>
                    </div>
                    <!-- </div> -->
                </div>
        </div>

        <div class="row tablet-row">
            <img src="./static/img/1/order1.png" class="header-order-tablet" />
        </div>

        <div class="row brand-row">
            <span class="col-md-2 offset-md-2"><strong>Нас рекомендуют:</strong></span>
            <div class="col-md-8 brand-list">
                <ul class="list-unstyled list-inline">
                    <li><img src="./static/img/1/1_GQ.png" /></li>
                    <li><img src="./static/img/1/2_mansHea.png" /></li>
                    <li><img src="./static/img/1/3_Esq.png" /></li>
                    <li><img src="./static/img/1/4_elle.png" /></li>
                </ul>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 reason-section">
                <div class="row">
                    <h2 class="col-md-12 reason-title">Причины выпадения волос у мужчин</h2>
                    <img src="./static/img/2/Red_zagolovok.png" class="red-line" />
                </div>
                <div class="row">
                    <div class="reason-list">
                        <ul class="list-unstyled">
                            <li><img src="./static/img/2/problem_nasledstvo.png" />Наследственность</li>
                            <li><img src="./static/img/2/problem_stress.png" />Стресс</li>
                            <li><img src="./static/img/2/problem_ves.png" />Гормональный дисбаланс</li>
                            <li><img src="./static/img/2/problem_volosy.png" />Блокировка волосяных фоликул</li>
                        </ul>
                    </div>
                    <div class="reason-img">
                        <img src="./static/img/2/problem_big.jpg" />
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 persent-section">
                <div>
                    <span class="persent-80">80%</span>
                </div>
                <div>
                    <span class="persent-span">европейских мужчин страдают андрогенетической алопецией уже после 35 лет<br>
                    <span class="persent-span-note" style="font-size:20px">*исследования Берлинского университета Charite</span>
                    </span>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 nomask-section">
                <div>
                    <span class="nomask-span">
                        <h4>ЧАСТИЧНАЯ АЛОПЕЦИЯ</h4>
                        Выпадение волос может привести к
                        частичной алопеции (алопеция Ареата). Это заболевание, 
                        при котором иммунная система организма ошибочно идентифицирует 
                        волосяные фолликулы как чужеродную угрозу и атакует их. Заболевание возникает внезапно – буквально за ночь 
                        волосы выпадают и на голове появляются круглые небольшие залысины.
                    </span>
                </div>
                <div class="nomask-img">
                    <img src="./static/img/3/problem3.jpg" />
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 todo-section">
                <div class="">
                    <h2 class="col-md-12 todo-title">Что делает Mizoxin</h2>
                    <img src="./static/img/2/Red_zagolovok.png" class="red-line" />
                </div>
                <div class=" todo-section-1block">
                    <div class="todo-img">
                        <img src="./static/img/4/problem4.gif" />
                    </div>
                    <div class="todo-list">
                        <ul class="list-unstyled">
                            <li><span>Останавливает чрезмерное выпадение волос</span></li>
                            <li><span>Устраняет причину выпадения, а не маскирует проблему</span></li>
                            <li><span>Оздоравливает и увлажняет кожу головы</span></li>
                            <li><span>Улучшает кровоснабжение волосяных фолликул</span></li>
                            <li><span>Стимулирует рост волос</span></li>
                            <li><span>Увеличивает плотность и толщину каждого волоса</span></li>
                        </ul>
                    </div>
                </div>

                <ul class="icons list-unstyled">
                    <li><img src="./static/img/4/i1.png" /></li>
                    <li><img src="./static/img/4/i2.png" /></li>
                    <li><img src="./static/img/4/i3.png" /></li>
                </ul>

                <div class="">
                    <h2 class="col-md-12 sostav-title">Только натуральный состав</h2>
                    <img src="./static/img/2/Red_zagolovok.png" class="red-line" />
                </div>
                <div class="row todo-section-2block">
                    <div class="todo-list-ing">
                        <ul class="list-unstyled">
                            <li><img src="./static/img/4/ing_1.png" /><span><strong>Экстракт виноградных косточек</strong> – стимулирует рост волос за счет питания у корней и повышения тонуса эпидермиса. Мощный природный антиоксидант, регулирует работу сальных желез, улучшает кровообращение, восстанавливает здоровье кожи головы.</span></li>
                            <li><img src="./static/img/4/ing_2.png" /><span><strong>Эфирное масло Розмарина</strong> – увеличивает приток крови к волосяным фолликулам и способствует их активации, улучшает состояние волос и восстанавливает поврежденные участки.</span></li>
                            <li><img src="./static/img/4/ing_3.png" /><span><strong>Аргановое масло</strong> – ускоряет регенерацию поврежденных клеток и стимулирует рост волос, сокращает их выпадение, устраняет шелушение кожи головы.</span></li>
                            <li><img src="./static/img/4/ing_4.png" /><span><strong>Экстракт лопуха</strong> – регулирует выделение кожного себума, обеззараживает и увлажняет кожу головы, насыщает ее полезными элементами, устраняет перхоть. </span></li>
                        </ul>
                    </div>
                    <div class="todo-img-ing">
                        <img src="./static/img/4/order_all_for4.png" class="img-prod1" />
                        <img src="./static/img/1/order1.png" class="img-prod2" />
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 stat-section">
                <div class="row">
                    <h2 class="col-md-12 stat-title">Mizoxin в цифрах – почему нам можно доверять</h2>
                    <span class="stat-section-note">О средстве Mizoxin можно много писать, но цифры не могут солгать!</span>
                </div>
                <div class="row stat-list">
                    <ul class="list-unstyled">
                        <li><img src="./static/img/5/1.png" width="58px"/><span>4 натуральных ингридиента</span></li>
                        <li><img src="./static/img/5/2.png" width="55px" /><span>5 лет клинических испытаний</span></li>
                        <li><img src="./static/img/5/3.png" width="46px" /><span>1000+ довольных клиентов</span></li>
                        <li><img src="./static/img/5/4.png" width="64px" /><span>100% эффективность</span></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row fake-section-full">
            <img src="./static/img/2/Red_zagolovok.png" class="red-line" style="margin-top:50px" />
            <div class="col-md-12 fake-section">
                <div class="fake-text">
                    <h4 style="color:red;font-family: 'Circe Bold';">ОСТЕРЕГАЙТЕСЬ ПОДДЕЛОК!</h4>
                    <span><span style="font-weight:600">MIZOXIN</span> прошел все необходимые клинические испытания и соответствует европейским стандартам качества.
                        Если вы хотите избежать подделок и получить гарантированный результат – покупайте оригинальный продукт на этом сайте.<br></br>
                        <span style="font-family: 'Circe Bold';text-transform:uppercase;">100% качество гарантировано производителем.</span>
                    </span>
                </div>
                <div class="fake-img">
                    <img src="./static/img/5/order5.png" class="fake-prod" />
                    <img src="./static/img/5/sert.png" class="fake-sert" />
                </div>
                <div class="order-form">
                        <span class="free-label">БЕСПЛАТНО <span class="star">*</span></span>
                        <span class="last-day-label">Последний день</span>
                        <span class="nowdate-label"><span class="nowdate" format="dayI monthS year" daysint></span></span>
                        <form action="" method="post" class="">
                            <input type="text" required="" name="order[fio]" placeholder="Ричард Артурович">
                            <input type="tel" required="" name="order[phone]" placeholder="+49 100 00 00 00">
                            <button type="submit" class="btn" onclick="$(this).closest('form').submit();return false;">Получить</button>
                            <p class="after_order">*при оформлении заказа</p>
                        </form>
                </div>
            </div>
            <img src="./static/img/2/Red_zagolovok.png" class="red-line" style="margin-bottom:50px" />
        </div>

        <div class="row">
            <div class="col-md-12 doctor-section">
                <div class="row" style="width: 100%;">
                    <h2 class="col-md-12 doctor-title">Что о нас говорят специалисты?</h2>
                </div>
                <div class="row" style="width: 100%;margin-left: auto;margin-right: auto;">
                    <div class="doctor-box">
                        <div style="display:flex;flex-direction:column;align-items:center">
                            <img src="./static/img/6/doctor.jpg"/>
                            <img src="./static/img/6/1.png" class="signature" />
                            <span>
                                <p style="font-size:22px;text-align:left">Леонард Гросман</p>
                                <p style="font-size:18px;text-align:left"><i>Ведущий трихолог Германии, член Европейского общества исследования волос (EHRS) и Международной ассоциации трихологов (IAT)</i><p>
                            </span>
                        </div>
                        <span class="doc-desc">Выпадение и истончение волос является очень распространенной проблемой. Особенно страдают мужчины старше 30 лет. Как правило, облысение – это результат взаимодействия различных факторов, включая генетическую предрасположенность, гормональные изменения, старение и внешние воздействия. Часто проблема усугубляется тем, что ранние симптомы не замечают или попросту игнорируют, что приводит к длительному и обширному облысению. Выпадение волос – не только физиологическая проблема. Она может спровоцировать снижение самооценки, потерю уверенности в себе, проблемы в личном и профессиональном общении.  
                        К счастью, сегодня есть методы, позволяющие восстановить и укрепить волосы и сохранить их в наилучшем состоянии. Один из таких методов – спрей MIZOXIN. Это абсолютно натуральное, очень простое и удобное в использовании средство, давно доказавшее свою эффективность в борьбе с облысением.
                            
                            </span>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 feedback-section">
                <div class="row" style="width: 100%;">
                    <h2 class="col-md-12 feedback-title">Наши отзывы</h2>
                    <img src="./static/img/2/Red_zagolovok.png" class="red-line" />
                </div>
                <div class="row">
                    <div class="glide">
                        <div class="glide__track" data-glide-el="track">
                            <ul class="glide__slides">
                                <li class="glide__slide"><img src="./static/img/6/otz2.jpg" width="300px" /><br><br><span>Mizoxin – это находка! Я начал лысеть два года назад, и перепробовал кучу средств, которые совершенно не помогали. Но благодаря спрею Mizoxin я наконец смог избавиться от залысин, мои волосы обрели густоту и здоровый вид, а самое главное – я опять чувствую себя уверенно!</span></li>
                                <li class="glide__slide"><img src="./static/img/6/otz1.jpg" width="300px" /><br><br><span>Даже не ожидал, что результат будет таким быстрым и явным. Mizoxin – это действительно эффективное решение для тех, кто хочет вернуть густые волосы.</span></li>
                                <li class="glide__slide"><img src="./static/img/6/otz3.jpg" width="300px" /><br><br><span>Мизоксин – это мое спасение!  Я уже так отчаялся, что подумывал о пересадке. Но благодаря Мизоксину моя проблема облысения уходит в прошлое, я с каждым днем вижу, как волосы становятся крепче и гуще.</span></li>
                            </ul>
                        </div>
                        <div class="glide__arrows" data-glide-el="controls">
                            <button class="glide__arrow glide__arrow--left" data-glide-dir="<"><<<</button>
                            <button class="glide__arrow glide__arrow--right" data-glide-dir=">">>>></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 order-section">
                <div class="row" style="width: 100%;">
                    <h2 class="col-md-12 order-title">Как получить</h2>
                    <img src="./static/img/2/Red_zagolovok.png" class="red-line" />
                </div>
                <div class="row">
                    <div class="order-list">
                        <ul class="list-unstyled">
                            <li>
                                <img src="./static/img/7/zapis.png" />
                                <span>Подайте заявку на этой странице, заполнив форму</span>
                            </li>
                            <li>
                                <img src="./static/img/7/oformlenie.png" />
                                <span>Наш специалист перезвонит вам и оформит заказ</span>
                            </li>
                            <li>
                                <img src="./static/img/7/polych.png" />
                                <span>Получите средство удобным для вас способом</span>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
        <div class="col-md-12 header">
                <div class="row header-title">
                    <img src="./static/img/1/logo1.png" class="logo-hair" style="width:20px" />
                    <h1><strong><span style="color:#f81212">MIZOXIN –</span> средство против <br>облысения и для роста волос</strong></h1>
                </div>
                <div class="row header-block">
                    <!-- <div class=""> -->
                    <div class="col-md-3 offset-md-2 order-form-main">
                        <span class="free-label">БЕСПЛАТНО <span class="star">*</span></span>
                        <span class="last-day-label">Последний день</span>
                        <span class="nowdate-label"><span class="nowdate" format="dayI monthS year" daysint></span></span>
                        <form action="" method="post" class="">
                            <input type="text" required="" name="order[fio]" placeholder="Ричард Артурович">
                            <input type="tel" required="" name="order[phone]" placeholder="+49 100 00 00 00">
                            <button type="submit" class="btn" onclick="$(this).closest('form').submit();return false;">Получить</button>
                            <p class="after_order">*при оформлении заказа</p>
                        </form>
                    </div>
                    <div class="col-md-2 header-list">
                        <ul class="list-unstyled">
                            <li>Останавливает выпадение волос</li>
                            <li>Предотвращает облысение</li>
                            <li>Ускоряет рост<br> волос</li>
                        </ul>
                    </div>
                    <!-- </div> -->
                </div>
                <img src="./static/img/1/man_1.png" class="header-man" />
                <img src="./static/img/1/order1.png" class="header-order" />
            </div>
        </div>

        <div class="row mobile-row">
                <div class="row header-block">
                    <!-- <div class=""> -->
                    <div class="col-md-3 offset-md-2 order-form-main">
                        <span class="free-label">БЕСПЛАТНО <span class="star">*</span></span>
                        <span class="last-day-label">Последний день</span>
                        <span class="nowdate-label"><span class="nowdate" format="dayI monthS year" daysint></span></span>
                        <form action="" method="post" class="">
                            <input type="text" required="" name="order[fio]" placeholder="Ричард Артурович">
                            <input type="tel" required="" name="order[phone]" placeholder="+49 100 00 00 00">
                            <button type="submit" class="btn" onclick="$(this).closest('form').submit();return false;">Получить</button>
                            <p class="after_order">*при оформлении заказа</p>
                        </form>
                    </div>
                    <div class="col-md-2 header-list">
                        <ul class="list-unstyled">
                            <li>Останавливает выпадение волос</li>
                            <li>Предотвращает облысение</li>
                            <li>Ускоряет рост<br> волос</li>
                        </ul>
                    </div>
                    <!-- </div> -->
                </div>
        </div>

        <div class="row tablet-row">
            <img src="./static/img/1/order1.png" class="header-order-tablet" />
        </div>
    </div>

<script src="./static/dist/bundle.js"></script>
</body>
</html>