import '../css/main.scss';
//------------------------
import './bootstrap.min';

$(function () {
    var $redCoronaBanner = $('#corona-banner.main-banner');
    var $greenCoronaBanner = $('#corona-banner').not('.main-banner');
    var $cookieBlock = $('#cookie');
    var $footer = $('.fMask'); // Изменить селектор если отличается
    var $callbackBtn = $('#kmacb');
    var $body = $('body');
    var wasWindowResizedOrScrolled = false;
  
    changeIndents();
  
    $cookieBlock.on('click', '#closecookie1, #closecookie2', changeIndents);
  
    window.addEventListener('load', function() {
      $(document).on('scroll', function() {
        wasWindowResizedOrScrolled = true;
        changeIndents();
      });
      $(window).on('resize', function() {
        wasWindowResizedOrScrolled = true;
        changeIndents();
      });
    });
  
    function changeIndents() {
      var calculatedIndents = getCalculatedIndents();
  
      $footer.css('padding-bottom', calculatedIndents.footerIndent + 'px');
      $callbackBtn.css('bottom', calculatedIndents.callbackBtnIndent + 'px');
      $redCoronaBanner.css('margin-bottom', calculatedIndents.redCoronaBannerIndent + 'px');
  
      wasWindowResizedOrScrolled && $body.css('padding-top', calculatedIndents.bodyIndent + 'px');
    }
  
    function getCalculatedIndents() {
      var cookieBlockHeight = getBlockHeight($cookieBlock);
      var redCoronaBannerHeight = getBlockHeight($redCoronaBanner);
      var greenCoronaBannerHeight = getBlockHeight($greenCoronaBanner);
  
      var footerIndent = cookieBlockHeight + redCoronaBannerHeight + 35;
      if($(window).scrollTop() > 100) {
        var callbackBtnIndent = cookieBlockHeight + redCoronaBannerHeight;
      } else {
        var callbackBtnIndent = cookieBlockHeight;
      }
      var bodyIndent = greenCoronaBannerHeight || redCoronaBannerHeight;
      var redCoronaBannerIndent = cookieBlockHeight;
  
  
      return {
        footerIndent,
        callbackBtnIndent,
        bodyIndent,
        redCoronaBannerIndent,
      };
    }
  
    function checkBlockAvailability($block) {
      return $block.css('display') !== 'none' && $block.length !== 0;
    }
  
    function getBlockHeight($block) {
      var isBlockAvailable = checkBlockAvailability($block);
      var blockHeight = isBlockAvailable ? $block.outerHeight() : 0;
  
      return blockHeight;
    }
  });
    
  
    $(document).ready(function(){
      $('a[href^="#"]:not(.carousel-control-next):not(.carousel-control-prev)').bind("click", function(e) {
        var anchor = $(this);
        var offset = ($('#corona-banner') && !$('#corona-banner').hasClass('main-banner') && $('#corona-banner').css('display') !== 'none') ? $('#corona-banner').outerHeight() : 0;
        if (!$(this).hasClass('popup-open') && $(anchor.attr('href')).length) {
          $('html, body').stop().animate(
            {scrollTop: $(anchor.attr('href')).offset().top - offset},
            1000
          );
          e.preventDefault();
        }
      });
      return false;
    });

