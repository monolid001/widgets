<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Mizoxin</title>

    <link rel="stylesheet" href="./static/dist/bundle.css">

    <link rel="shortcut icon" type="image/png" href="./static/img/favicon-16.png" />
    <link rel="shortcut icon" type="image/png" href="./static/img/favicon-32.png" />
    <link rel="shortcut icon" type="image/png" href="./static/img/favicon-96.png" />


</head>

<body>

    <section class="block-wrap first-block">
        <div class="container left-block desctop">
            <h1 class="head-title">MIZOXIN</h1>
            <h3 class="head-subtitle">средство против облысения и для роста волос</h3>
            <div class="form-block">
                <h2 class="price"><span class="upstar">БЕСПЛАТНО</span></h2>
                <h3 class="last-day">ПОСЛЕДНИЙ ДЕНЬ</h3>
                <h3 class="last-day last-day-text"><span class="nowdate" format="dayI monthS" daysint></span></h3>
                <form action="" method="POST">
                    <input class="form-control form-input" name="order[fio]" type="text" placeholder="Ваше имя">
                    <input class="form-control form-input" name="order[phone]" type="tel">
                    <button class="btn btn-primary form-button" type="button" onclick="$(this).closest('form').submit();return false;">ПОЛУЧИТЬ БЕСПЛАТНО</button>
                    <p class="note">* при оформлении заказа</p>
                </form>
            </div>
        </div>
        <div class="container left-block mobile">
            <h1 class="head-title">MIZOXIN</h1>
            <h3 class="head-subtitle">средство против облысения и для роста волос</h3>
        </div>
        <div class="container middle-block">
            <div class="list-block">
                <ul>
                    <li class="list-point">ОСТАНАВЛИВАЕТ<span class="list-subtext">выпадение волос</span></li>
                    <li class="list-point">УКРЕПЛЯЕТ<span class="list-subtext">волосяные луковицы</span></li>
                    <li class="list-point">ПРЕДОТВРАЩАЕТ<span class="list-subtext">облысение</span></li>
                </ul>
            </div>
            <div class="prod-img-block"><img class="product-img" loading="lazy" src="./static/img/order_tube1.png"></div>
        </div>
        <div class="form-block mobile">
                <h2 class="price"><span class="upstar">БЕСПЛАТНО</span></h2>
                <h3 class="last-day">ПОСЛЕДНИЙ ДЕНЬ</h3>
                <h3 class="last-day last-day-text"><span class="nowdate" format="dayI monthS" daysint></span></h3>
                <form action="" method="POST">
                    <select class="form-control form-input" name="order[country]" >{{country_options}}</select>
                    <input class="form-control form-input" name="order[fio]" type="text" placeholder="Ваше имя">
                    <input class="form-control form-input" name="order[phone]" type="tel">
                    <button class="btn btn-primary form-button" type="button" onclick="$(this).closest('form').submit();return false;">ПОЛУЧИТЬ БЕСПЛАТНО</button>
                    <p class="note">* при оформлении заказа</p>
                <input type="hidden" name="order[specifications]" value="" />
                <input type="hidden" name="order[discount]" value="">
                {{form_inviz}}
                </form>
            </div>
        <div class="container right-block">
            <div class="man-img-block"><img class="man-img" loading="lazy" src="./static/img/man1.png">
                <div class="magazines-block">
                    <p class="magazines-text">нас рекомендуют:</p><img class="magazines-img" loading="lazy" src="./static/img/logo.png">
                </div>
            </div>
        </div>
    </section>
    <section class="block-wrap second-block">
        <h1 class="title nomargin">САМЫЕ ЧАСТЫЕ ПРИЧИНЫ <span class="title-select">ВЫПАДЕНИЯ </span>ВОЛОС</h1>
        <h1 class="title">у мужчин</h1>
        <div class="container reasons-container desctop">
            <div class="reasons-left">
                <div class="reason">
                    <h1 class="reason-title">ГЕНЕТИЧЕСКАЯ ПРЕДРАСПОЛОЖЕННОСТЬ</h1>
                    <div class="reason-item-img-block-left"><img class="reason-item-img" loading="lazy" src="./static/img/stress1.png"></div>
                </div>
                <div class="reason">
                    <h1 class="reason-title">ГОРМОНАЛЬНЫЙ ДИСБАЛАНС</h1>
                    <div class="reason-item-img-block-left-bottom"><img class="reason-item-img" loading="lazy" src="./static/img/stress2.png"></div>
                </div>
            </div>
            <div class="reasons-img-block"><img class="reason-img" loading="lazy" src="./static/img/men2.png"></div>
            <div class="reasons-left reasons-right">
                <div class="reason reason-right">
                    <h1 class="reason-title">НЕГАТИВНЫЕ ВНЕШНИЕ ФАКТОРЫ</h1>
                    <div class="reason-item-img-block-right"><img class="reason-item-img fourth" loading="lazy" src="./static/img/stress3.png"></div>
                </div>
                <div class="reason reason-right">
                    <h1 class="reason-title rt-right">БЛОКИРОВКА ВОЛОСЯНЫХ ФОЛИКУЛ</h1>
                    <div class="reason-item-img-block-right-bottom"><img class="reason-item-img" loading="lazy" src="./static/img/stress4.png"></div>
                </div>
            </div>
        </div>
        <div class="container reasons-container mobile"><img class="reason-img-mobille" loading="lazy" src="./static/img/men2.png">
            <div class="reasons-block-mobile">
                <div class="reasons-item-mobile"><img class="reasons-img-mobile" loading="lazy" src="./static/img/stress1.png">
                    <p class="reason-title">ГЕНЕТИЧЕСКАЯ ПРЕДРАСПОЛОЖЕННОСТЬ</p>
                </div>
                <div class="reasons-item-mobile"><img class="reasons-img-mobile" loading="lazy" src="./static/img/stress3.png">
                    <p class="reason-title">НЕГАТИВНЫЕ ВНЕШНИЕ ФАКТОРЫ</p>
                </div>
                <div class="reasons-item-mobile"><img class="reasons-img-mobile" loading="lazy" src="./static/img/stress2.png">
                    <p class="reason-title">ГОРМОНАЛЬНЫЙ ДИСБАЛАНС</p>
                </div>
                <div class="reasons-item-mobile"><img class="reasons-img-mobile" loading="lazy" src="./static/img/stress2.png">
                    <p class="reason-title">БЛОКИРОВКА ВОЛОСЯНЫХ ФОЛЛИКУЛ</p>
                </div>
            </div>
            <div class="carousel slide reasons-carousel" data-bs-ride="false" id="carousel-3">
                <div class="carousel-inner">
                    <div class="carousel-item active"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/stress1.png" alt="Slide Image">
                        <p class="reasons-title-mobile">ГЕНЕТИЧЕСКАЯ ПРЕДРАСПОЛОЖЕННОСТЬ</p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/stress3.png" alt="Slide Image">
                        <p class="reasons-title-mobile">НЕГАТИВНЫЕ ВНЕШНИЕ ФАКТОРЫ</p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/stress2.png" alt="Slide Image">
                        <p class="reasons-title-mobile">ГОРМОНАЛЬНЫЙ ДИСБАЛАНС</p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/stress4.png" alt="Slide Image">
                        <p class="reasons-title-mobile">БЛОКИРОВКА ВОЛОСЯНЫХ ФОЛЛИКУЛ</p>
                    </div>
                </div>
                <div><a class="carousel-control-prev" href="#carousel-3" role="button" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span><span class="visually-hidden">Previous</span></a><a class="carousel-control-next" href="#carousel-3" role="button" data-bs-slide="next"><span class="carousel-control-next-icon"></span><span class="visually-hidden">Next</span></a></div>
                <div class="carousel-indicators"><button type="button" data-bs-target="#carousel-3" data-bs-slide-to="0" class="active"></button> <button type="button" data-bs-target="#carousel-3" data-bs-slide-to="1"></button> <button type="button" data-bs-target="#carousel-3" data-bs-slide-to="2"></button> <button type="button" data-bs-target="#carousel-3" data-bs-slide-to="3"></button></div>
            </div>
        </div>
    </section>
    <section class="block-wrap third-block desctop">
        <div class="container note-block">
            <div class="note-block-img"><img class="men3-img" loading="lazy" src="./static/img/men3.png"></div>
            <div class="note-block-middle">
                <h1 class="note-title">80%</h1>
            </div>
            <div class="note-block-middle">
                <p>Европейских мужчин страдают андрогенетической алопецией <span>УЖЕ ПОСЛЕ 35 ЛЕТ</span></p>
                <p class="last-p">– исследование Берлинского университета Charité</p>
            </div>
        </div>
    </section>
    <section class="block-wrap third-block mobile">
        <div class="container note-block">
            <div class="note-info">
                <div class="note-block-middle">
                    <h1 class="note-title">80%</h1>
                </div>
                <div class="note-block-middle">
                    <p>Европейских мужчин страдают андрогенетической алопецией <br><span>УЖЕ ПОСЛЕ 35 ЛЕТ</span></p>
                    <p class="last-p">Исследование Берлинского университета Charité</p>
                </div>
            </div>
            <div class="note-block-img"><img class="men3-img" loading="lazy" src="./static/img/men3.png"></div>
        </div>
    </section>
    <section class="block-wrap fourth-block">
        <h1 class="title">ВЫПАДЕНИЕ ВОЛОС <span class="title-select">МОЖЕТ ПРИВЕСТИ </span>К <br><span class="title-select">ЧАСТИЧНОЙ</span> АЛОПЕЦИИ</h1>
        <div class="container second-block">
            <div class="cond-left">
                <p class="cond-text">Миллионы людей страдают от заболевания, при котором волосы выпадают круглыми пятнами. Это заболевание называется алопеция Ареата (очаговая алопеция).</p>
                <p class="cond-text"><span class="cond-select">Заболевание возникает внезапно</span> – в один день все нормально, затем, буквально за ночь, волосы выпадают и на голове появляются круглые небольшие залысины.</p>
                <p class="cond-text"><span class="cond-select">Алопеция Ареата</span> – это заболевание, при котором имунная система организма ошибочно идентифицирует волосяные фолликулы как чужеродную угрозу – например, вирус – и атакует их. <span class="cond-select">Это один из самых распространенных видов</span> выпадения волос, по частоте встречаемости уступающий только генетическому выпадению волос.</p>
            </div>
            <div class="cond-right">
                <div class="cond-img-1"><img class="cond-img" loading="lazy" src="./static/img/alopeciya1.jpg"><img class="cond-img" loading="lazy" src="./static/img/alopeciya2.jpg"></div>
                <div class="cond-img-1"><img class="cond-img" loading="lazy" src="./static/img/alopeciya3.jpg"><img class="cond-img" loading="lazy" src="./static/img/alopeciya4.jpg"></div>
            </div>
        </div>
    </section>
    <section class="block-wrap fifth-block">
        <h1 class="title">MIZOXIN <span class="fifth-title-span">ПОЛНОСТЬЮ ИЗБАВЛЯЕТ </span><br>ОТ ПРОБЛЕМЫ ОБЛЫСЕНИЯ</h1>
        <div class="container pref-block">
            <div class="left-pref-block"><img class="what-img" loading="lazy" src="./static/img/gif.gif"></div>
            <!--<div class="what-lines"><img class="what-lines-img" loading="lazy" src="./static/img/roads.png"></div>-->
            <div class="right-pref-block">
                <ul class="what-list">
                    <li>ОСТАНАВЛИВАЕТ <span>чрезмерное выпадение волос</span></li>
                    <li>УСТРАНЯЕТ ПРИЧИНУ <span>выпадения, а не маскирует проблему</span></li>
                    <li>ОЗДОРАВЛИВАЕТ <span>и увлажняет кожу головы</span></li>
                    <li>УЛУЧШАЕТ <span>кровоснабжение волосяных фолликул</span></li>
                    <li>СТИМУЛИРУЕТ <span>рост волос</span></li>
                    <li>УВЕЛИЧИВАЕТ <span>плотность и толщину каждого волоса</span></li>
                </ul>
                <div class="what-icon"><img loading="lazy" src="./static/img/ico1.svg"><img loading="lazy" src="./static/img/ico2.svg"><img loading="lazy" src="./static/img/ico3.svg"></div>
            </div>
        </div>
    </section>
    <section class="block-wrap">
        <h1 class="title"><span class="fifth-title-span">ТОЛЬКО</span> НАТУРАЛЬНЫЕ <span class="fifth-title-span">ИНГРИДИЕНТЫ</span></h1>
        <div class="container consist-wrap desctop">
            <div class="consist-left-block">
                <div class="consist-item">
                    <div class="consist-left-side">
                        <p class="consist-head">Экстракт виноградных косточек</p>
                        <p class="consist-text">стимулирует рост волос за счет питания у корней и повышения тонуса эпидермиса</p>
                    </div><img class="consist-item-img" loading="lazy" src="./static/img/sost1.png">
                </div>
                <div class="consist-item">
                    <div class="consist-left-side">
                        <p class="consist-head"><strong>Аргановое масло</strong></p>
                        <p class="consist-text">ускоряет регенерацию поврежденных клеток и стимулирует рост волос</p>
                    </div><img class="consist-item-img3" loading="lazy" src="./static/img/sost3.png">
                </div>
            </div>
            <div><img class="consist-img" loading="lazy" src="./static/img/order_tube2.png"></div>
            <div class="consist-left-block">
                <div class="consist-item consist-item-right">
                    <div class="consist-left-side">
                        <p class="consist-head"><strong>Эфирное масло розмарина</strong></p>
                        <p class="consist-text">увеличивает приток крови к волосяным фолликулам и способствует их активации</p>
                    </div><img class="consist-item-img2" loading="lazy" src="./static/img/sost2.png">
                </div>
                <div class="consist-item consist-item-right">
                    <div class="consist-left-side">
                        <p class="consist-head">Экстракт лопуха</p>
                        <p class="consist-text">регулирует выделение кожного себума, увлажняет кожу головы, устраняет перхоть</p>
                    </div><img class="consist-item-img4" loading="lazy" src="./static/img/sost4.png">
                </div>
            </div>
        </div>
        <div class="container consist-wrap mobile">
            <div class="carousel slide" data-bs-ride="false" id="carousel-2">
                <div class="carousel-inner">
                    <div class="carousel-item active"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/sost1.png" alt="Slide Image">
                        <p class="consist-title-mobile">Экстракт виноградных косточек</p>
                        <p class="consist-text-mobile">стимулирует рост волос за счет питания у корней и повышения тонуса эпидермиса</p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/sost2.png" alt="Slide Image">
                        <p class="consist-title-mobile">Эфирное масло розмарина</p>
                        <p class="consist-text-mobile"><span style="color: rgb(249, 249, 249);">увеличивает приток крови к волосяным фолликулам и способствует их активации</span></p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/sost3.png" alt="Slide Image">
                        <p class="consist-title-mobile">Аргановое масло</p>
                        <p class="consist-text-mobile">ускоряет регенерацию поврежденных клеток и стимулирует рост волос</p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block sost-img-mobile" loading="lazy" src="./static/img/sost4.png" alt="Slide Image">
                        <p class="consist-title-mobile">Экстракт лопуха</p>
                        <p class="consist-text-mobile">регулирует выделение кожного себума, увлажняет кожу головы, устраняет перхоть</p>
                    </div>
                </div>
                <div><a class="carousel-control-prev" href="#carousel-2" role="button" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span><span class="visually-hidden">Previous</span></a><a class="carousel-control-next" href="#carousel-2" role="button" data-bs-slide="next"><span class="carousel-control-next-icon"></span><span class="visually-hidden">Next</span></a></div>
                <div class="carousel-indicators"><button type="button" data-bs-target="#carousel-2" data-bs-slide-to="0" class="active"></button> <button type="button" data-bs-target="#carousel-2" data-bs-slide-to="1"></button> <button type="button" data-bs-target="#carousel-2" data-bs-slide-to="2"></button> <button type="button" data-bs-target="#carousel-2" data-bs-slide-to="3"></button></div>
            </div>
        </div>
    </section>
    <section class="block-wrap seventh-block">
        <div class="container attention first-attention-block">
            <h1 class="title">ОСТЕРЕГАЙТЕСЬ ПОДДЕЛОК!</h1>
            <p class="attention-first-p">Mizoxin прошел все необходимые тесты и соответствует всем <span class="cond-select">европейским стандартам.</span></p>
            <p>Если вы хотите избежать подделок и получить гарантированный результат – используйте оригинальное средство <span class="cond-select">на этом сайте.</span></p>
            <div class="attention-icons"><img class="quality-img" loading="lazy" src="./static/img/quality.png"><img class="quality-icon" loading="lazy" src="./static/img/quality-eu.png"></div>
        </div>
        <div class="container attention attention-img-block"><img class="attention-img" loading="lazy" src="./static/img/order_sert.png"></div>
        <div class="form-block">
            <h2 class="price"><span class="upstar">БЕСПЛАТНО</span></h2>
            <h3 class="last-day">ПОСЛЕДНИЙ ДЕНЬ</h3>
            <h3 class="last-day last-day-text"><span class="nowdate" format="dayI monthS" daysint></span></h3>
                <form action="" method="POST">
                    <input class="form-control form-input" name="order[fio]" type="text"  placeholder="Ваше имя">
                    <input class="form-control form-input" name="order[phone]" type="tel">
                    <button class="btn btn-primary form-button" type="button" onclick="$(this).closest('form').submit();return false;">ПОЛУЧИТЬ БЕСПЛАТНО</button>
                    <p class="note">* при оформлении заказа</p>
                </form>
        </div>
    </section>
    <section class="block-wrap eighth-block desctop">
    <div class="fourth-block-wrap">
        <img class="expert-img" loading="lazy" src="./static/img/doc.png">
        <div class="container expert">
            <p class="expert-text">Выпадение и истончение волос является очень распространенной проблемой. Особенно страдают мужчины старше 30 лет. Как правило, облысение – это результат взаимодействия различных факторов, включая генетическую предрасположенность, гормональные изменения, старение и внешние воздействия. Часто проблема усугубляется тем, что ранние симптомы не замечают или попросту игнорируют, что приводит к длительному и обширному облысению. Выпадение волос – не только физиологическая проблема. Она может спровоцировать снижение самооценки, потерю уверенности в себе, проблемы в личном и профессиональном общении.</p>
            <p class="expert-text"><span class="cond-select">К счастью, сегодня есть методы, позволяющие восстановить и укрепить волосы и сохранить их в наилучшем состоянии.</span> Один из таких методов – спрей MIZOXIN. Это абсолютно натуральное, простое и удобное в использовании средство, давно доказавшее свою эффективность в борьбе с облысением.</p>
            <div class="expert-sign"><img class="sign-ing" loading="lazy" src="./static/img/signature.png">
                <div class="expert-name">
                    <p class="expert-text name">Леонард Гросман</p>
                    <p class="expert-text reg">Ведущий трихолог, член Европейского общества исследования волос (EHRS) и Международной ассоциации трихологов (IAT).</p>
                </div>
            </div>
        </div>
    </div>
    </section>
    <section class="block-wrap eighth-block mobile">
        <div class="container expert-wrap-mobile">
            <div class="expert-block-mobile"><img class="expert-image-mobile" loading="lazy" src="./static/img/doc.png">
                <div class="expert-sign-mobile"><img class="quote-image" loading="lazy" src="./static/img/coma.png">
                    <p class="quote-text"><span><span style="color: rgb(249, 249, 249); background-color: rgb(228, 10, 23);">К счастью, сегодня есть методы, позволяющие восстановить и укрепить волосы и сохранить их в наилучшем состоянии.</span></span></p>
                    <div class="expert-name">
                        <p class="expert-text name">Леонард Гросман</p>
                        <p class="expert-text reg">Ведущий трихолог , член Европейского общества исследования волос (EHRS) и Международной ассоциации трихологов (IAT).</p>
                    </div>
                </div>
            </div>
            <div>
                <p class="expert-text">Выпадение и истончение волос является очень распространенной проблемой. Особенно страдают мужчины старше 30 лет. Как правило, облысение – это результат взаимодействия различных факторов, включая генетическую предрасположенность, гормональные изменения, старение и внешние воздействия. Часто проблема усугубляется тем, что ранние симптомы не замечают или попросту игнорируют, что приводит к длительному и обширному облысению. Выпадение волос – не только физиологическая проблема. Она может спровоцировать снижение самооценки, потерю уверенности в себе, проблемы в личном и профессиональном общении.</p>
                <p class="expert-text">Один из таких методов – спрей MIZOXIN. Это абсолютно натуральное, простое и удобное в использовании средство, давно доказавшее свою эффективность в борьбе с облысением.</p>
            </div>
        </div>
    </section>
    <section class="block-wrap fourth-block">
    <div class="fourth-block-wrap">
        <div class="container feed-wrap">
            <h1 class="title">ОТЗЫВЫ</h1>
            <div class="carousel slide" data-bs-ride="false" id="carousel-1">
                <div class="carousel-inner">
                    <div class="carousel-item active"><img class="w-100 d-block" loading="lazy" src="./static/img/otz1.png" alt="Slide Image">
                        <p class="feed-text">Даже не ожидал, что результат будет таким быстрым и явным. Mizoxin - это действительно эффективное решение для тех, кто хочет вернуть густые волосы.</p>
                        <p class="feed-text feed-text-name">Артем Кремер, <span class="pl_city_stock5"></span></p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block" loading="lazy" src="./static/img/otz2.png" alt="Slide Image">
                        <p class="feed-text">Mizoxin - это находка! Я начал лысеть два года назад и перепробовал кучу средств, которые совершенно не помогали. Но благодаря спрею Mizoxin я наконец смог изабвиться от засылин, мои волосы обрели густоту и здоровый вид, а самое главное - я опять чувствую себя уверенно!</p>
                        <p class="feed-text feed-text-name">Максим Тевкелев, <span class="pl_city_stock7"></span></p>
                    </div>
                    <div class="carousel-item"><img class="w-100 d-block" loading="lazy" src="./static/img/otz3.png" alt="Slide Image">
                        <p class="feed-text">Мизоксин - это мое спасение! Я уже так отчаялся что подумывал о пересадке. Но благодаря Мизоксину моя проблема облысения уходит в прошлое, я с каждым днем вижу как волосы становятся крепче и гуще.</p>
                        <p class="feed-text feed-text-name">Марат Мустафин, <span class="pl_city_more5"></span></p>
                    </div>
                </div>
                <div>
                    <a class="carousel-control-prev" href="#carousel-1" role="button" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span><span class="visually-hidden">Previous</span></a>
                    <a class="carousel-control-next" href="#carousel-1" role="button" data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span><span class="visually-hidden">Next</span>
                    </a>
                </div>
                <div class="carousel-indicators"><button type="button" data-bs-target="#carousel-1" data-bs-slide-to="0" class="active"></button> <button type="button" data-bs-target="#carousel-1" data-bs-slide-to="1"></button> <button type="button" data-bs-target="#carousel-1" data-bs-slide-to="2"></button></div>
            </div>
        </div><img class="feed-img" loading="lazy" src="./static/img/men4.png">
    </div>
    </section>
    <section class="block-wrap tenth-block">
        <h1 class="title">КАК ЗАКАЗАТЬ?</h1>
        <div class="container order-block">
            <div class="order-item"><img class="order-img" loading="lazy" src="./static/img/zakaz1.png">
                <p class="order-text">Оставьте заявку на нашем сайте, заполнив форму заказа</p>
            </div>
            <div class="order-item"><img class="order-img" loading="lazy" src="./static/img/zakaz3.png">
                <p class="order-text">Наш специалист свяжется с вами для уточнения деталей</p>
            </div>
            <div class="order-item"><img class="order-img" loading="lazy" src="./static/img/zakaz2.png">
                <p class="order-text">Вы получите заказ удобным для вас способом в течение 3‑5 дней</p>
            </div>
        </div>
    </section>
    <section class="block-wrap first-block last-block">
        <div class="container left-block">
            <h1 class="head-title">MIZOXIN</h1>
            <h3 class="head-subtitle">средство против облысения и для роста волос</h3>
            <div class="form-block desctop">
                <h2 class="price"><span class="upstar">БЕСПЛАТНО</span></h2>
                <h3 class="last-day">ПОСЛЕДНИЙ ДЕНЬ</h3>
                <h3 class="last-day last-day-text"><span class="nowdate" format="dayI monthS" daysint></span></h3>
                <form action="" method="POST">
                    <input class="form-control form-input" name="order[fio]" type="text"  placeholder="Ваше имя">
                    <input class="form-control form-input" name="order[phone]" type="tel">
                    <button class="btn btn-primary form-button" type="button" onclick="$(this).closest('form').submit();return false;">ПОЛУЧИТЬ БЕСПЛАТНО</button>
                    <p class="note">* при оформлении заказа</p>
                </form>
            </div>
        </div>
        <div class="container middle-block">
            <div class="list-block">
                <ul>
                    <li class="list-point">ОСТАНАВЛИВАЕТ<span class="list-subtext">выпадение волос</span></li>
                    <li class="list-point">УКРЕПЛЯЕТ<span class="list-subtext">волосяные луковицы</span></li>
                    <li class="list-point">ПРЕДОТВРАЩАЕТ<span class="list-subtext">облысение</span></li>
                </ul>
            </div>
            <div class="prod-img-block"><img class="product-img" loading="lazy" src="./static/img/order_tube1.png"></div>
        </div>
        <div class="form-block mobile">
                <h2 class="price"><span class="upstar">БЕСПЛАТНО</span></h2>
                <h3 class="last-day">ПОСЛЕДНИЙ ДЕНЬ</h3>
                <h3 class="last-day last-day-text"><span class="nowdate" format="dayI monthS" daysint></span></h3>
                <form action="" method="POST">
                    <input class="form-control form-input" name="order[fio]" type="text"  placeholder="Ваше имя">
                    <input class="form-control form-input" name="order[phone]" type="tel">
                    <button class="btn btn-primary form-button" type="button" onclick="$(this).closest('form').submit();return false;">ПОЛУЧИТЬ БЕСПЛАТНО</button>
                    <p class="note">* при оформлении заказа</p>
                </form>
            </div>
        <div class="container right-block">
            <div class="last-img-block"><img class="man-img" loading="lazy" src="./static/img/men5.png"></div>
            <div class="magazines-block">
                <p class="magazines-text">нас рекомендуют:</p><img class="magazines-img" loading="lazy" src="./static/img/logo.png">
            </div>
        </div>
    </section>
    <footer class="fMask">
        {{landing_footer_requisites}}
        {{landing_footer_links}}
    </footer>



<script src="./static/dist/bundle.js"></script>

<script>
document.querySelectorAll('.carousel-control-prev').forEach(function (button) {
    button.addEventListener('click', function (event) {
        event.preventDefault();
    });
});
document.querySelectorAll('.carousel-control-next').forEach(function (button) {
    button.addEventListener('click', function (event) {
        event.preventDefault();
    });
});
</script>

</body>
</html>
