import "../css/main.scss";

$(document).ready(function () {
  var currentStep = 1;
  var time = 600;
  var intr;

  function updateProgress(step) {
    var progress = step * 25;
    $("#fill").css("width", progress + "%");
    $("#count").text(step + "/4");
  }

  async function showStep() {
    if (currentStep === 1) {
      $(`#step${currentStep}`).fadeIn(500).css("display", "flex");
    }
    if (currentStep === 2) {
      $(`#step${currentStep - 1}`).fadeOut();
      await new Promise((r) => setTimeout(r, 500));
      $(`#step${currentStep}`).fadeIn(500).css("display", "flex");
      $("#skip-btn").fadeOut();
      $("#form-btn").html("Следующий вопрос");
      updateProgress(1);
    }
    if (
      currentStep === 3 ||
      currentStep === 5 ||
      currentStep === 7 ||
      currentStep === 9
    ) {
      if (!$('input[name="eat"]:checked').length && currentStep === 3) {
        return;
      }
      if (!$('input[name="walk"]:checked').length && currentStep === 5) {
        return;
      }
      if (!$('input[name="emoji"]:checked').length && currentStep === 7) {
        return;
      }
      if (!$('input[name="fam"]:checked').length && currentStep === 9) {
        return;
      }
      $(`#step${currentStep - 1}`).fadeOut();
      await new Promise((r) => setTimeout(r, 500));
      $(`#step${currentStep}`).slideDown();
      $("#form-btn").html("Продолжить");
    }
    if (currentStep === 4) {
      $(`#step${currentStep - 1}`).slideUp();
      await new Promise((r) => setTimeout(r, 500));
      $(`#step${currentStep}`).fadeIn(500).css("display", "flex");
      $("#form-btn").html("Следующий вопрос");
      updateProgress(2);
    }
    if (currentStep === 6) {
      $(`#step${currentStep - 1}`).slideUp();
      await new Promise((r) => setTimeout(r, 500));
      $(`#step${currentStep}`).fadeIn(500).css("display", "flex");
      $("#form-btn").html("Следующий вопрос");
      updateProgress(3);
    }
    if (currentStep === 8) {
      $(`#step${currentStep - 1}`).slideUp();
      await new Promise((r) => setTimeout(r, 500));
      $(`#step${currentStep}`).fadeIn(500).css("display", "flex");
      $("#form-btn").html("Следующий вопрос");
      updateProgress(4);
    }
    if (currentStep === 10) {
      $(`#step${currentStep - 1}`).fadeOut();
      await new Promise((r) => setTimeout(r, 500));
      $(`#step${currentStep}`).fadeIn(500).css("display", "flex");
      $("#done").fadeIn(500).css("display", "flex");
      $(".progressbar").fadeOut();
      $("#form-btn").html("ПОЛУЧИТЬ БЕСПЛАТНО");
    }

    if (currentStep === 11) {
      $(".test-wrapper").slideUp();
      await new Promise((r) => setTimeout(r, 500));
      $(".order_block").slideDown();
      start_timer();

      let el = $("#roulette");
      if (!el) {
        el = $("#order_form");
      }
      let top = el.offset().top;
      $("body,html").animate({ scrollTop: top }, 800);

      return;
    }

    $('html, body').animate({
      scrollTop: $('#form-container').offset().top - ($(window).height() - $('#form-container').outerHeight(true)) / 2
    }, 500);

    currentStep++;
  }

  $(document).on("click", "#form-btn", function () {
    showStep();
  });

  $(document).on("click", "#skip-btn", async function () {
    $(".test-wrapper").slideUp();
    await new Promise((r) => setTimeout(r, 500));
    $(".order_block").slideDown();
    start_timer();

    let el = $("#roulette");
    if (!el) {
      el = $("#order_form");
    }
    let top = el.offset().top;
    $("body,html").animate({ scrollTop: top }, 800);
  });

  $(document).on("click", "#step2 .checkbox", function () {
    const checkboxItem = $(this).closest(".checkbox-item");

    const checkbox = checkboxItem.find('input[name="eat"]');

    checkbox.prop("checked", !checkbox.prop("checked"));

    checkboxItem.toggleClass("active", checkbox.prop("checked"));
  });

  $(document).on("click", "#step4 .checkbox", function () {
    const checkboxItem = $(this).closest(".checkbox-item");

    const checkbox = checkboxItem.find('input[name="walk"]');

    checkbox.prop("checked", !checkbox.prop("checked"));

    checkboxItem.toggleClass("active", checkbox.prop("checked"));
  });

  $(document).on("click", "#step6 .checkbox", function () {
    const checkboxItem = $(this).closest(".checkbox-item");

    const checkbox = checkboxItem.find('input[name="emoji"]');

    checkbox.prop("checked", !checkbox.prop("checked"));

    checkboxItem.toggleClass("active", checkbox.prop("checked"));
  });

  $(document).on("click", "#step8 .checkbox", function () {
    const checkboxItem = $(this).closest(".checkbox-item");

    const checkbox = checkboxItem.find('input[name="fam"]');

    checkbox.prop("checked", !checkbox.prop("checked"));

    checkboxItem.toggleClass("active", checkbox.prop("checked"));
  });

  showStep();

  function start_timer() {
    intr = setInterval(tick, 1000);
  }

  function tick() {
    time = time - 1;
    var mins = Math.floor(time / 60);
    var secs = time - mins * 60;
    if (mins == 0 && secs == 0) {
      clearInterval(intr);
    }
    secs = secs >= 10 ? secs : "0" + secs;
    $("#min").html("0" + mins);
    $("#sec").html(secs);
  }
});
