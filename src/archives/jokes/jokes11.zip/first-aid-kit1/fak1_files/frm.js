$(document).ready(function () {
    let t = document.querySelectorAll(".door"),
        e = document.querySelector(".spin-result-wrapper");
    function n(o) {
        $(".box").css("background", "none"),
            o.currentTarget.classList.add("open"),
            o.currentTarget.classList.add("vin"),
            setTimeout(function () {
                e.style.display = "block";
            }, 2500);
        for (let e = 0; e < t.length; e++)
            t[e].classList.contains("open") ||
                setTimeout(function () {
                    t[e].classList.add("open");
                }, 1500);
        for (let e = 0; e < t.length; e++) t[e].removeEventListener("click", n);
    }
    t.forEach(function (t) {
        t.addEventListener("click", n);
    });
}),
    $(".close-popup, .pop-up-button").click(function (e) {
        e.preventDefault(), $(".spin-result-wrapper").fadeOut();
    });

var time = 600;
var intr;

function start_timer() {
    intr = setInterval(tick, 1000);
}

function tick() {
    time = time - 1;
    var mins = Math.floor(time / 60);
    var secs = time - mins * 60;
    if (mins == 0 && secs == 0) {
        clearInterval(intr);
    }
    secs = secs >= 10 ? secs : "0" + secs;
    $("#min").html("0" + mins);
    $("#sec").html(secs);
}

const doors = document.querySelectorAll(".door");

function spin() {
    setTimeout(() => {
        setTimeout(function () {
            $(".door__wrapper").fadeOut();
            $(".order_block").fadeIn();
        }, 500),
            setTimeout(function () {
                start_timer();
            }, 500);
    }, 4000);
    doors.forEach((el) => el.removeEventListener("click", spin));
}

doors.forEach((el) => el.addEventListener("click", spin));