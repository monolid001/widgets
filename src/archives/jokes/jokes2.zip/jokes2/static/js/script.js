(function () {
  'use strict';

  const boxesWrapper = document.querySelector('.promo-boxes');
  const boxItems = document.querySelectorAll('.promo-boxes__item');
  const confirmPopup = document.querySelector('.promo-confirm-popup-boxes');
  const confirmPopupCloseElement = document.querySelector(
    '.promo-confirm-popup-boxes__close-popup'
  );
  const confirmPopupOkButtonElement = document.querySelector(
    '.promo-confirm-popup-boxes__button'
  );
  const form = document.querySelector('.promo-boxes-wrapper');
  const promoHeader = document.querySelector('.promo-boxes__header');
  const promoHeaderTextElement = document.querySelector(
    '.promo-boxes__header-text'
  );

  let attempt = 0;

  const openBox = function (e) {
    const currentTarget = e.currentTarget;
    

    if (attempt === 0) {
      attempt += 1;

      currentTarget
        .querySelector('.promo-boxes__box-image--closed')
        .classList.add('promo-box-image-hidden');
      currentTarget
        .querySelector('.promo-boxes__box-image--opened')
        .classList.remove('promo-box-image-hidden');
      currentTarget
        .classList.add('promo-box-current');

      promoHeader.classList.add('animate-header-red');
      promoHeaderTextElement.textContent =
        'У вас осталось 2 попытки! Попробуйте ещё!';
    } else if (attempt === 1) {
        attempt += 1;

        currentTarget
        .querySelector('.promo-boxes__box-image--closed')
        .classList.add('promo-box-image-hidden');
      currentTarget
        .querySelector('.promo-boxes__box-image--opened')
        .classList.remove('promo-box-image-hidden');
      currentTarget
        .classList.add('promo-box-current');

      promoHeader.classList.add('animate-header-red');
      promoHeaderTextElement.textContent =
        'У вас осталась 1 попытка! Попробуйте ещё раз!';
    } else {
        if (currentTarget.classList.contains('promo-box-current')) {
          return;
        } else {
          currentTarget
            .querySelector('.promo-boxes__box-image--closed')
            .classList.add('promo-box-image-hidden');
          
          currentTarget
            .querySelector('.promo-boxes__box-image--free')
            .classList.remove('promo-box-image-hidden');

          promoHeaderTextElement.textContent =
            'Вы выиграли скидку 50%!';

          setTimeout(function () {
            confirmPopup.classList.add('show');

            setTimeout(function () {
              form.style.display = 'block';
              $(boxesWrapper).slideUp();
            }, 1800);
          }, 1500);

          for (let i = 0; i < boxItems.length; i++) {
            boxItems[i].removeEventListener('click', openBox);
          }
        }
    }
  };

  for (let i = 0; i < boxItems.length; i++) {
    boxItems[i].addEventListener('click', openBox);
  }

  const closeConfirmPopup = function (e) {
    confirmPopup.classList.remove('show');

    e.preventDefault();
    return false;
  };

  confirmPopupCloseElement.addEventListener('click', closeConfirmPopup);
  confirmPopupOkButtonElement.addEventListener('click', closeConfirmPopup);
})();
