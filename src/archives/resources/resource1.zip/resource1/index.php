<!DOCTYPE html>
<html lang="de" dir="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>DocCheck</title>

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="./dist/bundle.css">
    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>

<body>
    <div class="ds">
        <dc-app-root class="dc-app-root" _nghost-doccheck-frontend-angular-c253="" ng-version="11.2.14"><dc-header
                _ngcontent-doccheck-frontend-angular-c253="" _nghost-doccheck-frontend-angular-c245=""
                class="ng-star-inserted"><sticky-anchor _ngcontent-doccheck-frontend-angular-c245="" style="
            display: block;
            position: relative;
            height: 130px;
            margin-top: 0px;
            margin-bottom: 0px;
          "></sticky-anchor>
                <div _ngcontent-doccheck-frontend-angular-c245="" id="dc-header" dchideheaderonscroll=""
                    class="dc-hhos-base-header dc-hhos-absolute">
                    <header _ngcontent-doccheck-frontend-angular-c245="" class="p-0">
                        <div _ngcontent-doccheck-frontend-angular-c245="" class="dc-container py-0 my-0 no-px-sm">
                            <div _ngcontent-doccheck-frontend-angular-c245="" class="d-flex">
                                <div _ngcontent-doccheck-frontend-angular-c245="" class="dc-icon">
                                    <a _ngcontent-doccheck-frontend-angular-c245="" href="#roulette"><img
                                            _ngcontent-doccheck-frontend-angular-c245="" loading="lazy"
                                            src="./img/dc-doc-animated.gif" alt="Doccheck" /></a>
                                </div>
                                <div _ngcontent-doccheck-frontend-angular-c245="" class="dc-logo">
                                    <a _ngcontent-doccheck-frontend-angular-c245="" class="d-inline-block"
                                        href="#roulette"><img _ngcontent-doccheck-frontend-angular-c245=""
                                            loading="lazy" src="./img/logo-dc-01.svg" alt="Doccheck"
                                            class="img-responsive" /></a>
                                </div>
                                <div _ngcontent-doccheck-frontend-angular-c245=""
                                    class="d-flex align-items-center justify-content-end login-link ng-star-inserted">
                                    <a href="#roulette" _ngcontent-doccheck-frontend-angular-c245="" dcauthclick="" class="dc-ft-ui">Log
                                        in</a>
                                </div>
                            </div>
                        </div>
                    </header>
                    <dc-navbar _ngcontent-doccheck-frontend-angular-c245="" _nghost-doccheck-frontend-angular-c242="">
                        <nav _ngcontent-doccheck-frontend-angular-c242="" class="navbar navbar-light px-0">
                            <div _ngcontent-doccheck-frontend-angular-c242=""
                                class="dc-container py-0 my-0 position-relative">
                                <dc-navbar-list _ngcontent-doccheck-frontend-angular-c242=""
                                    _nghost-doccheck-frontend-angular-c240="">
                                    <div _ngcontent-doccheck-frontend-angular-c240="" class="d-flex">
                                        <a _ngcontent-doccheck-frontend-angular-c240="" dctrack="click" routerlink="/"
                                            class="nav-item inline d-flex active" href="#roulette"><span
                                                _ngcontent-doccheck-frontend-angular-c240=""
                                                class="align-self-center dc-ft-ui">Community</span></a><a
                                            _ngcontent-doccheck-frontend-angular-c240="" dctrack="click"
                                            class="nav-item inline d-flex" href="#roulette"><span
                                                _ngcontent-doccheck-frontend-angular-c240=""
                                                class="align-self-center dc-ft-ui">Flexikon</span></a><a
                                            _ngcontent-doccheck-frontend-angular-c240="" dctrack="click"
                                            class="nav-item inline d-none d-sm-flex" href="#roulette"><span
                                                _ngcontent-doccheck-frontend-angular-c240=""
                                                class="align-self-center dc-ft-ui">Shop</span></a><a
                                            _ngcontent-doccheck-frontend-angular-c240="" dctrack="click"
                                            class="nav-item inline d-none d-md-flex" href="#roulette"><span
                                                _ngcontent-doccheck-frontend-angular-c240=""
                                                class="align-self-center dc-ft-ui">News</span></a><a href="#roulette"
                                            _ngcontent-doccheck-frontend-angular-c240="" placement="bottom"
                                            container="body" triggers="click" dctrack="click"
                                            dcclosepopoveronoutsideclick="" class="nav-item inline d-flex">
                                           <img width="21px" loading="lazy" src="./img/more.png" alt="">
                                            </a>
                                    </div>
                                </dc-navbar-list>                                                               
                                <button _ngcontent-doccheck-frontend-angular-c242=""
                                    class="btn btn-icon icon  search-button ng-star-inserted fas"><a href="#roulette" style="padding:0; margin:0;"><img width="29px" loading="lazy" src="./img/magnifi.png" alt=""></a>
                                </button>
                            </div>
                        </nav>
                    </dc-navbar>
                </div>
            </dc-header>
    </div>
    <div class="main">
        <div class="main-container">
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde sapiente quod expedita error alias natus consectetur saepe quam quasi facilis, totam a? Explicabo magni dolorum, ratione recusandae molestiae id corporis?
           Veniam sapiente iste deleniti ullam autem reiciendis, doloribus ipsam quod quaerat vel ratione expedita aspernatur quis molestias illo officia nam quia voluptatibus? Modi, assumenda voluptates aliquid consequatur amet harum incidunt?
           Suscipit eveniet ab nisi numquam laudantium animi explicabo earum temporibus asperiores, maxime necessitatibus perferendis. Tempore deleniti repudiandae repellat omnis nobis eligendi, qui fugit suscipit explicabo aspernatur. Vero optio quidem ipsum.
           Doloremque tempora eius minima quam, itaque vel ab neque consequatur, sit magnam aperiam corrupti sequi minus quas aspernatur? Reiciendis eaque alias sed vitae quo accusantium esse facilis voluptatem minima accusamus.
           Cumque illo accusantium consequatur maiores earum quisquam tempora asperiores. Reiciendis corporis quibusdam porro! Quos fugit at nisi dicta ipsa ex reiciendis error, facere magni! Earum omnis at animi quis ea?
           Eveniet dolorem asperiores debitis neque blanditiis esse. Cumque est fuga reprehenderit repudiandae ipsa pariatur esse alias, repellendus reiciendis vel quia ducimus eveniet hic doloremque libero deleniti ullam harum atque voluptatem.
           Quibusdam quae molestiae veritatis error dolor nulla quaerat accusamus officia autem eius magni earum inventore atque voluptatibus voluptatum ducimus temporibus necessitatibus, eveniet maiores assumenda est. Deserunt explicabo error laudantium corrupti.
           Voluptatibus, laboriosam maxime quibusdam asperiores labore assumenda ut delectus earum ratione beatae nam non. Cumque dolores maxime, deserunt optio ducimus numquam perspiciatis deleniti corporis nostrum tempore harum laudantium quaerat? Omnis!
           Voluptatibus aliquam sapiente, quam est cupiditate recusandae dolores voluptas possimus aut maiores accusamus architecto reiciendis excepturi? Voluptate asperiores, nesciunt dolores laboriosam quisquam, laudantium exercitationem blanditiis labore natus tempora illo fugiat?
           Omnis odio itaque sunt, placeat quos libero enim sequi temporibus vitae nihil nemo illo aliquid, eum maiores facilis recusandae. Consectetur placeat necessitatibus nam voluptas culpa est exercitationem eos, voluptates consequuntur!
           Aperiam modi, error nemo sequi eos magni amet iste! Totam voluptas impedit hic sequi, delectus vitae consequuntur maxime suscipit ut nihil id dicta quis iusto provident et facere dolor atque?
           Officiis consequatur odio nemo animi provident ipsam eum, magni quasi cupiditate mollitia quod ad eius amet possimus dignissimos sunt magnam. Corrupti odio aliquid beatae nesciunt delectus ipsa perspiciatis aspernatur quisquam?
           Non sit consectetur doloremque ex voluptatum corrupti tempora sequi in error explicabo suscipit officia id cupiditate esse, ut vero saepe fugit, repudiandae nostrum at. Sunt, dicta animi. Quisquam, ullam culpa?
           Incidunt accusamus ex minus tempore dignissimos fugiat voluptas illum ullam ipsam. Eum iste possimus perferendis repellendus eius! Quibusdam repellendus aperiam, doloremque iusto hic, similique possimus ipsum temporibus veniam odio quis?
           Amet odio, magni nemo quisquam excepturi dicta veritatis voluptatibus obcaecati aut temporibus nam quod delectus. Vel aut totam laborum iure corrupti voluptas praesentium quo nesciunt? Sequi voluptates quibusdam assumenda illo!
           Beatae fugit modi nesciunt quis aperiam, autem qui nemo. Qui libero cupiditate quidem, exercitationem asperiores, ipsa tenetur quia eligendi perferendis odit autem ad recusandae earum, rerum dolor nulla voluptatibus maiores?
           Quo maiores vero delectus tenetur facilis? Distinctio ipsa aspernatur minus, laudantium dolorem sapiente eveniet pariatur, labore assumenda ipsum quidem impedit est totam blanditiis magni excepturi ullam odio, eaque voluptas quis?
           Eum dolorum enim, tempore fugiat quod reiciendis error quos, tenetur, minus autem pariatur consectetur nisi assumenda. Magnam numquam cumque vitae perferendis provident iste deleniti velit quos? Eos sit corrupti repudiandae.
           Quo earum temporibus illum cumque, corporis nobis qui sequi aut aperiam alias consequuntur, cupiditate quibusdam ut veritatis ad. Porro dolorem dolor itaque quasi autem, cumque ducimus vitae distinctio eligendi nemo!
           Quasi deleniti laborum porro totam rem sequi aliquam perspiciatis, magni quod non natus exercitationem fuga laudantium. Quibusdam sunt in, ducimus saepe nam accusantium, ea, voluptas labore provident vero doloremque laudantium.
           Porro ea modi fugiat, deleniti sit aperiam neque consequatur quia consequuntur. Asperiores, deserunt explicabo? Porro laborum debitis et eos quaerat consequuntur? Quos pariatur distinctio maiores aperiam cupiditate id animi quo?
           Qui facere sunt nam magnam alias quaerat recusandae molestiae fugiat temporibus, dolor totam odit, cum harum! Eius adipisci totam neque laudantium et at velit, dolorem quasi enim sed, beatae debitis?
           Quaerat ipsam dolore recusandae vel obcaecati corporis nostrum porro facilis id. Voluptatibus, qui fuga voluptatum maiores ab rerum, provident alias nesciunt doloremque explicabo nisi nam mollitia quaerat vero. Libero, fugiat?
           Animi voluptatum dolores veritatis quo porro neque tempora atque fugit quasi nihil sint, obcaecati ut nulla, exercitationem praesentium voluptate dolore similique error voluptatem pariatur. Voluptatum cupiditate iure aperiam reiciendis consequatur.
           Quidem aliquam iste praesentium distinctio voluptate ut nesciunt qui atque explicabo vel, officia deserunt similique reiciendis magni quibusdam eligendi, repellendus aliquid cupiditate pariatur, sunt eaque eum unde. Dicta, modi accusantium.
           Ratione recusandae ipsa, iure dolorem aliquid iste amet, perspiciatis omnis exercitationem fugit vel facere quia in explicabo sit. Eaque, ipsam? Natus voluptatibus commodi facilis quisquam. Optio, enim quis! Dolorem, dolores.
           Nostrum suscipit facilis error a reprehenderit voluptas porro id temporibus expedita facere, enim quaerat, corrupti odio numquam rem dolor aut similique dignissimos non fugit praesentium! Dicta quisquam facilis labore porro?
           Et maxime a laboriosam fuga eligendi. Error ullam tempora inventore itaque sapiente, vel sed quam dolor nemo veritatis, exercitationem magni dicta, deleniti quas repellendus excepturi velit? Autem ipsa non minima.
           Est natus debitis omnis excepturi eum, quaerat dolorem magni explicabo quia id recusandae, aperiam aut error quidem deleniti ducimus quae minus aspernatur a possimus? Dolorum eaque quisquam ut dolorem cumque?
           Ratione eveniet doloribus non optio deleniti saepe iusto. Magni impedit labore cum, a voluptate commodi incidunt natus totam tenetur nisi iure quaerat soluta suscipit ex aperiam deleniti atque reprehenderit voluptates!
        </div>
    </div>
    <footer id="fMask">
        <div class="f-t">
            <div class="f1 toggle">
                <span style="display:flex;"><span class="arrow k1">&#9660;</span><span
                        class="fwb">DocCheck</span></span>
                <ul class="ul-fot">
                    <li class="fot-li"><a href="#roulette" class="fot-link">About Us</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Investor Relations</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Press</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Career</a></li>
                </ul>
            </div>
            <div class="f2 toggle">
                <span style="display:flex;"><span class="arrow">&#9660;</span><span class="fwb">For
                        Business</span></span>
                <ul class="ul-fot">
                    <li class="fot-li"><a href="#roulette" class="fot-link">Media Kit</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Login Services</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Content Marketing</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Market Research</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Agile Commerce</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">All Services</a></li>
                </ul>
            </div>
            <div class="f3 toggle">
                <span style="display:flex;"><span class="arrow">&#9660;</span><span class="fwb">Other
                        stuff</span></span>
                <ul class="ul-fot">
                    <li class="fot-li"><a href="#roulette" class="fot-link">Contact</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Terms</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Privacy</a></li>
                    <li class="fot-li"><a href="#roulette" class="fot-link">Imprint</a></li>
                </ul>
            </div>
        </div>
        <div class="row ng-tns-c248-7">
            <div class="col-md footer-buttons align-items-center">
                <div class="mb-0 dc-dynamic ng-tns-c246-11 image-shown">
                    <img class="rounded-circle selected-image ng-tns-c246-11 not-empty ng-star-inserted" loading="lazy"
                        src="./img/en.png" alt="">
                </div>
            </div>
            <div class="f-b col-md footer-social align-self-center">
                <div class="icons-b icon-wrapper">
                    <div class="i1"><a href="#roulette" class="tw-l"><img loading="lazy"
                                src="./img/facebook-app-symbol.png" alt="" class="icon-design"></a></div>
                    <div class="i2"><a href="#roulette" class="tw-l"><img loading="lazy"
                                src="./img/twitter.png" alt="" class="icon-design"></a>
                    </div>
                    <div class="i3"><a href="#roulette" class="tw-l"><img loading="lazy"
                                src="./img/instagram.png" alt="" class="icon-design"></a>
                    </div>
                    <div class="i4"><a href="#roulette" class="tw-l"><img loading="lazy"
                                src="./img/linkedin.png" alt="" class="icon-design"></a>
                    </div>
                    <div class="i5"><a href="#roulette" class="tw-l"><img loading="lazy"
                                src="./img/whatsapp.png" alt="" class="icon-design"></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row ng-tns-c248-7">
            <div class="company ng-tns-c248-7">
                © 2024 DocCheck Community GmbH
            </div>
        </div>
    </footer>
    <script src="./dist/bundle.js"></script>


</body>
</html>