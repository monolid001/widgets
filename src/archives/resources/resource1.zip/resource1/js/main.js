import '../css/main.scss';
//------------------------

$(function () {
  var $redCoronaBanner = $('#corona-banner.main-banner');
  var $greenCoronaBanner = $('#corona-banner').not('.main-banner');
  var $cookieBlock = $('#cookie');
  var $footer = $('.fMask'); // Изменить селектор если отличается
  var $callbackBtn = $('#kmacb');
  var $body = $('body');
  var wasWindowResizedOrScrolled = false;

  changeIndents();

  $cookieBlock.on('click', '#closecookie1, #closecookie2', changeIndents);

  window.addEventListener('load', function() {
      $(document).on('scroll', function() {
          wasWindowResizedOrScrolled = true;
          changeIndents();
      });
      $(window).on('resize', function() {
          wasWindowResizedOrScrolled = true;
          changeIndents();
      });
  });

  function changeIndents() {
      var calculatedIndents = getCalculatedIndents();

      $footer.css('padding-bottom', calculatedIndents.footerIndent + 'px');
      $callbackBtn.css('bottom', calculatedIndents.callbackBtnIndent + 'px');
      $redCoronaBanner.css('margin-bottom', calculatedIndents.redCoronaBannerIndent + 'px');

      wasWindowResizedOrScrolled && $body.css('padding-top', calculatedIndents.bodyIndent + 'px');
  }

  function getCalculatedIndents() {
      var cookieBlockHeight = getBlockHeight($cookieBlock);
      var redCoronaBannerHeight = getBlockHeight($redCoronaBanner);
      var greenCoronaBannerHeight = getBlockHeight($greenCoronaBanner);

      var footerIndent = cookieBlockHeight + redCoronaBannerHeight + 35;
      if($(window).scrollTop() > 100) {
          var callbackBtnIndent = cookieBlockHeight + redCoronaBannerHeight;
      } else {
          var callbackBtnIndent = cookieBlockHeight;
      }
      var bodyIndent = greenCoronaBannerHeight || redCoronaBannerHeight;
      var redCoronaBannerIndent = cookieBlockHeight;


      return {
          footerIndent,
          callbackBtnIndent,
          bodyIndent,
          redCoronaBannerIndent,
      };
  }

  function checkBlockAvailability($block) {
      return $block.css('display') !== 'none' && $block.length !== 0;
  }

  function getBlockHeight($block) {
      var isBlockAvailable = checkBlockAvailability($block);
      var blockHeight = isBlockAvailable ? $block.outerHeight() : 0;

      return blockHeight;
  }
});


$(document).ready(function () {
    $('a[href^="#"]').bind("click", function (e) {
        var anchor = $(this);
        var offset = ($('#corona-banner') && !$('#corona-banner').hasClass('main-banner') && $('#corona-banner').css('display') !== 'none') ? $('#corona-banner').outerHeight() : 0;
        if (!$(this).hasClass('popup-open') && $(anchor.attr('href')).length) {
            $('html, body').stop().animate(
                { scrollTop: $(anchor.attr('href')).offset().top - offset },
                1000
            );
            e.preventDefault();
        }
    });
    return false;
});

function getElementY(query) {
    return window.pageYOffset + document.querySelector(query).getBoundingClientRect().top;
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const targetID = this.getAttribute('href');
        const target_Y = getElementY(targetID);

        let scroll = (targetY) => {
            window.scrollTo({
                top: targetY,
                behavior: 'smooth'
            })
            setTimeout(() => {
                const targetY_again = getElementY(targetID);
                if (targetY !== targetY_again) {
                    scroll(targetY_again)
                }
            }, 700)
        }

        scroll(target_Y)
    });
});

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.f-t .toggle > span').forEach((header) => {
        header.addEventListener('click', function () {
            this.parentElement.classList.toggle('active');
        });
    });
    const firstToggle = document.querySelector('.f-t .toggle:first-child');
    if (firstToggle) {
        firstToggle.classList.add('active');
    }
});


let lastScrollTop = 0;

window.addEventListener('scroll', function () {
    let currentScroll = window.pageYOffset || document.documentElement.scrollTop;

    if (currentScroll < lastScrollTop && currentScroll > 100) {
        document.querySelector('.ds').classList.add('fixed');
    } else {
        document.querySelector('.ds').classList.remove('fixed');
    }
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
}, false);


document.addEventListener('DOMContentLoaded', () => {
    const fixedElement = document.querySelector('.ds');
    let lastScrollTop = 0;  
    window.addEventListener('scroll', () => {
      let currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
      if (currentScrollTop < lastScrollTop) {
        fixedElement.classList.add('visible');
      } else {
        fixedElement.classList.remove('visible');
      }
      lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop;
    }, false);
  });
  

  
  var time = 600;
  var intr;

  function start_timer() {
      intr = setInterval(tick, 1000);
  }

  function tick() {
      time = time - 1;
      var mins = Math.floor(time / 60);
      var secs = time - mins * 60;
      if (mins == 0 && secs == 0) {
          clearInterval(intr);
      }
      secs = secs >= 10 ? secs : "0" + secs;
      $("#min").html("0" + mins);
      $("#sec").html(secs);
  }
  start_timer()